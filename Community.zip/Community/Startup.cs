using System;
using System.Collections.Generic;
using System.Text.Json.Serialization;
using Community.Middlewares;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Http;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Microsoft.IdentityModel.Tokens;
using Microsoft.OpenApi.Models;
using Community.DbContexts;
using Community.Dtos.Pagination.Services;
using Community.Extentions;
using Community.Clients.Keycloak.Extentions;
using Community.Hubs;

namespace Community
{
    public class Startup
    {
        public Startup(IConfiguration configuration)
        {
            Configuration = configuration;
        }

        public IConfiguration Configuration { get; }
        readonly string MyAllowSpecificOrigins = "_myAllowSpecificOrigins";

        // This method gets called by the runtime. Use this method to add services to the container.
        public void ConfigureServices(IServiceCollection services)
        {

            services.AddCors();

            services.AddControllers().AddJsonOptions(options =>
            {
                options.JsonSerializerOptions.DefaultIgnoreCondition = JsonIgnoreCondition.WhenWritingNull;
            });

            services.AddAutoMapper(typeof(Startup));

            var connectionString = Environment.GetEnvironmentVariable("CIEN_COMMUNITY_DATABASE_CONNECTION_STRING");
            //var connectionString = Configuration.GetConnectionString("CIEN_COMMUNITY_DATABASE_CONNECTION_STRING");

            services.AddDbContext<CommunityDbContext>(c => c.UseSqlServer(connectionString));

            services.AddHttpContextAccessor();

            services.AddSingleton<IUriService>(o =>
            {
                var accessor = o.GetRequiredService<IHttpContextAccessor>();
                var request = accessor.HttpContext.Request;
                var uri = string.Concat(request.Scheme, "://", request.Host.ToUriComponent());
                return new UriService(uri);
            });

            services.AddKeycloakExtentions();
            services.AddCommunityExtentions();
            services.AddListasItemExtentions();
            services.AddPublicationExtentions();
            services.AddFilesExtentions();
            services.AddInterestsExtentions();
            services.AddMessageExtentions();
            services.AddNotificationExtentions();
            services.AddToolsExtentions();
            services.AddLearnExtentions();
            services.AddToolsFasesExtentions();
            services.AddToolsTareasExtentions();
            services.AddToolsEquiposExtentions();
            services.AddCocreaExtentions();
            services.AddmetricasExtentions();
            services.AddChatBotExtentions();

            services.AddSignalR();            // Add this service too

            var keycloakAuthority = Environment.GetEnvironmentVariable("KEYCLOAK_HOST") + "/auth/realms/" + Environment.GetEnvironmentVariable("KEYCLOAK_REALM");

            var keycloakAppClientId = Environment.GetEnvironmentVariable("KEYCLOAK_APP_CLIENT_ID");

            services.AddAuthentication(JwtBearerDefaults.AuthenticationScheme)
            .AddJwtBearer(options =>
            {
                options.Authority = keycloakAuthority;
                options.Audience = keycloakAppClientId;
                options.IncludeErrorDetails = true;
                options.TokenValidationParameters = new TokenValidationParameters
                {
                    ValidateAudience = false,
                    //ValidAudiences = new[] { "master-realm", "account" },
                    ValidateIssuer = false,
                    ValidIssuer = keycloakAuthority,
                    ValidateLifetime = false
                };
            });

            services.AddAuthorization();

            services.AddSwaggerGen(options =>
            {
               options.SwaggerDoc("v1", new OpenApiInfo { Title = "Community", Version = "v1" });
               options.AddSecurityDefinition("oauth2", new OpenApiSecurityScheme
               {
                   Type = SecuritySchemeType.OAuth2,
                   Flows = new OpenApiOAuthFlows
                   {
                       AuthorizationCode = new OpenApiOAuthFlow
                       {
                           AuthorizationUrl = new Uri(keycloakAuthority + "/protocol/openid-connect/auth"),
                           TokenUrl = new Uri(keycloakAuthority + "/protocol/openid-connect/token"),
                           Scopes = new Dictionary<string, string>
                           {
                                {"role", "user roles"}
                           }
                       }
                   }
               });

               options.OperationFilter<AuthorizeCheckOperationFilter>();
            });

            // services.AddCors(options =>
            // {
            //     options.AddPolicy(name: MyAllowSpecificOrigins,
            //                   builder =>
            //                   {
            //                       builder.WithOrigins( 
            //                         "http://localhost:4200",
            //                         "https://dev.cien.itofontic.co",                                    
            //                         "https://dev.cien.itofontic.co/usuariochatsocket",
            //                         "https://dev.cien.itofontic.co/chatsocket",
            //                         "https://cien.itofontic.co",
            //                         "https://test.cien.itofontic.co")
            //                       .AllowAnyHeader()
            //                       .AllowAnyMethod()
            //                       .AllowCredentials();
            //                   });
            // });
        }

        // This method gets called by the runtime. Use this method to configure the HTTP request pipeline.
        public void Configure(IApplicationBuilder app, IWebHostEnvironment env)
        {
            if (env.IsDevelopment())
            {
                app.UseDeveloperExceptionPage();
            }

            app.UseSwagger();

            app.UseSwaggerUI(options =>
            {
                options.SwaggerEndpoint("/swagger/v1/swagger.json", "api v1");

                options.OAuthClientId(Environment.GetEnvironmentVariable("SWAGGER_CLIENT_ID"));
                options.OAuthClientSecret(Environment.GetEnvironmentVariable("SWAGGER_CLIENT_SECRET"));
                options.OAuthAppName("API Community - Swagger");
                options.OAuthUsePkce();
            });

            app.UseRouting();

            app.UseAuthentication();

            app.UseAuthorization();

            app.UseCors();

            app.UseCors(options => options.WithOrigins(
                "http://localhost:4200",
                "https://dev.cien.itofontic.co",
                "https://cien.itofontic.co",
                "https://test.cien.itofontic.co"
                ).AllowAnyHeader().AllowAnyMethod().AllowCredentials());

            app.UseEndpoints(endpoints =>
            {
                // endpoints.MapControllers().RequireCors(MyAllowSpecificOrigins);;
                endpoints.MapControllers();
                // endpoints.MapHub<ChatHub>("/chatsocket");
                // endpoints.MapHub<UsuariosChatHub>("/usuariochatsocket");
                endpoints.MapHub<ChatHub>("api/community/chatsocket");
                endpoints.MapHub<UsuariosChatHub>("api/community/usuariochatsocket");
            });

        }
    }
}