﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

namespace Community.Migrations
{
    public partial class initial : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "AppFiles",
                columns: table => new
                {
                    id = table.Column<Guid>(type: "uniqueidentifier", nullable: false),
                    owner_id = table.Column<Guid>(type: "uniqueidentifier", nullable: false),
                    content_type = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    length = table.Column<long>(type: "bigint", nullable: false),
                    name = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    file_name = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    created_at = table.Column<DateTime>(type: "datetime2", nullable: true, defaultValueSql: "getdate()"),
                    updated_at = table.Column<DateTime>(type: "datetime2", nullable: true, defaultValueSql: "getdate()")
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_AppFiles", x => x.id);
                });

            migrationBuilder.CreateTable(
                name: "ChatBot",
                columns: table => new
                {
                    IDChatBot = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    HtmlTexto = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    Tipo = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    Llave = table.Column<string>(type: "nvarchar(450)", nullable: false),
                    Ubicacion = table.Column<int>(type: "int", nullable: false),
                    Anterior = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    Ejecucion = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    Siguiente = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    FechaCreacion = table.Column<DateTime>(type: "datetime2", nullable: false),
                    UsuarioCreacion = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    Estado = table.Column<int>(type: "int", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_ChatBot", x => x.IDChatBot);
                });

            migrationBuilder.CreateTable(
                name: "listas_community",
                columns: table => new
                {
                    id = table.Column<Guid>(type: "uniqueidentifier", nullable: false),
                    codigo = table.Column<string>(type: "Varchar (255)", nullable: false),
                    nombre = table.Column<string>(type: "Varchar (255)", nullable: false),
                    orden = table.Column<int>(type: "int", nullable: false, defaultValue: 0),
                    padre_id = table.Column<Guid>(type: "uniqueidentifier", nullable: true),
                    fecha_creacion = table.Column<DateTime>(type: "datetime2", nullable: false, defaultValueSql: "getdate()"),
                    fecha_actualizacion = table.Column<DateTime>(type: "datetime2", nullable: false, defaultValueSql: "getdate()"),
                    fecha_eliminacion = table.Column<DateTime>(type: "datetime2", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_listas_community", x => x.id);
                    table.ForeignKey(
                        name: "LISTA_ITEM_PADRE_COMMUNITY_FK",
                        column: x => x.padre_id,
                        principalTable: "listas_community",
                        principalColumn: "id");
                });

            migrationBuilder.CreateTable(
                name: "LoginUsers",
                columns: table => new
                {
                    Id = table.Column<Guid>(type: "uniqueidentifier", nullable: false),
                    Iduser = table.Column<Guid>(type: "uniqueidentifier", nullable: false),
                    Nombre = table.Column<string>(type: "VARCHAR(500)", maxLength: 500, nullable: false),
                    Usuario = table.Column<string>(type: "VARCHAR(500)", maxLength: 500, nullable: false),
                    Correo = table.Column<string>(type: "VARCHAR(500)", maxLength: 500, nullable: false),
                    FechaCreacion = table.Column<DateTime>(type: "datetime2", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_LoginUsers", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "ModuloPruebas",
                columns: table => new
                {
                    Id = table.Column<Guid>(type: "uniqueidentifier", nullable: false),
                    TipoPagina = table.Column<string>(type: "VARCHAR(255)", maxLength: 255, nullable: false),
                    FechaCreacion = table.Column<DateTime>(type: "datetime2", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_ModuloPruebas", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "Participantes",
                columns: table => new
                {
                    Id = table.Column<Guid>(type: "uniqueidentifier", nullable: false),
                    Nombre = table.Column<string>(type: "VARCHAR(255)", maxLength: 255, nullable: false),
                    Estado = table.Column<bool>(type: "BIT", maxLength: 255, nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Participantes", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "Preguntas",
                columns: table => new
                {
                    Id = table.Column<Guid>(type: "uniqueidentifier", nullable: false),
                    EntidadId = table.Column<Guid>(type: "uniqueidentifier", nullable: false),
                    EntidadNombre = table.Column<string>(type: "VARCHAR(255)", maxLength: 255, nullable: false),
                    GrupoId = table.Column<Guid>(type: "uniqueidentifier", nullable: false),
                    GrupoNombre = table.Column<string>(type: "VARCHAR(255)", maxLength: 255, nullable: false),
                    PreguntaTexto = table.Column<string>(type: "VARCHAR(500)", maxLength: 500, nullable: false),
                    Justificacion = table.Column<string>(type: "VARCHAR(500)", maxLength: 500, nullable: false),
                    Estado = table.Column<bool>(type: "BIT", maxLength: 100, nullable: false),
                    FechaCreacion = table.Column<DateTime>(type: "datetime2", nullable: false),
                    FechaModificacion = table.Column<DateTime>(type: "datetime2", nullable: false),
                    Autor = table.Column<Guid>(type: "uniqueidentifier", nullable: false),
                    ModificadoPor = table.Column<Guid>(type: "uniqueidentifier", nullable: false),
                    Contador = table.Column<int>(type: "int", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Preguntas", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "proyecto",
                columns: table => new
                {
                    id = table.Column<Guid>(type: "uniqueidentifier", nullable: false),
                    nombre = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    descripcion = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    finalizacion = table.Column<int>(type: "int", nullable: false),
                    etiquetas = table.Column<string>(type: "nvarchar(max)", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_proyecto", x => x.id);
                });

            migrationBuilder.CreateTable(
                name: "Respuestas_Recurso_Experioencia_Herramienta",
                columns: table => new
                {
                    id = table.Column<Guid>(type: "uniqueidentifier", nullable: false),
                    tipo_entidad = table.Column<short>(type: "smallint", nullable: false),
                    respuesta1 = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    respuesta2 = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    respuesta3 = table.Column<string>(type: "nvarchar(max)", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Respuestas_Recurso_Experioencia_Herramienta", x => x.id);
                });

            migrationBuilder.CreateTable(
                name: "Retos",
                columns: table => new
                {
                    Id = table.Column<Guid>(type: "uniqueidentifier", nullable: false),
                    Titulo = table.Column<string>(type: "VARCHAR(255)", maxLength: 255, nullable: false),
                    Descripcion = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: false),
                    FechaCreacion = table.Column<DateTime>(type: "datetime2", nullable: false),
                    FechaCierre = table.Column<DateTime>(type: "datetime2", nullable: false),
                    Vistas = table.Column<int>(type: "int", nullable: false),
                    Requisitos = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: false),
                    Estado = table.Column<string>(type: "VARCHAR(100)", maxLength: 100, nullable: false),
                    Autor = table.Column<Guid>(type: "uniqueidentifier", nullable: false),
                    FlagEstado = table.Column<bool>(type: "BIT", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Retos", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "Temas",
                columns: table => new
                {
                    Id = table.Column<Guid>(type: "uniqueidentifier", nullable: false),
                    Nombre = table.Column<string>(type: "VARCHAR(255)", maxLength: 255, nullable: false),
                    Descripcion = table.Column<string>(type: "VARCHAR(500)", maxLength: 500, nullable: true),
                    Estado = table.Column<bool>(type: "BIT", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Temas", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "entidad",
                columns: table => new
                {
                    id = table.Column<Guid>(type: "uniqueidentifier", nullable: false),
                    nombre = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    contacto = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    ciudad_id = table.Column<Guid>(type: "uniqueidentifier", nullable: false),
                    orden_id = table.Column<Guid>(type: "uniqueidentifier", nullable: true),
                    sector_id = table.Column<Guid>(type: "uniqueidentifier", nullable: true),
                    app_file_id = table.Column<Guid>(type: "uniqueidentifier", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_entidad", x => x.id);
                    table.ForeignKey(
                        name: "ENTIDAD_APPFILE_FK",
                        column: x => x.app_file_id,
                        principalTable: "AppFiles",
                        principalColumn: "id");
                    table.ForeignKey(
                        name: "ENTIDAD_CIUDAD_FK",
                        column: x => x.ciudad_id,
                        principalTable: "listas_community",
                        principalColumn: "id");
                    table.ForeignKey(
                        name: "ENTIDAD_ORDEN_FK",
                        column: x => x.orden_id,
                        principalTable: "listas_community",
                        principalColumn: "id");
                    table.ForeignKey(
                        name: "ENTIDAD_SECTOR_FK",
                        column: x => x.sector_id,
                        principalTable: "listas_community",
                        principalColumn: "id");
                });

            migrationBuilder.CreateTable(
                name: "respuesta_etiqueta",
                columns: table => new
                {
                    id = table.Column<Guid>(type: "uniqueidentifier", nullable: false),
                    respuesta_id = table.Column<Guid>(type: "uniqueidentifier", nullable: true),
                    etiqueta_id = table.Column<Guid>(type: "uniqueidentifier", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_respuesta_etiqueta", x => x.id);
                    table.ForeignKey(
                        name: "LISTA_RESPUESTAETIQUETA_Etiqueta_FK",
                        column: x => x.etiqueta_id,
                        principalTable: "listas_community",
                        principalColumn: "id");
                    table.ForeignKey(
                        name: "LISTA_RESPUESTAETIQUETA_Respuesta_FK",
                        column: x => x.respuesta_id,
                        principalTable: "listas_community",
                        principalColumn: "id");
                });

            migrationBuilder.CreateTable(
                name: "ubicacion_geografica",
                columns: table => new
                {
                    id = table.Column<Guid>(type: "uniqueidentifier", nullable: false),
                    Latitud = table.Column<double>(type: "float", nullable: false),
                    Longitud = table.Column<double>(type: "float", nullable: false),
                    MunicipioId = table.Column<Guid>(type: "uniqueidentifier", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_ubicacion_geografica", x => x.id);
                    table.ForeignKey(
                        name: "UBICACIONGEOGRAFICA_LISTAITEMUBICACION_FK",
                        column: x => x.MunicipioId,
                        principalTable: "listas_community",
                        principalColumn: "id");
                });

            migrationBuilder.CreateTable(
                name: "Respuestas",
                columns: table => new
                {
                    Id = table.Column<Guid>(type: "uniqueidentifier", nullable: false),
                    RespuestaTexto = table.Column<string>(type: "VARCHAR(500)", maxLength: 500, nullable: false),
                    Estado = table.Column<bool>(type: "BIT", nullable: false),
                    FechaCreacion = table.Column<DateTime>(type: "datetime2", nullable: false),
                    FechaModificacion = table.Column<DateTime>(type: "datetime2", nullable: false),
                    Autor = table.Column<Guid>(type: "uniqueidentifier", nullable: false),
                    ModificadoPor = table.Column<Guid>(type: "uniqueidentifier", nullable: false),
                    LikesCount = table.Column<int>(type: "int", nullable: false),
                    PreguntaId = table.Column<Guid>(type: "uniqueidentifier", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Respuestas", x => x.Id);
                    table.ForeignKey(
                        name: "FK_Respuestas_Preguntas_PreguntaId",
                        column: x => x.PreguntaId,
                        principalTable: "Preguntas",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "DocumentoRetos",
                columns: table => new
                {
                    Id = table.Column<Guid>(type: "uniqueidentifier", nullable: false),
                    RetoId = table.Column<Guid>(type: "uniqueidentifier", nullable: false),
                    Tipo = table.Column<string>(type: "VARCHAR(255)", maxLength: 255, nullable: false),
                    Webp = table.Column<string>(type: "nvarchar(max)", maxLength: 2147483647, nullable: true),
                    Base64 = table.Column<string>(type: "nvarchar(max)", maxLength: 2147483647, nullable: true),
                    NombreDocumento = table.Column<string>(type: "nvarchar(255)", maxLength: 255, nullable: false),
                    FlagPortada = table.Column<bool>(type: "BIT", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_DocumentoRetos", x => x.Id);
                    table.ForeignKey(
                        name: "FK_DocumentoRetos_Retos_RetoId",
                        column: x => x.RetoId,
                        principalTable: "Retos",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "EntidadRetos",
                columns: table => new
                {
                    Id = table.Column<Guid>(type: "uniqueidentifier", nullable: false),
                    RetoId = table.Column<Guid>(type: "uniqueidentifier", nullable: false),
                    EntidadId = table.Column<Guid>(type: "uniqueidentifier", nullable: false),
                    NombreEntidad = table.Column<string>(type: "nvarchar(255)", maxLength: 255, nullable: false),
                    Estado = table.Column<bool>(type: "BIT", maxLength: 255, nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_EntidadRetos", x => x.Id);
                    table.ForeignKey(
                        name: "FK_EntidadRetos_Retos_RetoId",
                        column: x => x.RetoId,
                        principalTable: "Retos",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "EtapaRetos",
                columns: table => new
                {
                    Id = table.Column<Guid>(type: "uniqueidentifier", nullable: false),
                    RetoId = table.Column<Guid>(type: "uniqueidentifier", nullable: false),
                    Nombre = table.Column<string>(type: "varchar(MAX)", nullable: false),
                    FechaInicial = table.Column<DateTime>(type: "datetime2", nullable: false),
                    FechaFinal = table.Column<DateTime>(type: "datetime2", nullable: false),
                    Estado = table.Column<bool>(type: "BIT", maxLength: 255, nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_EtapaRetos", x => x.Id);
                    table.ForeignKey(
                        name: "FK_EtapaRetos_Retos_RetoId",
                        column: x => x.RetoId,
                        principalTable: "Retos",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "IncentivoRetos",
                columns: table => new
                {
                    Id = table.Column<Guid>(type: "uniqueidentifier", nullable: false),
                    RetoId = table.Column<Guid>(type: "uniqueidentifier", nullable: false),
                    Nombre = table.Column<string>(type: "VARCHAR(255)", maxLength: 255, nullable: false),
                    Descripcion = table.Column<string>(type: "VARCHAR(500)", maxLength: 500, nullable: false),
                    Estado = table.Column<bool>(type: "BIT", maxLength: 255, nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_IncentivoRetos", x => x.Id);
                    table.ForeignKey(
                        name: "FK_IncentivoRetos_Retos_RetoId",
                        column: x => x.RetoId,
                        principalTable: "Retos",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "ParticipanteRetos",
                columns: table => new
                {
                    Id = table.Column<Guid>(type: "uniqueidentifier", nullable: false),
                    RetoId = table.Column<Guid>(type: "uniqueidentifier", nullable: false),
                    ParticipanteId = table.Column<Guid>(type: "uniqueidentifier", nullable: false),
                    Estado = table.Column<bool>(type: "BIT", maxLength: 255, nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_ParticipanteRetos", x => x.Id);
                    table.ForeignKey(
                        name: "FK_ParticipanteRetos_Participantes_ParticipanteId",
                        column: x => x.ParticipanteId,
                        principalTable: "Participantes",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "FK_ParticipanteRetos_Retos_RetoId",
                        column: x => x.RetoId,
                        principalTable: "Retos",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "TemaRetos",
                columns: table => new
                {
                    Id = table.Column<Guid>(type: "uniqueidentifier", nullable: false),
                    RetoId = table.Column<Guid>(type: "uniqueidentifier", nullable: false),
                    TemaId = table.Column<Guid>(type: "uniqueidentifier", nullable: false),
                    Estado = table.Column<bool>(type: "BIT", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_TemaRetos", x => x.Id);
                    table.ForeignKey(
                        name: "FK_TemaRetos_Retos_RetoId",
                        column: x => x.RetoId,
                        principalTable: "Retos",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "FK_TemaRetos_Temas_TemaId",
                        column: x => x.TemaId,
                        principalTable: "Temas",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "equipo",
                columns: table => new
                {
                    id = table.Column<Guid>(type: "uniqueidentifier", nullable: false),
                    nombre = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    contacto = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    ciudad_id = table.Column<Guid>(type: "uniqueidentifier", nullable: false),
                    entidad_id = table.Column<Guid>(type: "uniqueidentifier", nullable: false),
                    orden_id = table.Column<Guid>(type: "uniqueidentifier", nullable: true),
                    app_file_id = table.Column<Guid>(type: "uniqueidentifier", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_equipo", x => x.id);
                    table.ForeignKey(
                        name: "EQUIPO_APPFILE_FK",
                        column: x => x.app_file_id,
                        principalTable: "AppFiles",
                        principalColumn: "id");
                    table.ForeignKey(
                        name: "EQUIPO_CIUDAD_FK",
                        column: x => x.ciudad_id,
                        principalTable: "listas_community",
                        principalColumn: "id");
                    table.ForeignKey(
                        name: "EQUIPO_ENTIDAD_FK",
                        column: x => x.entidad_id,
                        principalTable: "entidad",
                        principalColumn: "id");
                    table.ForeignKey(
                        name: "EQUIPO_ORDEN_FK",
                        column: x => x.orden_id,
                        principalTable: "listas_community",
                        principalColumn: "id");
                });

            migrationBuilder.CreateTable(
                name: "RespuestaComentarios",
                columns: table => new
                {
                    Id = table.Column<Guid>(type: "uniqueidentifier", nullable: false),
                    ComentarioTexto = table.Column<string>(type: "VARCHAR(500)", maxLength: 500, nullable: false),
                    Estado = table.Column<bool>(type: "BIT", nullable: false),
                    FechaCreacion = table.Column<DateTime>(type: "datetime2", nullable: false),
                    FechaModificacion = table.Column<DateTime>(type: "datetime2", nullable: false),
                    Autor = table.Column<Guid>(type: "uniqueidentifier", nullable: false),
                    ModificadoPor = table.Column<Guid>(type: "uniqueidentifier", nullable: false),
                    RespuestaId = table.Column<Guid>(type: "uniqueidentifier", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_RespuestaComentarios", x => x.Id);
                    table.ForeignKey(
                        name: "FK_RespuestaComentarios_Respuestas_RespuestaId",
                        column: x => x.RespuestaId,
                        principalTable: "Respuestas",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "RespuestaLikes",
                columns: table => new
                {
                    Id = table.Column<Guid>(type: "uniqueidentifier", nullable: false),
                    Estado = table.Column<bool>(type: "BIT", nullable: false),
                    FechaCreacion = table.Column<DateTime>(type: "datetime2", nullable: false),
                    FechaModificacion = table.Column<DateTime>(type: "datetime2", nullable: false),
                    Autor = table.Column<Guid>(type: "uniqueidentifier", nullable: false),
                    ModificadoPor = table.Column<Guid>(type: "uniqueidentifier", nullable: false),
                    RespuestasId = table.Column<Guid>(type: "uniqueidentifier", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_RespuestaLikes", x => x.Id);
                    table.ForeignKey(
                        name: "FK_RespuestaLikes_Respuestas_RespuestasId",
                        column: x => x.RespuestasId,
                        principalTable: "Respuestas",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "app_user",
                columns: table => new
                {
                    id = table.Column<Guid>(type: "uniqueidentifier", nullable: false),
                    nombres = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    apellidos = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    pais_id = table.Column<Guid>(type: "uniqueidentifier", nullable: false),
                    departamento_id = table.Column<Guid>(type: "uniqueidentifier", nullable: false),
                    municipio_id = table.Column<Guid>(type: "uniqueidentifier", nullable: false),
                    fecha_nacimiento = table.Column<DateTime>(type: "datetime2", nullable: false),
                    genero_id = table.Column<Guid>(type: "uniqueidentifier", nullable: false),
                    notificar = table.Column<bool>(type: "bit", nullable: false, defaultValueSql: "0"),
                    mostrar_correo = table.Column<bool>(type: "bit", nullable: false, defaultValueSql: "0"),
                    mostrar_telefono = table.Column<bool>(type: "bit", nullable: false, defaultValueSql: "0"),
                    mostrar_redes = table.Column<bool>(type: "bit", nullable: false, defaultValueSql: "0"),
                    fecha_eliminacion = table.Column<DateTime>(type: "datetime2", nullable: true),
                    motivo_eliminacion_id = table.Column<Guid>(type: "uniqueidentifier", nullable: true),
                    entidad_id = table.Column<Guid>(type: "uniqueidentifier", nullable: true),
                    TipoEntidad = table.Column<Guid>(type: "uniqueidentifier", nullable: true),
                    entidad_texto = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    equipo_id = table.Column<Guid>(type: "uniqueidentifier", nullable: true),
                    equipo_texto = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    organizacion_id = table.Column<Guid>(type: "uniqueidentifier", nullable: true),
                    area_direccion_equipo_id = table.Column<Guid>(type: "uniqueidentifier", nullable: true),
                    sector_id = table.Column<Guid>(type: "uniqueidentifier", nullable: true),
                    orden_id = table.Column<Guid>(type: "uniqueidentifier", nullable: true),
                    profesion_id = table.Column<Guid>(type: "uniqueidentifier", nullable: true),
                    profesion = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    cargoactual_id = table.Column<Guid>(type: "uniqueidentifier", nullable: true),
                    rol_cargo_actual = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    nivel_id = table.Column<Guid>(type: "uniqueidentifier", nullable: true),
                    proyecto_actual_id = table.Column<Guid>(type: "uniqueidentifier", nullable: true),
                    proyecto_destacado_id = table.Column<Guid>(type: "uniqueidentifier", nullable: true),
                    celular = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    email = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    linkedin = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    twitter = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    app_file_id = table.Column<Guid>(type: "uniqueidentifier", nullable: true),
                    PreguntaConectaId = table.Column<Guid>(type: "uniqueidentifier", nullable: true),
                    PreguntaConectaTexto = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    Progreso = table.Column<int>(type: "int", nullable: false, defaultValueSql: "30"),
                    IndicativoId = table.Column<Guid>(type: "uniqueidentifier", nullable: true),
                    organizacion_id1 = table.Column<Guid>(type: "uniqueidentifier", nullable: true),
                    area_direccion_equipo_id1 = table.Column<Guid>(type: "uniqueidentifier", nullable: true),
                    estado_notificacion_conecta_id = table.Column<Guid>(type: "uniqueidentifier", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_app_user", x => x.id);
                    table.ForeignKey(
                        name: "APPUSER_APPFILE_FK",
                        column: x => x.app_file_id,
                        principalTable: "AppFiles",
                        principalColumn: "id");
                    table.ForeignKey(
                        name: "APPUSERS_ENTIDAD_FK",
                        column: x => x.entidad_id,
                        principalTable: "entidad",
                        principalColumn: "id");
                    table.ForeignKey(
                        name: "APPUSERS_EQUIPO_FK",
                        column: x => x.equipo_id,
                        principalTable: "equipo",
                        principalColumn: "id");
                    table.ForeignKey(
                        name: "LISTA_APPUSER_AreaDireccionEquipo_FK",
                        column: x => x.area_direccion_equipo_id1,
                        principalTable: "listas_community",
                        principalColumn: "id");
                    table.ForeignKey(
                        name: "LISTA_APPUSER_DEPARTAMENTORESIDENCIA_FK",
                        column: x => x.departamento_id,
                        principalTable: "listas_community",
                        principalColumn: "id");
                    table.ForeignKey(
                        name: "LISTA_APPUSER_GENERO_FK",
                        column: x => x.genero_id,
                        principalTable: "listas_community",
                        principalColumn: "id");
                    table.ForeignKey(
                        name: "LISTA_APPUSER_INDICATIVO_FK",
                        column: x => x.IndicativoId,
                        principalTable: "listas_community",
                        principalColumn: "id");
                    table.ForeignKey(
                        name: "LISTA_APPUSER_MOTIVO_ELIMINACION_FK",
                        column: x => x.motivo_eliminacion_id,
                        principalTable: "listas_community",
                        principalColumn: "id");
                    table.ForeignKey(
                        name: "LISTA_APPUSER_MUNICIPIORESIDENCIA_FK",
                        column: x => x.municipio_id,
                        principalTable: "listas_community",
                        principalColumn: "id");
                    table.ForeignKey(
                        name: "LISTA_APPUSER_PAISRESIDENCIA_FK",
                        column: x => x.pais_id,
                        principalTable: "listas_community",
                        principalColumn: "id");
                    table.ForeignKey(
                        name: "LISTA_APPUSER_ProyectoActual_FK",
                        column: x => x.proyecto_actual_id,
                        principalTable: "proyecto",
                        principalColumn: "id");
                    table.ForeignKey(
                        name: "LISTA_APPUSER_ProyectoDestacado_FK",
                        column: x => x.proyecto_destacado_id,
                        principalTable: "proyecto",
                        principalColumn: "id");
                    table.ForeignKey(
                        name: "LISTA_PERFIL_AreaDireccionEquipo_FK",
                        column: x => x.area_direccion_equipo_id,
                        principalTable: "listas_community",
                        principalColumn: "id");
                    table.ForeignKey(
                        name: "LISTA_PERFIL_CargoActual_FK",
                        column: x => x.cargoactual_id,
                        principalTable: "listas_community",
                        principalColumn: "id");
                    table.ForeignKey(
                        name: "LISTA_PERFIL_NIvel_FK",
                        column: x => x.nivel_id,
                        principalTable: "listas_community",
                        principalColumn: "id");
                    table.ForeignKey(
                        name: "LISTA_PERFIL_Orden_FK",
                        column: x => x.orden_id,
                        principalTable: "listas_community",
                        principalColumn: "id");
                    table.ForeignKey(
                        name: "LISTA_PERFIL_ORGANIZACION_FK",
                        column: x => x.organizacion_id,
                        principalTable: "listas_community",
                        principalColumn: "id");
                    table.ForeignKey(
                        name: "LISTA_PERFIL_PreguntaConecta_FK",
                        column: x => x.PreguntaConectaId,
                        principalTable: "listas_community",
                        principalColumn: "id");
                    table.ForeignKey(
                        name: "LISTA_PERFIL_Profesion_FK",
                        column: x => x.profesion_id,
                        principalTable: "listas_community",
                        principalColumn: "id");
                    table.ForeignKey(
                        name: "LISTA_PERFIL_Sector_FK",
                        column: x => x.sector_id,
                        principalTable: "listas_community",
                        principalColumn: "id");
                });

            migrationBuilder.CreateTable(
                name: "contacto",
                columns: table => new
                {
                    id = table.Column<Guid>(type: "uniqueidentifier", nullable: false),
                    user_id = table.Column<Guid>(type: "uniqueidentifier", nullable: false),
                    contacto_id = table.Column<Guid>(type: "uniqueidentifier", nullable: false),
                    respuesta_contacto_id = table.Column<Guid>(type: "uniqueidentifier", nullable: true),
                    fecha_creacion = table.Column<DateTime>(type: "datetime2", nullable: false, defaultValueSql: "getdate()")
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_contacto", x => x.id);
                    table.ForeignKey(
                        name: "CONTACTO_User_CONTACTO_FK",
                        column: x => x.contacto_id,
                        principalTable: "app_user",
                        principalColumn: "id");
                    table.ForeignKey(
                        name: "CONTACTO_User_FK",
                        column: x => x.user_id,
                        principalTable: "app_user",
                        principalColumn: "id");
                    table.ForeignKey(
                        name: "LISTA_CONTACTO_RespuestaConecta_FK",
                        column: x => x.respuesta_contacto_id,
                        principalTable: "listas_community",
                        principalColumn: "id",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.CreateTable(
                name: "Conversacion",
                columns: table => new
                {
                    id = table.Column<Guid>(type: "uniqueidentifier", nullable: false),
                    user_sender_id = table.Column<Guid>(type: "uniqueidentifier", nullable: true),
                    user_receptor_id = table.Column<Guid>(type: "uniqueidentifier", nullable: true),
                    fecha_creacion = table.Column<DateTime>(type: "datetime2", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Conversacion", x => x.id);
                    table.ForeignKey(
                        name: "CONVERSACIONES_APPUSERRECEPTOR_FK",
                        column: x => x.user_receptor_id,
                        principalTable: "app_user",
                        principalColumn: "id");
                    table.ForeignKey(
                        name: "CONVERSACIONES_APPUSERSENDER_FK",
                        column: x => x.user_sender_id,
                        principalTable: "app_user",
                        principalColumn: "id");
                });

            migrationBuilder.CreateTable(
                name: "experiencia",
                columns: table => new
                {
                    id = table.Column<Guid>(type: "uniqueidentifier", nullable: false),
                    nombre = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    resumen = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    buena_practica_uno = table.Column<string>(type: "Varchar (400)", nullable: true),
                    buena_practica_dos = table.Column<string>(type: "Varchar (400)", nullable: true),
                    buena_practica_tres = table.Column<string>(type: "Varchar (400)", nullable: true),
                    leccion_aprendida_uno = table.Column<string>(type: "Varchar (400)", nullable: true),
                    leccion_aprendida_dos = table.Column<string>(type: "Varchar (400)", nullable: true),
                    leccion_aprendida_tres = table.Column<string>(type: "Varchar (400)", nullable: true),
                    escala_id = table.Column<Guid>(type: "uniqueidentifier", nullable: false),
                    AppFilePortadaId = table.Column<Guid>(type: "uniqueidentifier", nullable: false),
                    AppFileDocumentoId = table.Column<Guid>(type: "uniqueidentifier", nullable: false),
                    urlDocumento = table.Column<string>(type: "Varchar (500)", nullable: true),
                    etiquetas = table.Column<string>(type: "Varchar (1000)", nullable: true),
                    usar_herramienta = table.Column<bool>(type: "bit", nullable: false),
                    fecha_creacion = table.Column<DateTime>(type: "datetime2", nullable: false),
                    fecha_actualizacion = table.Column<DateTime>(type: "datetime2", nullable: false),
                    user_id = table.Column<Guid>(type: "uniqueidentifier", nullable: true),
                    ocultar = table.Column<bool>(type: "bit", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_experiencia", x => x.id);
                    table.ForeignKey(
                        name: "EXPERIENCIA_APPUSER_FK",
                        column: x => x.user_id,
                        principalTable: "app_user",
                        principalColumn: "id");
                    table.ForeignKey(
                        name: "EXPERIENCIA_DOCUMENTO_FILE_FK",
                        column: x => x.AppFileDocumentoId,
                        principalTable: "AppFiles",
                        principalColumn: "id");
                    table.ForeignKey(
                        name: "EXPERIENCIA_LISTAITEMESCALA_FK",
                        column: x => x.escala_id,
                        principalTable: "listas_community",
                        principalColumn: "id");
                    table.ForeignKey(
                        name: "EXPERIENCIA_PORTADA_FILE_FK",
                        column: x => x.AppFilePortadaId,
                        principalTable: "AppFiles",
                        principalColumn: "id");
                });

            migrationBuilder.CreateTable(
                name: "Herramienta",
                columns: table => new
                {
                    id = table.Column<Guid>(type: "uniqueidentifier", nullable: false),
                    user_id = table.Column<Guid>(type: "uniqueidentifier", nullable: false),
                    FechaCreacion = table.Column<DateTime>(type: "datetime2", nullable: false),
                    tipo_recurso_id = table.Column<Guid>(type: "uniqueidentifier", nullable: true),
                    descripcion = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    informacion_herramienta = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    opcion_recuerso = table.Column<bool>(type: "bit", nullable: false),
                    descripcion_recurso = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    Que_es = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    para_que_sirve = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    valor_como_se_usa = table.Column<bool>(type: "bit", nullable: false),
                    como_se_usa = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    tipo_herramienta = table.Column<Guid>(type: "uniqueidentifier", nullable: true),
                    etiquetas = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    idImgPortada = table.Column<Guid>(type: "uniqueidentifier", nullable: true),
                    urlImgPortada = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    idPdfArchivo = table.Column<Guid>(type: "uniqueidentifier", nullable: true),
                    urlPdfArchivo = table.Column<string>(type: "nvarchar(max)", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Herramienta", x => x.id);
                    table.ForeignKey(
                        name: "AppFiles_Tool_ImgPortada_FK",
                        column: x => x.idImgPortada,
                        principalTable: "AppFiles",
                        principalColumn: "id");
                    table.ForeignKey(
                        name: "AppFiles_Tool_PdfArchivo_FK",
                        column: x => x.idPdfArchivo,
                        principalTable: "AppFiles",
                        principalColumn: "id");
                    table.ForeignKey(
                        name: "LISTA_Tool_TipoHerramienta_FK",
                        column: x => x.tipo_herramienta,
                        principalTable: "listas_community",
                        principalColumn: "id");
                    table.ForeignKey(
                        name: "LISTA_Tool_TipoRecurso_FK",
                        column: x => x.tipo_recurso_id,
                        principalTable: "listas_community",
                        principalColumn: "id");
                    table.ForeignKey(
                        name: "Usuario_Tool_FK",
                        column: x => x.user_id,
                        principalTable: "app_user",
                        principalColumn: "id");
                });

            migrationBuilder.CreateTable(
                name: "Intereses",
                columns: table => new
                {
                    id = table.Column<Guid>(type: "uniqueidentifier", nullable: false),
                    user_id = table.Column<Guid>(type: "uniqueidentifier", nullable: true),
                    listaitem_id = table.Column<Guid>(type: "uniqueidentifier", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Intereses", x => x.id);
                    table.ForeignKey(
                        name: "LISTA_INTERESES_APPUSER_FK",
                        column: x => x.user_id,
                        principalTable: "app_user",
                        principalColumn: "id");
                    table.ForeignKey(
                        name: "LISTA_INTERESES_SEGERENCIA_FK",
                        column: x => x.listaitem_id,
                        principalTable: "listas_community",
                        principalColumn: "id");
                });

            migrationBuilder.CreateTable(
                name: "notificacion_silence",
                columns: table => new
                {
                    id = table.Column<Guid>(type: "uniqueidentifier", nullable: false),
                    fecha_creacion = table.Column<DateTime>(type: "datetime2", nullable: false),
                    user_id = table.Column<Guid>(type: "uniqueidentifier", nullable: false),
                    user_silence_id = table.Column<Guid>(type: "uniqueidentifier", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_notificacion_silence", x => x.id);
                    table.ForeignKey(
                        name: "NOTIFICACION_SILENCE_APPUSER_FK",
                        column: x => x.user_id,
                        principalTable: "app_user",
                        principalColumn: "id");
                    table.ForeignKey(
                        name: "NOTIFICACION_SILENCE_APPUSER_SILENCE_FK",
                        column: x => x.user_silence_id,
                        principalTable: "app_user",
                        principalColumn: "id");
                });

            migrationBuilder.CreateTable(
                name: "oferta",
                columns: table => new
                {
                    id = table.Column<Guid>(type: "uniqueidentifier", nullable: false),
                    titulo = table.Column<string>(type: "Varchar (50)", nullable: false),
                    tipo_id = table.Column<Guid>(type: "uniqueidentifier", nullable: false),
                    tipo_otro = table.Column<string>(type: "Varchar (100)", nullable: true),
                    tema_otro = table.Column<string>(type: "Varchar (100)", nullable: true),
                    modalidad_id = table.Column<Guid>(type: "uniqueidentifier", nullable: false),
                    tiempo_id = table.Column<Guid>(type: "uniqueidentifier", nullable: false),
                    contenido = table.Column<string>(type: "Varchar (500)", nullable: false),
                    existe_requisito_previo = table.Column<bool>(type: "bit", nullable: false),
                    requisito_previo_cuales = table.Column<string>(type: "Varchar (500)", nullable: true),
                    url = table.Column<string>(type: "Varchar (500)", nullable: true),
                    etiquetas = table.Column<string>(type: "Varchar (1000)", nullable: true),
                    nombre_contacto = table.Column<string>(type: "Varchar (200)", nullable: true),
                    dependencia_contacto = table.Column<string>(type: "Varchar (100)", nullable: true),
                    correo_contacto = table.Column<string>(type: "Varchar (100)", nullable: true),
                    Indicativo_celular_contacto = table.Column<string>(type: "Varchar (10)", nullable: true),
                    Numero_celular_contacto = table.Column<string>(type: "Varchar (10)", nullable: true),
                    esta_interesado_conocer_ofertas = table.Column<bool>(type: "bit", nullable: false),
                    AppFilePortadaId = table.Column<Guid>(type: "uniqueidentifier", nullable: false),
                    urlVideo = table.Column<string>(type: "Varchar (500)", nullable: true),
                    ocultar = table.Column<bool>(type: "bit", nullable: false),
                    fecha_creacion = table.Column<DateTime>(type: "datetime2", nullable: false),
                    fecha_actualizacion = table.Column<DateTime>(type: "datetime2", nullable: false),
                    user_id = table.Column<Guid>(type: "uniqueidentifier", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_oferta", x => x.id);
                    table.ForeignKey(
                        name: "OFERTA_APPUSER_FK",
                        column: x => x.user_id,
                        principalTable: "app_user",
                        principalColumn: "id");
                    table.ForeignKey(
                        name: "OFERTA_LISTAITEMTIEMPO_FK",
                        column: x => x.tiempo_id,
                        principalTable: "listas_community",
                        principalColumn: "id");
                    table.ForeignKey(
                        name: "OFERTA_LISTAITEMTIPO_FK",
                        column: x => x.tipo_id,
                        principalTable: "listas_community",
                        principalColumn: "id");
                    table.ForeignKey(
                        name: "OFERTA_PORTADA_FILE_OFERTA_FK",
                        column: x => x.AppFilePortadaId,
                        principalTable: "AppFiles",
                        principalColumn: "id");
                });

            migrationBuilder.CreateTable(
                name: "perfil_etiqueta",
                columns: table => new
                {
                    id = table.Column<Guid>(type: "uniqueidentifier", nullable: false),
                    user_id = table.Column<Guid>(type: "uniqueidentifier", nullable: true),
                    listaitem_id = table.Column<Guid>(type: "uniqueidentifier", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_perfil_etiqueta", x => x.id);
                    table.ForeignKey(
                        name: "APPUSER_ETIQUETAS_FK",
                        column: x => x.user_id,
                        principalTable: "app_user",
                        principalColumn: "id");
                    table.ForeignKey(
                        name: "LISTA_ETIQUETAS_Etiqueta_FK",
                        column: x => x.listaitem_id,
                        principalTable: "listas_community",
                        principalColumn: "id");
                });

            migrationBuilder.CreateTable(
                name: "publicacion",
                columns: table => new
                {
                    id = table.Column<Guid>(type: "uniqueidentifier", nullable: false),
                    descripcion = table.Column<string>(type: "nvarchar(500)", nullable: false),
                    fecha_creacion = table.Column<DateTime>(type: "datetime2", nullable: false),
                    fecha_actualizacion = table.Column<DateTime>(type: "datetime2", nullable: false),
                    user_id = table.Column<Guid>(type: "uniqueidentifier", nullable: true),
                    fecha_eliminacion = table.Column<DateTime>(type: "datetime2", nullable: true),
                    UrlGif = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    compartir_id = table.Column<Guid>(type: "uniqueidentifier", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_publicacion", x => x.id);
                    table.ForeignKey(
                        name: "LISTA_PUBLICACIONES_APPUSER_FK",
                        column: x => x.user_id,
                        principalTable: "app_user",
                        principalColumn: "id");
                    table.ForeignKey(
                        name: "PUBLICACION_COMPARTIR_FK",
                        column: x => x.compartir_id,
                        principalTable: "publicacion",
                        principalColumn: "id");
                });

            migrationBuilder.CreateTable(
                name: "UsuariosConectadosChat",
                columns: table => new
                {
                    id = table.Column<Guid>(type: "uniqueidentifier", nullable: false),
                    user_id = table.Column<Guid>(type: "uniqueidentifier", nullable: true),
                    SocketId = table.Column<string>(type: "nvarchar(max)", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_UsuariosConectadosChat", x => x.id);
                    table.ForeignKey(
                        name: "USUARIOCONECTADO_APPUSER_FK",
                        column: x => x.user_id,
                        principalTable: "app_user",
                        principalColumn: "id");
                });

            migrationBuilder.CreateTable(
                name: "Conversacion_Union",
                columns: table => new
                {
                    id = table.Column<Guid>(type: "uniqueidentifier", nullable: false),
                    IdSender = table.Column<Guid>(type: "uniqueidentifier", nullable: false),
                    IdReceptor = table.Column<Guid>(type: "uniqueidentifier", nullable: false),
                    fecha_creacion = table.Column<DateTime>(type: "datetime2", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Conversacion_Union", x => x.id);
                    table.ForeignKey(
                        name: "CONVERSACIONUNION_CONVERSACIONRECEPTOR_FK",
                        column: x => x.IdReceptor,
                        principalTable: "Conversacion",
                        principalColumn: "id");
                    table.ForeignKey(
                        name: "CONVERSACIONUNION_CONVERSACIONSENDER_FK",
                        column: x => x.IdSender,
                        principalTable: "Conversacion",
                        principalColumn: "id");
                });

            migrationBuilder.CreateTable(
                name: "experiencia_poblacion",
                columns: table => new
                {
                    id = table.Column<Guid>(type: "uniqueidentifier", nullable: false),
                    poblacion_id = table.Column<Guid>(type: "uniqueidentifier", nullable: false),
                    ListaItemPoblacionId = table.Column<Guid>(type: "uniqueidentifier", nullable: false),
                    fecha_creacion = table.Column<DateTime>(type: "datetime2", nullable: false),
                    experiencia_id = table.Column<Guid>(type: "uniqueidentifier", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_experiencia_poblacion", x => x.id);
                    table.ForeignKey(
                        name: "EXPERIENCIA_POBLACION_EXPERIENCIA_FK",
                        column: x => x.experiencia_id,
                        principalTable: "experiencia",
                        principalColumn: "id");
                    table.ForeignKey(
                        name: "FK_experiencia_poblacion_listas_community_ListaItemPoblacionId",
                        column: x => x.ListaItemPoblacionId,
                        principalTable: "listas_community",
                        principalColumn: "id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "experiencia_tema",
                columns: table => new
                {
                    id = table.Column<Guid>(type: "uniqueidentifier", nullable: false),
                    tema_id = table.Column<Guid>(type: "uniqueidentifier", nullable: false),
                    ListaItemTemaId = table.Column<Guid>(type: "uniqueidentifier", nullable: false),
                    fecha_creacion = table.Column<DateTime>(type: "datetime2", nullable: false),
                    experiencia_id = table.Column<Guid>(type: "uniqueidentifier", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_experiencia_tema", x => x.id);
                    table.ForeignKey(
                        name: "EXPERIENCIA_TEMA_EXPERIENCIA_FK",
                        column: x => x.experiencia_id,
                        principalTable: "experiencia",
                        principalColumn: "id");
                    table.ForeignKey(
                        name: "FK_experiencia_tema_listas_community_ListaItemTemaId",
                        column: x => x.ListaItemTemaId,
                        principalTable: "listas_community",
                        principalColumn: "id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "experiencia_herramienta",
                columns: table => new
                {
                    id = table.Column<Guid>(type: "uniqueidentifier", nullable: false),
                    herramienta_id = table.Column<Guid>(type: "uniqueidentifier", nullable: false),
                    HerramientaExperienciaId = table.Column<Guid>(type: "uniqueidentifier", nullable: false),
                    fecha_creacion = table.Column<DateTime>(type: "datetime2", nullable: false),
                    experiencia_id = table.Column<Guid>(type: "uniqueidentifier", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_experiencia_herramienta", x => x.id);
                    table.ForeignKey(
                        name: "EXPERIENCIA_HERRAMIENTA_EXPERIENCIA_FK",
                        column: x => x.experiencia_id,
                        principalTable: "experiencia",
                        principalColumn: "id");
                    table.ForeignKey(
                        name: "FK_experiencia_herramienta_Herramienta_HerramientaExperienciaId",
                        column: x => x.HerramientaExperienciaId,
                        principalTable: "Herramienta",
                        principalColumn: "id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "Herramienta_Equipo",
                columns: table => new
                {
                    id = table.Column<Guid>(type: "uniqueidentifier", nullable: false),
                    tool_id = table.Column<Guid>(type: "uniqueidentifier", nullable: false),
                    equipo_id = table.Column<Guid>(type: "uniqueidentifier", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Herramienta_Equipo", x => x.id);
                    table.ForeignKey(
                        name: "LISTA_Tool_Equipo_FK",
                        column: x => x.equipo_id,
                        principalTable: "listas_community",
                        principalColumn: "id");
                    table.ForeignKey(
                        name: "Tool_Equipo_FK",
                        column: x => x.tool_id,
                        principalTable: "Herramienta",
                        principalColumn: "id");
                });

            migrationBuilder.CreateTable(
                name: "Herramienta_Fases",
                columns: table => new
                {
                    id = table.Column<Guid>(type: "uniqueidentifier", nullable: false),
                    tool_id = table.Column<Guid>(type: "uniqueidentifier", nullable: false),
                    fases_id = table.Column<Guid>(type: "uniqueidentifier", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Herramienta_Fases", x => x.id);
                    table.ForeignKey(
                        name: "LISTA_Tool_Fase_FK",
                        column: x => x.fases_id,
                        principalTable: "listas_community",
                        principalColumn: "id");
                    table.ForeignKey(
                        name: "Tool_Fase_FK",
                        column: x => x.tool_id,
                        principalTable: "Herramienta",
                        principalColumn: "id");
                });

            migrationBuilder.CreateTable(
                name: "Herramienta_Tareas",
                columns: table => new
                {
                    id = table.Column<Guid>(type: "uniqueidentifier", nullable: false),
                    tool_id = table.Column<Guid>(type: "uniqueidentifier", nullable: false),
                    tareas_id = table.Column<Guid>(type: "uniqueidentifier", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Herramienta_Tareas", x => x.id);
                    table.ForeignKey(
                        name: "LISTA_Tool_Tarea_FK",
                        column: x => x.tareas_id,
                        principalTable: "listas_community",
                        principalColumn: "id");
                    table.ForeignKey(
                        name: "Tool_Tarea_FK",
                        column: x => x.tool_id,
                        principalTable: "Herramienta",
                        principalColumn: "id");
                });

            migrationBuilder.CreateTable(
                name: "oferta_dirigido_a",
                columns: table => new
                {
                    id = table.Column<Guid>(type: "uniqueidentifier", nullable: false),
                    dirigido_a_id = table.Column<Guid>(type: "uniqueidentifier", nullable: false),
                    fecha_creacion = table.Column<DateTime>(type: "datetime2", nullable: false),
                    oferta_id = table.Column<Guid>(type: "uniqueidentifier", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_oferta_dirigido_a", x => x.id);
                    table.ForeignKey(
                        name: "OFERTA_DIRIGIDO_A_OFERTA_FK",
                        column: x => x.oferta_id,
                        principalTable: "oferta",
                        principalColumn: "id");
                    table.ForeignKey(
                        name: "OFERTA_LISTAITEMDIRIGIDOA_FK",
                        column: x => x.dirigido_a_id,
                        principalTable: "listas_community",
                        principalColumn: "id");
                });

            migrationBuilder.CreateTable(
                name: "oferta_file",
                columns: table => new
                {
                    id = table.Column<Guid>(type: "uniqueidentifier", nullable: false),
                    fecha_creacion = table.Column<DateTime>(type: "datetime2", nullable: false),
                    oferta_id = table.Column<Guid>(type: "uniqueidentifier", nullable: false),
                    appfile_id = table.Column<Guid>(type: "uniqueidentifier", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_oferta_file", x => x.id);
                    table.ForeignKey(
                        name: "OFERTA_FILE_APPFILE_FK",
                        column: x => x.appfile_id,
                        principalTable: "AppFiles",
                        principalColumn: "id");
                    table.ForeignKey(
                        name: "OFERTA_FILE_OFERTA_FK",
                        column: x => x.oferta_id,
                        principalTable: "oferta",
                        principalColumn: "id");
                });

            migrationBuilder.CreateTable(
                name: "oferta_modulo",
                columns: table => new
                {
                    id = table.Column<Guid>(type: "uniqueidentifier", nullable: false),
                    Descripcion = table.Column<string>(type: "Varchar (400)", nullable: false),
                    fecha_creacion = table.Column<DateTime>(type: "datetime2", nullable: false),
                    oferta_id = table.Column<Guid>(type: "uniqueidentifier", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_oferta_modulo", x => x.id);
                    table.ForeignKey(
                        name: "OFERTA_MODULO_OFERTA_FK",
                        column: x => x.oferta_id,
                        principalTable: "oferta",
                        principalColumn: "id");
                });

            migrationBuilder.CreateTable(
                name: "oferta_tema",
                columns: table => new
                {
                    id = table.Column<Guid>(type: "uniqueidentifier", nullable: false),
                    tema_id = table.Column<Guid>(type: "uniqueidentifier", nullable: false),
                    fecha_creacion = table.Column<DateTime>(type: "datetime2", nullable: false),
                    oferta_id = table.Column<Guid>(type: "uniqueidentifier", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_oferta_tema", x => x.id);
                    table.ForeignKey(
                        name: "OFERTA_LISTAITEMTEMA_FK",
                        column: x => x.tema_id,
                        principalTable: "listas_community",
                        principalColumn: "id");
                    table.ForeignKey(
                        name: "OFERTA_TEMA_OFERTA_FK",
                        column: x => x.oferta_id,
                        principalTable: "oferta",
                        principalColumn: "id");
                });

            migrationBuilder.CreateTable(
                name: "notificacion_disabled",
                columns: table => new
                {
                    id = table.Column<Guid>(type: "uniqueidentifier", nullable: false),
                    fecha_creacion = table.Column<DateTime>(type: "datetime2", nullable: false),
                    user_id = table.Column<Guid>(type: "uniqueidentifier", nullable: false),
                    publicacion_id = table.Column<Guid>(type: "uniqueidentifier", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_notificacion_disabled", x => x.id);
                    table.ForeignKey(
                        name: "NOTIFICACION_DISABLED_APPUSER_FK",
                        column: x => x.user_id,
                        principalTable: "app_user",
                        principalColumn: "id");
                    table.ForeignKey(
                        name: "NOTIFICACION_DISABLED_PUBLICACION_FK",
                        column: x => x.publicacion_id,
                        principalTable: "publicacion",
                        principalColumn: "id");
                });

            migrationBuilder.CreateTable(
                name: "publicacion_comentario",
                columns: table => new
                {
                    id = table.Column<Guid>(type: "uniqueidentifier", nullable: false),
                    descripcion = table.Column<string>(type: "nvarchar(500)", nullable: false),
                    padre_id = table.Column<Guid>(type: "uniqueidentifier", nullable: true),
                    fecha_creacion = table.Column<DateTime>(type: "datetime2", nullable: false),
                    fecha_actualizacion = table.Column<DateTime>(type: "datetime2", nullable: false),
                    user_id = table.Column<Guid>(type: "uniqueidentifier", nullable: true),
                    publicacion_id = table.Column<Guid>(type: "uniqueidentifier", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_publicacion_comentario", x => x.id);
                    table.ForeignKey(
                        name: "COMENTARIO_PADRE_FK",
                        column: x => x.padre_id,
                        principalTable: "publicacion_comentario",
                        principalColumn: "id");
                    table.ForeignKey(
                        name: "LISTA_COMENTARIOS_APPUSER_FK",
                        column: x => x.user_id,
                        principalTable: "app_user",
                        principalColumn: "id");
                    table.ForeignKey(
                        name: "LISTA_COMENTARIOS_PUBLICACION_FK",
                        column: x => x.publicacion_id,
                        principalTable: "publicacion",
                        principalColumn: "id");
                });

            migrationBuilder.CreateTable(
                name: "publicacion_file",
                columns: table => new
                {
                    id = table.Column<Guid>(type: "uniqueidentifier", nullable: false),
                    fecha_creacion = table.Column<DateTime>(type: "datetime2", nullable: false),
                    publicacion_id = table.Column<Guid>(type: "uniqueidentifier", nullable: false),
                    appfile_id = table.Column<Guid>(type: "uniqueidentifier", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_publicacion_file", x => x.id);
                    table.ForeignKey(
                        name: "LISTA_PUBLICACION_FILE_APPFILE_FK",
                        column: x => x.appfile_id,
                        principalTable: "AppFiles",
                        principalColumn: "id");
                    table.ForeignKey(
                        name: "LISTA_PUBLICACION_FILE_PUBLICACION_FK",
                        column: x => x.publicacion_id,
                        principalTable: "publicacion",
                        principalColumn: "id");
                });

            migrationBuilder.CreateTable(
                name: "publicacion_ocultar",
                columns: table => new
                {
                    id = table.Column<Guid>(type: "uniqueidentifier", nullable: false),
                    fecha_creacion = table.Column<DateTime>(type: "datetime2", nullable: false),
                    AppUserId = table.Column<Guid>(type: "uniqueidentifier", nullable: true),
                    publicacion_id = table.Column<Guid>(type: "uniqueidentifier", nullable: false),
                    listaitem_id = table.Column<Guid>(type: "uniqueidentifier", nullable: true),
                    Otro = table.Column<string>(type: "nvarchar(max)", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_publicacion_ocultar", x => x.id);
                    table.ForeignKey(
                        name: "LISTA_PUBLICACION_OCULTAR_APPUSER_FK",
                        column: x => x.AppUserId,
                        principalTable: "app_user",
                        principalColumn: "id");
                    table.ForeignKey(
                        name: "LISTA_PUBLICACION_OCULTAR_LISTAITEM_FK",
                        column: x => x.listaitem_id,
                        principalTable: "listas_community",
                        principalColumn: "id");
                    table.ForeignKey(
                        name: "LISTA_PUBLICACION_OCULTAR_PUBLICACION_FK",
                        column: x => x.publicacion_id,
                        principalTable: "publicacion",
                        principalColumn: "id");
                });

            migrationBuilder.CreateTable(
                name: "publicacion_reportar",
                columns: table => new
                {
                    id = table.Column<Guid>(type: "uniqueidentifier", nullable: false),
                    fecha_creacion = table.Column<DateTime>(type: "datetime2", nullable: false),
                    AppUserId = table.Column<Guid>(type: "uniqueidentifier", nullable: true),
                    publicacion_id = table.Column<Guid>(type: "uniqueidentifier", nullable: false),
                    listaitem_id = table.Column<Guid>(type: "uniqueidentifier", nullable: true),
                    Otro = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    Aprobacion = table.Column<int>(type: "int", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_publicacion_reportar", x => x.id);
                    table.ForeignKey(
                        name: "FK_publicacion_reportar_listas_community_listaitem_id",
                        column: x => x.listaitem_id,
                        principalTable: "listas_community",
                        principalColumn: "id",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "LISTA_PUBLICACION_REPORTAR_APPUSER_FK",
                        column: x => x.AppUserId,
                        principalTable: "app_user",
                        principalColumn: "id");
                    table.ForeignKey(
                        name: "LISTA_PUBLICACION_REPORTAR_PUBLICACION_FK",
                        column: x => x.publicacion_id,
                        principalTable: "publicacion",
                        principalColumn: "id");
                });

            migrationBuilder.CreateTable(
                name: "ConversacionesConectadas",
                columns: table => new
                {
                    id = table.Column<Guid>(type: "uniqueidentifier", nullable: false),
                    conversacion_id = table.Column<Guid>(type: "uniqueidentifier", nullable: false),
                    AppUserId = table.Column<Guid>(type: "uniqueidentifier", nullable: true),
                    SocketId = table.Column<string>(type: "nvarchar(max)", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_ConversacionesConectadas", x => x.id);
                    table.ForeignKey(
                        name: "CONVERSACIONCONECTADO_CONVERSACION_FK",
                        column: x => x.conversacion_id,
                        principalTable: "Conversacion_Union",
                        principalColumn: "id");
                    table.ForeignKey(
                        name: "CONVERSACIONCONECTADO_USUARIOS_FK",
                        column: x => x.AppUserId,
                        principalTable: "app_user",
                        principalColumn: "id");
                });

            migrationBuilder.CreateTable(
                name: "Mensaje",
                columns: table => new
                {
                    id = table.Column<Guid>(type: "uniqueidentifier", nullable: false),
                    mensaje = table.Column<string>(type: "nvarchar(500)", nullable: false),
                    fecha_creacion = table.Column<DateTime>(type: "datetime2", nullable: false),
                    user_id = table.Column<Guid>(type: "uniqueidentifier", nullable: true),
                    conversacion_id = table.Column<Guid>(type: "uniqueidentifier", nullable: false),
                    leido = table.Column<bool>(type: "bit", nullable: false),
                    UrlGif = table.Column<string>(type: "nvarchar(max)", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Mensaje", x => x.id);
                    table.ForeignKey(
                        name: "MENSAJES_APPUSER_FK",
                        column: x => x.user_id,
                        principalTable: "app_user",
                        principalColumn: "id");
                    table.ForeignKey(
                        name: "MENSAJES_CONVERSACION_FK",
                        column: x => x.conversacion_id,
                        principalTable: "Conversacion_Union",
                        principalColumn: "id");
                });

            migrationBuilder.CreateTable(
                name: "iteracion",
                columns: table => new
                {
                    id = table.Column<Guid>(type: "uniqueidentifier", nullable: false),
                    fecha_creacion = table.Column<DateTime>(type: "datetime2", nullable: false),
                    AppUserId = table.Column<Guid>(type: "uniqueidentifier", nullable: true),
                    publicacion_id = table.Column<Guid>(type: "uniqueidentifier", nullable: true),
                    comentario_id = table.Column<Guid>(type: "uniqueidentifier", nullable: true),
                    listaitem_id = table.Column<Guid>(type: "uniqueidentifier", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_iteracion", x => x.id);
                    table.ForeignKey(
                        name: "LISTA_ITERACION_APPUSER_FK",
                        column: x => x.AppUserId,
                        principalTable: "app_user",
                        principalColumn: "id");
                    table.ForeignKey(
                        name: "LISTA_ITERACION_COMENTARIO_FK",
                        column: x => x.comentario_id,
                        principalTable: "publicacion_comentario",
                        principalColumn: "id");
                    table.ForeignKey(
                        name: "LISTA_ITERACION_LISTAITEM_FK",
                        column: x => x.listaitem_id,
                        principalTable: "listas_community",
                        principalColumn: "id");
                    table.ForeignKey(
                        name: "LISTA_ITERACION_PUBLICACION_FK",
                        column: x => x.publicacion_id,
                        principalTable: "publicacion",
                        principalColumn: "id");
                });

            migrationBuilder.CreateTable(
                name: "mensaje_file",
                columns: table => new
                {
                    id = table.Column<Guid>(type: "uniqueidentifier", nullable: false),
                    fecha_creacion = table.Column<DateTime>(type: "datetime2", nullable: false),
                    mensaje_id = table.Column<Guid>(type: "uniqueidentifier", nullable: false),
                    appfile_id = table.Column<Guid>(type: "uniqueidentifier", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_mensaje_file", x => x.id);
                    table.ForeignKey(
                        name: "MENSAJE_FILE_APPFILE_FK",
                        column: x => x.appfile_id,
                        principalTable: "AppFiles",
                        principalColumn: "id");
                    table.ForeignKey(
                        name: "MENSAJES_FILE_MENSAJES_FK",
                        column: x => x.mensaje_id,
                        principalTable: "Mensaje",
                        principalColumn: "id");
                });

            migrationBuilder.CreateTable(
                name: "notificacion",
                columns: table => new
                {
                    id = table.Column<Guid>(type: "uniqueidentifier", nullable: false),
                    fecha_creacion = table.Column<DateTime>(type: "datetime2", nullable: false),
                    user_id = table.Column<Guid>(type: "uniqueidentifier", nullable: false),
                    user_origen_id = table.Column<Guid>(type: "uniqueidentifier", nullable: false),
                    descripcion = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    enlace = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    publicacion_id = table.Column<Guid>(type: "uniqueidentifier", nullable: true),
                    iteracion_id = table.Column<Guid>(type: "uniqueidentifier", nullable: true),
                    activa = table.Column<bool>(type: "bit", nullable: false, defaultValue: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_notificacion", x => x.id);
                    table.ForeignKey(
                        name: "NOTIFICACION_APPUSER_DESTINO_FK",
                        column: x => x.user_id,
                        principalTable: "app_user",
                        principalColumn: "id");
                    table.ForeignKey(
                        name: "NOTIFICACION_APPUSER_ORIGEN_FK",
                        column: x => x.user_origen_id,
                        principalTable: "app_user",
                        principalColumn: "id");
                    table.ForeignKey(
                        name: "NOTIFICACION_ITERACION_FK",
                        column: x => x.iteracion_id,
                        principalTable: "iteracion",
                        principalColumn: "id");
                    table.ForeignKey(
                        name: "NOTIFICACION_PUBLICACION_FK",
                        column: x => x.publicacion_id,
                        principalTable: "publicacion",
                        principalColumn: "id");
                });

            migrationBuilder.CreateIndex(
                name: "IX_app_user_app_file_id",
                table: "app_user",
                column: "app_file_id");

            migrationBuilder.CreateIndex(
                name: "IX_app_user_area_direccion_equipo_id",
                table: "app_user",
                column: "area_direccion_equipo_id");

            migrationBuilder.CreateIndex(
                name: "IX_app_user_area_direccion_equipo_id1",
                table: "app_user",
                column: "area_direccion_equipo_id1");

            migrationBuilder.CreateIndex(
                name: "IX_app_user_cargoactual_id",
                table: "app_user",
                column: "cargoactual_id");

            migrationBuilder.CreateIndex(
                name: "IX_app_user_departamento_id",
                table: "app_user",
                column: "departamento_id");

            migrationBuilder.CreateIndex(
                name: "IX_app_user_entidad_id",
                table: "app_user",
                column: "entidad_id");

            migrationBuilder.CreateIndex(
                name: "IX_app_user_equipo_id",
                table: "app_user",
                column: "equipo_id");

            migrationBuilder.CreateIndex(
                name: "IX_app_user_genero_id",
                table: "app_user",
                column: "genero_id");

            migrationBuilder.CreateIndex(
                name: "IX_app_user_IndicativoId",
                table: "app_user",
                column: "IndicativoId");

            migrationBuilder.CreateIndex(
                name: "IX_app_user_motivo_eliminacion_id",
                table: "app_user",
                column: "motivo_eliminacion_id");

            migrationBuilder.CreateIndex(
                name: "IX_app_user_municipio_id",
                table: "app_user",
                column: "municipio_id");

            migrationBuilder.CreateIndex(
                name: "IX_app_user_nivel_id",
                table: "app_user",
                column: "nivel_id");

            migrationBuilder.CreateIndex(
                name: "IX_app_user_orden_id",
                table: "app_user",
                column: "orden_id");

            migrationBuilder.CreateIndex(
                name: "IX_app_user_organizacion_id",
                table: "app_user",
                column: "organizacion_id");

            migrationBuilder.CreateIndex(
                name: "IX_app_user_pais_id",
                table: "app_user",
                column: "pais_id");

            migrationBuilder.CreateIndex(
                name: "IX_app_user_PreguntaConectaId",
                table: "app_user",
                column: "PreguntaConectaId");

            migrationBuilder.CreateIndex(
                name: "IX_app_user_profesion_id",
                table: "app_user",
                column: "profesion_id");

            migrationBuilder.CreateIndex(
                name: "IX_app_user_proyecto_actual_id",
                table: "app_user",
                column: "proyecto_actual_id");

            migrationBuilder.CreateIndex(
                name: "IX_app_user_proyecto_destacado_id",
                table: "app_user",
                column: "proyecto_destacado_id");

            migrationBuilder.CreateIndex(
                name: "IX_app_user_sector_id",
                table: "app_user",
                column: "sector_id");

            migrationBuilder.CreateIndex(
                name: "IX_ChatBot_Llave",
                table: "ChatBot",
                column: "Llave",
                unique: true);

            migrationBuilder.CreateIndex(
                name: "IX_contacto_contacto_id",
                table: "contacto",
                column: "contacto_id");

            migrationBuilder.CreateIndex(
                name: "IX_contacto_respuesta_contacto_id",
                table: "contacto",
                column: "respuesta_contacto_id");

            migrationBuilder.CreateIndex(
                name: "IX_contacto_user_id",
                table: "contacto",
                column: "user_id");

            migrationBuilder.CreateIndex(
                name: "IX_Conversacion_user_receptor_id",
                table: "Conversacion",
                column: "user_receptor_id");

            migrationBuilder.CreateIndex(
                name: "IX_Conversacion_user_sender_id",
                table: "Conversacion",
                column: "user_sender_id");

            migrationBuilder.CreateIndex(
                name: "IX_Conversacion_Union_IdReceptor",
                table: "Conversacion_Union",
                column: "IdReceptor");

            migrationBuilder.CreateIndex(
                name: "IX_Conversacion_Union_IdSender",
                table: "Conversacion_Union",
                column: "IdSender");

            migrationBuilder.CreateIndex(
                name: "IX_ConversacionesConectadas_AppUserId",
                table: "ConversacionesConectadas",
                column: "AppUserId");

            migrationBuilder.CreateIndex(
                name: "IX_ConversacionesConectadas_conversacion_id",
                table: "ConversacionesConectadas",
                column: "conversacion_id");

            migrationBuilder.CreateIndex(
                name: "IX_DocumentoRetos_RetoId",
                table: "DocumentoRetos",
                column: "RetoId");

            migrationBuilder.CreateIndex(
                name: "IX_entidad_app_file_id",
                table: "entidad",
                column: "app_file_id");

            migrationBuilder.CreateIndex(
                name: "IX_entidad_ciudad_id",
                table: "entidad",
                column: "ciudad_id");

            migrationBuilder.CreateIndex(
                name: "IX_entidad_orden_id",
                table: "entidad",
                column: "orden_id");

            migrationBuilder.CreateIndex(
                name: "IX_entidad_sector_id",
                table: "entidad",
                column: "sector_id");

            migrationBuilder.CreateIndex(
                name: "IX_EntidadRetos_RetoId",
                table: "EntidadRetos",
                column: "RetoId");

            migrationBuilder.CreateIndex(
                name: "IX_equipo_app_file_id",
                table: "equipo",
                column: "app_file_id");

            migrationBuilder.CreateIndex(
                name: "IX_equipo_ciudad_id",
                table: "equipo",
                column: "ciudad_id");

            migrationBuilder.CreateIndex(
                name: "IX_equipo_entidad_id",
                table: "equipo",
                column: "entidad_id");

            migrationBuilder.CreateIndex(
                name: "IX_equipo_orden_id",
                table: "equipo",
                column: "orden_id");

            migrationBuilder.CreateIndex(
                name: "IX_EtapaRetos_RetoId",
                table: "EtapaRetos",
                column: "RetoId");

            migrationBuilder.CreateIndex(
                name: "IX_experiencia_AppFileDocumentoId",
                table: "experiencia",
                column: "AppFileDocumentoId");

            migrationBuilder.CreateIndex(
                name: "IX_experiencia_AppFilePortadaId",
                table: "experiencia",
                column: "AppFilePortadaId");

            migrationBuilder.CreateIndex(
                name: "IX_experiencia_escala_id",
                table: "experiencia",
                column: "escala_id");

            migrationBuilder.CreateIndex(
                name: "IX_experiencia_user_id",
                table: "experiencia",
                column: "user_id");

            migrationBuilder.CreateIndex(
                name: "IX_experiencia_herramienta_experiencia_id",
                table: "experiencia_herramienta",
                column: "experiencia_id");

            migrationBuilder.CreateIndex(
                name: "IX_experiencia_herramienta_HerramientaExperienciaId",
                table: "experiencia_herramienta",
                column: "HerramientaExperienciaId");

            migrationBuilder.CreateIndex(
                name: "IX_experiencia_poblacion_experiencia_id",
                table: "experiencia_poblacion",
                column: "experiencia_id");

            migrationBuilder.CreateIndex(
                name: "IX_experiencia_poblacion_ListaItemPoblacionId",
                table: "experiencia_poblacion",
                column: "ListaItemPoblacionId");

            migrationBuilder.CreateIndex(
                name: "IX_experiencia_tema_experiencia_id",
                table: "experiencia_tema",
                column: "experiencia_id");

            migrationBuilder.CreateIndex(
                name: "IX_experiencia_tema_ListaItemTemaId",
                table: "experiencia_tema",
                column: "ListaItemTemaId");

            migrationBuilder.CreateIndex(
                name: "IX_Herramienta_idImgPortada",
                table: "Herramienta",
                column: "idImgPortada");

            migrationBuilder.CreateIndex(
                name: "IX_Herramienta_idPdfArchivo",
                table: "Herramienta",
                column: "idPdfArchivo");

            migrationBuilder.CreateIndex(
                name: "IX_Herramienta_tipo_herramienta",
                table: "Herramienta",
                column: "tipo_herramienta");

            migrationBuilder.CreateIndex(
                name: "IX_Herramienta_tipo_recurso_id",
                table: "Herramienta",
                column: "tipo_recurso_id");

            migrationBuilder.CreateIndex(
                name: "IX_Herramienta_user_id",
                table: "Herramienta",
                column: "user_id");

            migrationBuilder.CreateIndex(
                name: "IX_Herramienta_Equipo_equipo_id",
                table: "Herramienta_Equipo",
                column: "equipo_id");

            migrationBuilder.CreateIndex(
                name: "IX_Herramienta_Equipo_tool_id",
                table: "Herramienta_Equipo",
                column: "tool_id");

            migrationBuilder.CreateIndex(
                name: "IX_Herramienta_Fases_fases_id",
                table: "Herramienta_Fases",
                column: "fases_id");

            migrationBuilder.CreateIndex(
                name: "IX_Herramienta_Fases_tool_id",
                table: "Herramienta_Fases",
                column: "tool_id");

            migrationBuilder.CreateIndex(
                name: "IX_Herramienta_Tareas_tareas_id",
                table: "Herramienta_Tareas",
                column: "tareas_id");

            migrationBuilder.CreateIndex(
                name: "IX_Herramienta_Tareas_tool_id",
                table: "Herramienta_Tareas",
                column: "tool_id");

            migrationBuilder.CreateIndex(
                name: "IX_IncentivoRetos_RetoId",
                table: "IncentivoRetos",
                column: "RetoId");

            migrationBuilder.CreateIndex(
                name: "IX_Intereses_listaitem_id",
                table: "Intereses",
                column: "listaitem_id");

            migrationBuilder.CreateIndex(
                name: "IX_Intereses_user_id",
                table: "Intereses",
                column: "user_id");

            migrationBuilder.CreateIndex(
                name: "IX_iteracion_AppUserId",
                table: "iteracion",
                column: "AppUserId");

            migrationBuilder.CreateIndex(
                name: "IX_iteracion_comentario_id",
                table: "iteracion",
                column: "comentario_id");

            migrationBuilder.CreateIndex(
                name: "IX_iteracion_listaitem_id",
                table: "iteracion",
                column: "listaitem_id");

            migrationBuilder.CreateIndex(
                name: "IX_iteracion_publicacion_id",
                table: "iteracion",
                column: "publicacion_id");

            migrationBuilder.CreateIndex(
                name: "IX_listas_community_codigo",
                table: "listas_community",
                column: "codigo",
                unique: true);

            migrationBuilder.CreateIndex(
                name: "IX_listas_community_padre_id",
                table: "listas_community",
                column: "padre_id");

            migrationBuilder.CreateIndex(
                name: "IX_Mensaje_conversacion_id",
                table: "Mensaje",
                column: "conversacion_id");

            migrationBuilder.CreateIndex(
                name: "IX_Mensaje_user_id",
                table: "Mensaje",
                column: "user_id");

            migrationBuilder.CreateIndex(
                name: "IX_mensaje_file_appfile_id",
                table: "mensaje_file",
                column: "appfile_id");

            migrationBuilder.CreateIndex(
                name: "IX_mensaje_file_mensaje_id",
                table: "mensaje_file",
                column: "mensaje_id");

            migrationBuilder.CreateIndex(
                name: "IX_notificacion_iteracion_id",
                table: "notificacion",
                column: "iteracion_id");

            migrationBuilder.CreateIndex(
                name: "IX_notificacion_publicacion_id",
                table: "notificacion",
                column: "publicacion_id");

            migrationBuilder.CreateIndex(
                name: "IX_notificacion_user_id",
                table: "notificacion",
                column: "user_id");

            migrationBuilder.CreateIndex(
                name: "IX_notificacion_user_origen_id",
                table: "notificacion",
                column: "user_origen_id");

            migrationBuilder.CreateIndex(
                name: "IX_notificacion_disabled_publicacion_id",
                table: "notificacion_disabled",
                column: "publicacion_id");

            migrationBuilder.CreateIndex(
                name: "IX_notificacion_disabled_user_id",
                table: "notificacion_disabled",
                column: "user_id");

            migrationBuilder.CreateIndex(
                name: "IX_notificacion_silence_user_id",
                table: "notificacion_silence",
                column: "user_id");

            migrationBuilder.CreateIndex(
                name: "IX_notificacion_silence_user_silence_id",
                table: "notificacion_silence",
                column: "user_silence_id");

            migrationBuilder.CreateIndex(
                name: "IX_oferta_AppFilePortadaId",
                table: "oferta",
                column: "AppFilePortadaId");

            migrationBuilder.CreateIndex(
                name: "IX_oferta_tiempo_id",
                table: "oferta",
                column: "tiempo_id");

            migrationBuilder.CreateIndex(
                name: "IX_oferta_tipo_id",
                table: "oferta",
                column: "tipo_id");

            migrationBuilder.CreateIndex(
                name: "IX_oferta_user_id",
                table: "oferta",
                column: "user_id");

            migrationBuilder.CreateIndex(
                name: "IX_oferta_dirigido_a_dirigido_a_id",
                table: "oferta_dirigido_a",
                column: "dirigido_a_id");

            migrationBuilder.CreateIndex(
                name: "IX_oferta_dirigido_a_oferta_id",
                table: "oferta_dirigido_a",
                column: "oferta_id");

            migrationBuilder.CreateIndex(
                name: "IX_oferta_file_appfile_id",
                table: "oferta_file",
                column: "appfile_id");

            migrationBuilder.CreateIndex(
                name: "IX_oferta_file_oferta_id",
                table: "oferta_file",
                column: "oferta_id");

            migrationBuilder.CreateIndex(
                name: "IX_oferta_modulo_oferta_id",
                table: "oferta_modulo",
                column: "oferta_id");

            migrationBuilder.CreateIndex(
                name: "IX_oferta_tema_oferta_id",
                table: "oferta_tema",
                column: "oferta_id");

            migrationBuilder.CreateIndex(
                name: "IX_oferta_tema_tema_id",
                table: "oferta_tema",
                column: "tema_id");

            migrationBuilder.CreateIndex(
                name: "IX_ParticipanteRetos_ParticipanteId",
                table: "ParticipanteRetos",
                column: "ParticipanteId");

            migrationBuilder.CreateIndex(
                name: "IX_ParticipanteRetos_RetoId",
                table: "ParticipanteRetos",
                column: "RetoId");

            migrationBuilder.CreateIndex(
                name: "IX_perfil_etiqueta_listaitem_id",
                table: "perfil_etiqueta",
                column: "listaitem_id");

            migrationBuilder.CreateIndex(
                name: "IX_perfil_etiqueta_user_id",
                table: "perfil_etiqueta",
                column: "user_id");

            migrationBuilder.CreateIndex(
                name: "IX_publicacion_compartir_id",
                table: "publicacion",
                column: "compartir_id");

            migrationBuilder.CreateIndex(
                name: "IX_publicacion_user_id",
                table: "publicacion",
                column: "user_id");

            migrationBuilder.CreateIndex(
                name: "IX_publicacion_comentario_padre_id",
                table: "publicacion_comentario",
                column: "padre_id");

            migrationBuilder.CreateIndex(
                name: "IX_publicacion_comentario_publicacion_id",
                table: "publicacion_comentario",
                column: "publicacion_id");

            migrationBuilder.CreateIndex(
                name: "IX_publicacion_comentario_user_id",
                table: "publicacion_comentario",
                column: "user_id");

            migrationBuilder.CreateIndex(
                name: "IX_publicacion_file_appfile_id",
                table: "publicacion_file",
                column: "appfile_id");

            migrationBuilder.CreateIndex(
                name: "IX_publicacion_file_publicacion_id",
                table: "publicacion_file",
                column: "publicacion_id");

            migrationBuilder.CreateIndex(
                name: "IX_publicacion_ocultar_AppUserId",
                table: "publicacion_ocultar",
                column: "AppUserId");

            migrationBuilder.CreateIndex(
                name: "IX_publicacion_ocultar_listaitem_id",
                table: "publicacion_ocultar",
                column: "listaitem_id");

            migrationBuilder.CreateIndex(
                name: "IX_publicacion_ocultar_publicacion_id",
                table: "publicacion_ocultar",
                column: "publicacion_id");

            migrationBuilder.CreateIndex(
                name: "IX_publicacion_reportar_AppUserId",
                table: "publicacion_reportar",
                column: "AppUserId");

            migrationBuilder.CreateIndex(
                name: "IX_publicacion_reportar_listaitem_id",
                table: "publicacion_reportar",
                column: "listaitem_id");

            migrationBuilder.CreateIndex(
                name: "IX_publicacion_reportar_publicacion_id",
                table: "publicacion_reportar",
                column: "publicacion_id");

            migrationBuilder.CreateIndex(
                name: "IX_respuesta_etiqueta_etiqueta_id",
                table: "respuesta_etiqueta",
                column: "etiqueta_id");

            migrationBuilder.CreateIndex(
                name: "IX_respuesta_etiqueta_respuesta_id",
                table: "respuesta_etiqueta",
                column: "respuesta_id");

            migrationBuilder.CreateIndex(
                name: "IX_RespuestaComentarios_RespuestaId",
                table: "RespuestaComentarios",
                column: "RespuestaId");

            migrationBuilder.CreateIndex(
                name: "IX_RespuestaLikes_RespuestasId",
                table: "RespuestaLikes",
                column: "RespuestasId");

            migrationBuilder.CreateIndex(
                name: "IX_Respuestas_PreguntaId",
                table: "Respuestas",
                column: "PreguntaId");

            migrationBuilder.CreateIndex(
                name: "IX_TemaRetos_RetoId",
                table: "TemaRetos",
                column: "RetoId");

            migrationBuilder.CreateIndex(
                name: "IX_TemaRetos_TemaId",
                table: "TemaRetos",
                column: "TemaId");

            migrationBuilder.CreateIndex(
                name: "IX_ubicacion_geografica_MunicipioId",
                table: "ubicacion_geografica",
                column: "MunicipioId");

            migrationBuilder.CreateIndex(
                name: "IX_UsuariosConectadosChat_user_id",
                table: "UsuariosConectadosChat",
                column: "user_id");
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "ChatBot");

            migrationBuilder.DropTable(
                name: "contacto");

            migrationBuilder.DropTable(
                name: "ConversacionesConectadas");

            migrationBuilder.DropTable(
                name: "DocumentoRetos");

            migrationBuilder.DropTable(
                name: "EntidadRetos");

            migrationBuilder.DropTable(
                name: "EtapaRetos");

            migrationBuilder.DropTable(
                name: "experiencia_herramienta");

            migrationBuilder.DropTable(
                name: "experiencia_poblacion");

            migrationBuilder.DropTable(
                name: "experiencia_tema");

            migrationBuilder.DropTable(
                name: "Herramienta_Equipo");

            migrationBuilder.DropTable(
                name: "Herramienta_Fases");

            migrationBuilder.DropTable(
                name: "Herramienta_Tareas");

            migrationBuilder.DropTable(
                name: "IncentivoRetos");

            migrationBuilder.DropTable(
                name: "Intereses");

            migrationBuilder.DropTable(
                name: "LoginUsers");

            migrationBuilder.DropTable(
                name: "mensaje_file");

            migrationBuilder.DropTable(
                name: "ModuloPruebas");

            migrationBuilder.DropTable(
                name: "notificacion");

            migrationBuilder.DropTable(
                name: "notificacion_disabled");

            migrationBuilder.DropTable(
                name: "notificacion_silence");

            migrationBuilder.DropTable(
                name: "oferta_dirigido_a");

            migrationBuilder.DropTable(
                name: "oferta_file");

            migrationBuilder.DropTable(
                name: "oferta_modulo");

            migrationBuilder.DropTable(
                name: "oferta_tema");

            migrationBuilder.DropTable(
                name: "ParticipanteRetos");

            migrationBuilder.DropTable(
                name: "perfil_etiqueta");

            migrationBuilder.DropTable(
                name: "publicacion_file");

            migrationBuilder.DropTable(
                name: "publicacion_ocultar");

            migrationBuilder.DropTable(
                name: "publicacion_reportar");

            migrationBuilder.DropTable(
                name: "respuesta_etiqueta");

            migrationBuilder.DropTable(
                name: "RespuestaComentarios");

            migrationBuilder.DropTable(
                name: "RespuestaLikes");

            migrationBuilder.DropTable(
                name: "Respuestas_Recurso_Experioencia_Herramienta");

            migrationBuilder.DropTable(
                name: "TemaRetos");

            migrationBuilder.DropTable(
                name: "ubicacion_geografica");

            migrationBuilder.DropTable(
                name: "UsuariosConectadosChat");

            migrationBuilder.DropTable(
                name: "experiencia");

            migrationBuilder.DropTable(
                name: "Herramienta");

            migrationBuilder.DropTable(
                name: "Mensaje");

            migrationBuilder.DropTable(
                name: "iteracion");

            migrationBuilder.DropTable(
                name: "oferta");

            migrationBuilder.DropTable(
                name: "Participantes");

            migrationBuilder.DropTable(
                name: "Respuestas");

            migrationBuilder.DropTable(
                name: "Retos");

            migrationBuilder.DropTable(
                name: "Temas");

            migrationBuilder.DropTable(
                name: "Conversacion_Union");

            migrationBuilder.DropTable(
                name: "publicacion_comentario");

            migrationBuilder.DropTable(
                name: "Preguntas");

            migrationBuilder.DropTable(
                name: "Conversacion");

            migrationBuilder.DropTable(
                name: "publicacion");

            migrationBuilder.DropTable(
                name: "app_user");

            migrationBuilder.DropTable(
                name: "equipo");

            migrationBuilder.DropTable(
                name: "proyecto");

            migrationBuilder.DropTable(
                name: "entidad");

            migrationBuilder.DropTable(
                name: "AppFiles");

            migrationBuilder.DropTable(
                name: "listas_community");
        }
    }
}
