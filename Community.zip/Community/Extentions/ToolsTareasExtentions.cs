﻿using Community.Repositories.Tareas;
using Community.Services.Tareas;
using Microsoft.Extensions.DependencyInjection;

namespace Community.Extentions
{
    public static class ToolsTareasExtentions
    {
        public static IServiceCollection AddToolsTareasExtentions(this IServiceCollection services)
        {
            services.AddScoped<ITareasRepository, TareasRepository>();
            services.AddScoped<ITareasService, TareasService>();
            return services;
        }
    }
}
