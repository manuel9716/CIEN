﻿using Community.Repositories.Tools;
using Community.Services.Tools;
using Microsoft.Extensions.DependencyInjection;

namespace Community.Extentions
{
    public static class ToolsExtentions
    {
        public static IServiceCollection AddToolsExtentions(this IServiceCollection services)
        {
            services.AddScoped<IToolsRepository, ToolsRepository>();
            services.AddScoped<IToolsService, ToolsService>();
            return services;
        }
    }
}
