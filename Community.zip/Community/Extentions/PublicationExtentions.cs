using Community.Repositories.Publications;
using Community.Services.Publications;
using Microsoft.Extensions.DependencyInjection;

namespace Community.Extentions
{
    public static class PublicationExtentions
    {
        public static IServiceCollection AddPublicationExtentions(this IServiceCollection services)
        {
            services.AddScoped<IPublicationRepository, PublicationRepository>();
            services.AddScoped<IPublicationService, PublicationService>();

            return services;
        }
    }
}