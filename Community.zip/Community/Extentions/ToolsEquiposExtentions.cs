﻿using Community.Repositories.Equipos;
using Community.Services.Equipos;
using Microsoft.Extensions.DependencyInjection;

namespace Community.Extentions
{
    public static class ToolsEquiposExtentions
    {
        public static IServiceCollection AddToolsEquiposExtentions(this IServiceCollection services)
        {
            services.AddScoped<IEquiposRepository, EquiposRepository>();
            services.AddScoped<IEquiposService, EquiposService>();
            return services;
        }
    }
}
