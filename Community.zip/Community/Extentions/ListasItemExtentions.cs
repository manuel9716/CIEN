using Community.Repositories.ListasItem;
using Community.Services.ListasItem;
using Microsoft.Extensions.DependencyInjection;

namespace Community.Extentions
{
    public static class ListasItemExtentions
    {
        public static IServiceCollection AddListasItemExtentions(this IServiceCollection services)
        {
            services.AddScoped<IListasItemRepository, ListasItemRepository>();
            services.AddScoped<IListasItemService, ListasItemService>();
            return services;
        }

    }
}
