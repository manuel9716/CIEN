using Community.Repositories.Learn;
using Community.Services.Learn;
using Microsoft.Extensions.DependencyInjection;

namespace Community.Extentions
{
    public static class LearnExtensions
    {
        public static IServiceCollection AddLearnExtentions(this IServiceCollection services)
        {
            services.AddScoped<ILearnRepository, LearnRepository>();
            services.AddScoped<ILearnService, LearnService>();

            return services;
        }
    }
}