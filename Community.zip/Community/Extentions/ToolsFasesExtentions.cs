﻿using Community.Repositories.Fases;
using Community.Services.Fases;
using Microsoft.Extensions.DependencyInjection;

namespace Community.Extentions
{
    public static class ToolsFasesExtentions
    {
        public static IServiceCollection AddToolsFasesExtentions(this IServiceCollection services)
        {
            services.AddScoped<IFasesRepository, FasesRepository>();
            services.AddScoped<IFasesService, FasesService>();
            return services;
        }
    }
}
