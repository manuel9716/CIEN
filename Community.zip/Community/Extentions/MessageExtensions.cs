using Community.Repositories.Messages;
using Community.Services.Messages;
using Microsoft.Extensions.DependencyInjection;

namespace Community.Extentions
{
    public static class MessageExtensions
    {
        public static IServiceCollection AddMessageExtentions(this IServiceCollection services)
        {
            services.AddScoped<IMessageRepository, MessageRepository>();
            services.AddScoped<IMessageService, MessageService>();

            return services;
        }
    }
}
