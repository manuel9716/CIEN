using Microsoft.Extensions.DependencyInjection;

using Community.Repositories.AppUsers;
using Community.Services.AppUsers;
using Community.Repositories.Contactos;
using Community.Services.Contactos;

namespace Community.Extentions
{
    public static class CommunityExtentions
    {
        public static IServiceCollection AddCommunityExtentions(this IServiceCollection services)
        {

            services.AddScoped<IAppUsersRepository, AppUsersRepository>();
            services.AddScoped<IAppUsersService, AppUsersService>();
            services.AddScoped<IContactoRepository, ContactoRepository>();
            services.AddScoped<IContactoService, ContactoService>();
            return services;
        }

    }
}
