﻿using Community.Repositories.ChatBot;
using Community.Services.ChatBot;
using Microsoft.Extensions.DependencyInjection;

namespace Community.Extentions
{

    public static class ChatBotExtentions
    {
        public static IServiceCollection AddChatBotExtentions(this IServiceCollection services)
        {
            services.AddScoped<IChatBotRepository, ChatBotRepository>();
            services.AddScoped<IChatBotServices, ChatBotServices>();
            return services;
        }

    }
}
