using Community.Repositories.Files;
using Community.Services.Files;
using Microsoft.Extensions.DependencyInjection;

namespace Community.Extentions
{
    public static class FileExtentions
    {
        public static IServiceCollection AddFilesExtentions(this IServiceCollection services)
        {
            services.AddScoped<IFilesRepository, FilesRepository>();
            services.AddScoped<IFilesService, FilesService>();
            return services;
        }

    }
}