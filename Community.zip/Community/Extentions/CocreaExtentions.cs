﻿using Microsoft.Extensions.DependencyInjection;
using Community.Repositories.AppUsers;
using Community.Services.AppUsers;
using Community.Repositories.Contactos;
using Community.Services.Contactos;
using Community.Repositories.Cocrea;
using Community.Services.Cocrea;

namespace Community.Extentions
{
    public static class CocreaExtentions
    {
        public static IServiceCollection AddCocreaExtentions(this IServiceCollection services)
        {
            services.AddScoped<ICocreaRepository, CocreaRepository>();
            services.AddScoped<ICocreaServices, CocreaServices>();
            return services;
        }

    }
}
