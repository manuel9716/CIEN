﻿using Community.Repositories.Interests;
using Community.Services.Interests;
using Microsoft.Extensions.DependencyInjection;

namespace Community.Extentions
{
    public static class InterestsExtentions
    {
        public static IServiceCollection AddInterestsExtentions(this IServiceCollection services)
        {
            services.AddScoped<IInterestsRepository, InterestsRepository>();
            services.AddScoped<IInterestsService, InterestsService>();
            return services;
        }
    }
}
