﻿using Community.Repositories.Cocrea;
using Community.Repositories.Metricas;
using Community.Services.Cocrea;
using Community.Services.Metricas;
using Microsoft.Extensions.DependencyInjection;

namespace Community.Extentions
{
    public static class MetricasExtentions
    {

        public static IServiceCollection AddmetricasExtentions(this IServiceCollection services)
        {
            services.AddScoped<IMetricasRepository, MetricasRepository>();
            services.AddScoped<IMetricasServices, MetricasServices>();
            return services;
        }


    }
}
