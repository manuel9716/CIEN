using Community.Repositories.Notifications;
using Community.Services.Notifications;
using Microsoft.Extensions.DependencyInjection;

namespace Community.Extentions
{
    public static class NotificationExtentions
    {
        public static IServiceCollection AddNotificationExtentions(this IServiceCollection services)
        {
            services.AddScoped<INotificationRepository, NotificationRepository>();
            services.AddScoped<INotificationService, NotificationService>();

            return services;
        }
    }
}