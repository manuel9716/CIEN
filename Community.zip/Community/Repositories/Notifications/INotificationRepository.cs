using System;
using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;
using Community.Dtos.Pagination.Models;
using Community.Models.notification;

namespace Community.Repositories.Notifications
{
    public interface INotificationRepository
    {
        Notification Create(Notification entity, CancellationToken cancellationToken);
        Task<Notification> Read(Guid id, CancellationToken cancellationToken);
        Task<List<Notification>> ReadAll(Guid Userid,CancellationToken cancellationToken);
        Task Delete(Guid id, CancellationToken cancellationToken);
        Task<long> TotalCount(Guid id, CancellationToken cancellationToken);
        Task<List<Notification>> ReadAllActivas(Guid Userid,CancellationToken cancellationToken);
        Task<Notification> Update(Notification entity, CancellationToken cancellationToken);


    }
}
