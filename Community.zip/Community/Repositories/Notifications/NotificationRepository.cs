using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using Community.DbContexts;
using Community.Dtos.Pagination.Models;
using Community.Dtos.AppUsers.Models;
using Community.Models;
using Community.Models.notification;

namespace Community.Repositories.Notifications
{
    public class NotificationRepository : INotificationRepository
    {
        private readonly CommunityDbContext _context;

        public NotificationRepository(CommunityDbContext context)
        {
            _context = context;
        }

        public Notification Create(Notification entity, CancellationToken cancellationToken)
        {
            entity.FechaCreacion = DateTime.Now;

            var result =  _context.Add(entity);

           _context.SaveChanges();
            return result.Entity;
        }

        public async Task Delete(Guid id, CancellationToken cancellationToken)
        {
            var entity = await Read(id, cancellationToken);
            if (entity != null)
            {
                _context.Notificacion.Remove(entity);
                await _context.SaveChangesAsync(cancellationToken);
            }
        }

        public async Task<Notification> Read(Guid id, CancellationToken cancellationToken)
        {
            return await _context.Notificacion.Where(x => x.Id == id).FirstOrDefaultAsync(cancellationToken);
        }

        public async Task<List<Notification>> ReadAll(Guid Userid, CancellationToken cancellationToken)
        {
            var result = await _context.Notificacion.Where(p => p.UserId == Userid).Include(x=>x.UserOrigen).OrderByDescending(x=>x.FechaCreacion).ToListAsync();
            return result;        
        }

        public async Task<long> TotalCount(Guid id, CancellationToken cancellationToken)
        {
            var result = await _context.Notificacion.Where(x=>x.UserId == id && x.activa).CountAsync();
            return result;
        } 

        public async Task<List<Notification>> ReadAllActivas(Guid Userid, CancellationToken cancellationToken)
        {
            var result = await _context.Notificacion.Where(p => p.UserId == Userid && p.activa).OrderByDescending(x=>x.FechaCreacion).ToListAsync();
            return result;        
        }

        public async Task<Notification> Update(Notification entity, CancellationToken cancellationToken)
        {
            _context.Entry(entity).State = EntityState.Modified;
            await _context.SaveChangesAsync(cancellationToken);
            return entity;
        }
    }
}
