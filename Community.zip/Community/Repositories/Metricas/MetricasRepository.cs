﻿using Community.DbContexts;
using Community.Dtos.Cocrea.Models;
using Community.Dtos.Cocrea.Models.Preguntas;
using Community.Dtos.Metricas.InputModels;
using Community.Dtos.Metricas.Models.Herramientas;
using Community.Dtos.Pagination.Models;
using Community.Models;
using Community.Models.Metricas;
using Microsoft.EntityFrameworkCore;
using System;
using System.Linq;
using System.Threading.Tasks;

namespace Community.Repositories.Metricas
{
    public class MetricasRepository : IMetricasRepository
    {
        private readonly CommunityDbContext _context;

        public MetricasRepository(CommunityDbContext context)
        {
            _context = context;
        }

        public ResponseModels InsertLoginUser(InputLoginUsersModels Dta)
        {
            var response = new ResponseModels(); 
            response.IsSuccess = false;

            using (var db = _context)
            {
                try
                {
                    using (var dbTransaction = db.Database.BeginTransaction())
                    {
                        try
                        {
                            var ValiUser = db.Loginuser.Where(x => x.Iduser == Dta.idUsuario).FirstOrDefault();
                             if(ValiUser == null)
                             {
                                var InsertLoginUser = new LoginUsers();
                                InsertLoginUser.Iduser = Dta.idUsuario;
                                InsertLoginUser.Nombre = Dta.nombre;
                                InsertLoginUser.Usuario = Dta.nombreUsuario;
                                InsertLoginUser.Correo = Dta.correo;
                                InsertLoginUser.FechaCreacion = DateTime.Now;
                                db.Entry(InsertLoginUser).State = EntityState.Added;
                                db.SaveChanges();
                                dbTransaction.Commit();
                                response.IsSuccess = true;
                                response.Message = "Registro insertado correctamente a la base de datos";
                             }
                            else
                            {
                                response.Message = "Usuario ya Registrado";
                            }
                        }
                        catch (System.Exception Ex)
                        {
                            dbTransaction.Rollback();
                            response.Message = "Ocurrio un problema al insertar el registro en la base de datos + Detalle:  " + Ex.Message + "_" + Ex.InnerException + "_" + Ex.StackTrace;
                        }
                    }
                }
                catch (System.Exception Ex)
                {
                    response.Message = "Ocurrio un problema al insertar el registro en la base de datos + Detalle:  " + Ex.Message + "_" + Ex.InnerException + "_" +Ex.StackTrace;
                }
            }
            return response;
        }

          public ResponseModels InsertVisitaModuloprueba(inputModuloPruebaModels Dta)
        {
            var response = new ResponseModels();
            response.IsSuccess = false;

            using (var db = _context)
            {
                try
                {
                    using (var dbTransaction = db.Database.BeginTransaction())
                    {
                        try
                        {
                            var InsertVistapagina = new ModuloPrueba();
                            InsertVistapagina.TipoPagina = Dta.tipo;
                            InsertVistapagina.FechaCreacion = DateTime.Now;
                            db.Entry(InsertVistapagina).State = EntityState.Added;
                            db.SaveChanges();
                            dbTransaction.Commit();
                            response.IsSuccess = true;
                            response.Message = "Registro insertado correctamente a la base de datos";
                        }
                        catch (System.Exception Ex)
                        {
                            dbTransaction.Rollback();
                            response.Message = "Ocurrio un problema al insertar el registro en la base de datos + Detalle:  " + Ex.Message + "_" + Ex.InnerException + "_" + Ex.StackTrace;
                        }
                    }
                }
                catch (System.Exception Ex)
                {
                    response.Message = "Ocurrio un problema al insertar el registro en la base de datos + Detalle:  " + Ex.Message + "_" + Ex.InnerException + "_" + Ex.StackTrace;
                }
            }

            return response;
          }
    }
}
