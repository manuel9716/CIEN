﻿using Community.Models.interests;
using System;
using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;

namespace Community.Repositories.Interests
{
    public interface IInterestsRepository
    {
        Task<Interest> Read(Guid id, CancellationToken cancellationToken);
        Task<List<Interest>> GetbyUserId(Guid appUserId, CancellationToken cancellationToken);
        Task<List<Interest>> GetInterestsbyUserId(Guid Id, CancellationToken cancellationToken);
    }
}
