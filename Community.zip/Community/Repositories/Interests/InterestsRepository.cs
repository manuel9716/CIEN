﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using Community.DbContexts;
using Community.Dtos.Pagination.Models;
using Community.Dtos.Interests.Models;
using Community.Models.interests;

namespace Community.Repositories.Interests
{
    public class InterestsRepository : IInterestsRepository
    {       
        private readonly CommunityDbContext _context;

        public InterestsRepository(CommunityDbContext context)
        {
            _context = context;
        }
        public async Task<Interest> Read(Guid id, CancellationToken cancellationToken)
        {
            return await _context.Intereses.Where(Interest => Interest.Id == id).FirstOrDefaultAsync(cancellationToken);
        }

        public async Task<List<Interest>> GetbyUserId(Guid AppUserId, CancellationToken cancellationToken)
        {
            return await _context.Intereses
                            .Include(usuario => usuario.Usuario)
                            .Include(interes => interes.ListaItem)
                            .Where(usuario => usuario.AppUserId == AppUserId)
                            .ToListAsync();
        }

        public async Task<List<Interest>> GetInterestsbyUserId(Guid Id, CancellationToken cancellationToken)
        {
            return await _context.Intereses
                            .Include(usuario => usuario.Usuario)
                            .Include(interes => interes.ListaItem)
                            .Where(interes => interes.ListaItemId == Id)
                            .ToListAsync();
        }
    }
}
