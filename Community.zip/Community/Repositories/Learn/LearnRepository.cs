using Community.DbContexts;
using Community.Dtos.Pagination.Models;
using Community.Models;
using Community.Models.Learn;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace Community.Repositories.Learn
{
    public class LearnRepository : ILearnRepository
    {
        private readonly CommunityDbContext _context;
        public LearnRepository(CommunityDbContext context)
        {
            _context = context;
        }
         public async Task<List<Oferta>> GetOfertas(Paginator paginator,string nombre,List<Guid> tema, List<Guid> tipo, List<Guid> modalidad, List<Guid> dirigidoA)
        {

            var query = from oferta in _context.Oferta select oferta;
            query = this.Nombre(query, nombre);
            query = this.Categorias(query,tema,tipo,modalidad,dirigidoA);
            query = query.Where(x => x.Ocultar == true)
            .OrderByDescending(p => p.FechaCreacion);

            return await query.Skip((paginator.PageNumber - 1) * paginator.PageSize)
               .Take(paginator.PageSize)
               .Include(usuario => usuario.Usuario)
               .Include(dirigidoa => dirigidoa.OfertaDirigidoA)
               .Include(temas => temas.OfertaTema)
               .Include(modulo => modulo.OfertaModulo)
               .Include(files => files.Ofertafile)
               .ToListAsync();

        }
       
        private IQueryable<Oferta> Nombre(IQueryable<Oferta> query, string nombre)
        {
            if(nombre != null)
            {
                query = query.Where(p => p.Titulo.Contains(nombre));
            }

            return query;
        }

        private IQueryable<Oferta> Categorias(IQueryable<Oferta> query, List<Guid> tema, List<Guid> tipo, List<Guid> modalidad, List<Guid> dirigidoA)
        {

            if (tema.Count > 0)
            {
                foreach (var item in tema)
                {
                    query = query.Where(p => p.OfertaTema.Any(z => z.TemaId == item));

                }

            }

            if (tipo.Count > 0)
            {
                foreach (var item in tipo)
                {
                    query = query.Where(p => p.TipoId == item);

                }

            }

            if (modalidad.Count > 0)
            {
                foreach (var item in modalidad)
                {
                    query = query.Where(p => p.ModalidadId == item);

                }

            }


            if (dirigidoA.Count > 0 )
            {
                foreach (var item in dirigidoA)
                {
                    query = query.Where(p => p.OfertaDirigidoA.Any(z => z.DirigidoAId == item));

                }

            }

            return query;

        }
        public async Task<Oferta> GetOferta(Guid Id)
        {
            return await _context.Oferta.Where(p => p.Id == Id && p.Ocultar == true)
               .Include(usuario => usuario.Usuario)
               .Include(dirigidoa => dirigidoa.OfertaDirigidoA)
               .Include(temas => temas.OfertaTema)
               .Include(modulo => modulo.OfertaModulo)
               .Include(files => files.Ofertafile)
               .FirstOrDefaultAsync();
        }
         public async Task<ListaItem> ReadListaItemId(Guid id)
        {
            return await _context.ListasItem.Where(p => p.Id == id)
               .FirstOrDefaultAsync();
        }
        public async Task<ListaItem> ReadListaItem(Guid id, Guid idPadre, CancellationToken cancellationToken)
        {
            return await _context.ListasItem.Where(p => p.Id == id && p.PadreId == idPadre)
                .FirstOrDefaultAsync(cancellationToken);
        }
        public async Task<ListaItem> ReadListaItemPadre(string codigo, CancellationToken cancellationToken)
        {
            return await _context.ListasItem.Where(p => p.Codigo == codigo)
                .FirstOrDefaultAsync(cancellationToken);
        }


        public async Task<Oferta> CreateOferta(Oferta entity, CancellationToken cancellationToken)
        {
            entity.FechaCreacion = DateTime.Now;
            entity.FechaActualizacion = DateTime.Now;

            var result = await _context.AddAsync(entity);

            await _context.SaveChangesAsync();
            return result.Entity;
        }

        public async Task<Oferta_file> CreateOfertaFile(Oferta_file entity, CancellationToken cancellationToken)
        {
            entity.FechaCreacion = DateTime.Now;

            var result = await _context.AddAsync(entity);

            await _context.SaveChangesAsync();
            return result.Entity;
        }

        public async Task<Oferta_DIrigido_A> CreateOfertaDirigidoA(Oferta_DIrigido_A entity, CancellationToken cancellationToken)
        {
            entity.FechaCreacion = DateTime.Now;

            var result = await _context.AddAsync(entity);

            await _context.SaveChangesAsync();
            return result.Entity;
        }

        public async Task<Oferta_modulo> CreateOfertaModulo(Oferta_modulo entity, CancellationToken cancellationToken)
        {
            entity.FechaCreacion = DateTime.Now;

            var result = await _context.AddAsync(entity);

            await _context.SaveChangesAsync();
            return result.Entity;
        }

        public async Task<Oferta_tema> CreateOfertaTema(Oferta_tema entity, CancellationToken cancellationToken)
        {
            entity.FechaCreacion = DateTime.Now;

            var result = await _context.AddAsync(entity);

            await _context.SaveChangesAsync();
            return result.Entity;
        }
         public async Task<Oferta> UpdaterOferta(Oferta entity, CancellationToken cancellationToken)
        {
            entity.FechaActualizacion = DateTime.Now;
            _context.Entry(entity).State = EntityState.Modified;
            await _context.SaveChangesAsync(cancellationToken);
            return entity;
        }
        public async Task<Oferta> OcultarOferta(Oferta entity, CancellationToken cancellationToken)
        {
            entity.Ocultar = false;
            _context.Entry(entity).State = EntityState.Modified;
            await _context.SaveChangesAsync(cancellationToken);
            return entity;
        }

        public Task<Oferta_DIrigido_A> ReadOfertaDirigidoA(Guid dirigidoaId)
        {
            return _context.OfertaDirigidoA.Where(p => p.Id == dirigidoaId)
              .FirstOrDefaultAsync();
        }

        public Oferta_DIrigido_A DeleteOfertaDirigidoA(Oferta_DIrigido_A entity)
        {

                    _context.OfertaDirigidoA.Remove(entity);
                    _context.SaveChanges();

            return null;

        }
        public Task<Oferta_modulo> ReadOfertaModulo(Guid moduloId)
        {
            return _context.OfertaModulo.Where(p => p.Id == moduloId)
              .FirstOrDefaultAsync();
        }

        public Oferta_modulo DeleteOfertaModulo(Oferta_modulo entity)
        {
                    _context.OfertaModulo.Remove(entity);
                    _context.SaveChanges();

            return null;
        }

        public Task<Oferta_tema> ReadOfertaTema(Guid temaId)
        {
            return _context.OfertaTema.Where(p => p.Id == temaId)
              .FirstOrDefaultAsync();
        }


        public Oferta_tema DeleteOfertaTema(Oferta_tema entity)
        {
                    _context.OfertaTema.Remove(entity);
                    _context.SaveChanges();

            return null;
        }

        public List<Oferta_file> ReadOfertaFile(Guid OfertaId)
        {
            return _context.OfertaFile.Where(p => p.OfertaId == OfertaId)
              .ToList();
        }

        public Oferta_file DeleteOfertaFiles(Guid OfertaId)
        {
            var entity = ReadOfertaFile(OfertaId);
            if (entity.Count > 0)
            {
                foreach (var item in entity)
                {

                    _context.OfertaFile.Remove(item);
                    _context.SaveChanges();

                }
            }

            return null;
        }

      
    }
}
