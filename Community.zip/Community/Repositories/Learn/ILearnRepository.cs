using Community.Dtos.Pagination.Models;
using Community.Models;
using Community.Models.Learn;
using System;
using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;

namespace Community.Repositories.Learn
{
    public interface ILearnRepository
    {
         Task<List<Oferta>> GetOfertas(Paginator paginator, string nombre,List<Guid> tema, List<Guid> tipo, List<Guid> modalidad, List <Guid> dirigidoA);
        Task<Oferta> GetOferta(Guid Id);
         Task<ListaItem> ReadListaItemId(Guid id);
        Task<ListaItem> ReadListaItem(Guid id, Guid idPadre, CancellationToken cancellationToken);
        Task<ListaItem> ReadListaItemPadre(string codigo, CancellationToken cancellationToken);
        Task<Oferta> CreateOferta(Oferta entity, CancellationToken cancellationToken);
        Task<Oferta_file> CreateOfertaFile(Oferta_file entity, CancellationToken cancellationToken);
        Task<Oferta_DIrigido_A> CreateOfertaDirigidoA(Oferta_DIrigido_A entity, CancellationToken cancellationToken);
        Task<Oferta_modulo> CreateOfertaModulo(Oferta_modulo entity, CancellationToken cancellationToken);
        Task<Oferta_tema> CreateOfertaTema(Oferta_tema entity, CancellationToken cancellationToken);
        Task<Oferta> UpdaterOferta(Oferta entity, CancellationToken cancellationToken);
        Task<Oferta> OcultarOferta(Oferta entity, CancellationToken cancellationToken);
        Oferta_DIrigido_A DeleteOfertaDirigidoA(Oferta_DIrigido_A entity);
        Oferta_modulo DeleteOfertaModulo(Oferta_modulo entity);
        Oferta_tema DeleteOfertaTema(Oferta_tema entity);
        Oferta_file DeleteOfertaFiles(Guid OfertaId);
        //public Task<Oferta_file> ReadOfertaFile(Guid fileId);
        public Task<Oferta_tema> ReadOfertaTema(Guid temaId);
        public Task<Oferta_modulo> ReadOfertaModulo(Guid moduloId);
        public Task<Oferta_DIrigido_A> ReadOfertaDirigidoA(Guid dirigidoaId);
    }
}
