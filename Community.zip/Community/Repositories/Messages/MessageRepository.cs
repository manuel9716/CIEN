using Community.DbContexts;
using Community.Dtos.Pagination.Models;
using Community.Models;
using Community.Models.Messages;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace Community.Repositories.Messages
{
    public class MessageRepository : IMessageRepository
    {
        private readonly CommunityDbContext _context;
        public MessageRepository(CommunityDbContext context)
        {
            _context = context;
        }

        public async Task<List<Conversation>> GetConversaciones(Guid AppUserId)
        {

            return await _context.Conversacion.Where(p => p.UserSenderId == AppUserId)
               .OrderByDescending(p => p.FechaCreacion)
               .Include(usuarioreceptor => usuarioreceptor.ReceptorUsuario)
               .ToListAsync();
        }
        public List<Conversation> GetConversacionesSocket(Guid AppUserId)
        {
            return _context.Conversacion.Where(p => p.UserSenderId == AppUserId)
               .OrderByDescending(p => p.FechaCreacion)
               .Include(usuarioreceptor => usuarioreceptor.ReceptorUsuario)
               .ToList();
        }
        public async Task<List<Conversation>> GetConversacionesPorNombre(Guid AppUserId,string nombre)
        {

            var query = from conversacion in _context.Conversacion select conversacion;
            query = query.Where(p => p.UserSenderId == AppUserId)
            .OrderByDescending(p => p.FechaCreacion);

            return await query.Where(p => p.ReceptorUsuario.Nombres.Contains(nombre) || p.ReceptorUsuario.Apellidos.Contains(nombre))
                .Include(usuarioreceptor => usuarioreceptor.ReceptorUsuario)
                .ToListAsync();

        }

        public async Task<List<Message>> GetMensajes(Guid IdConversacion, Paginator paginator)
        {
            var query = from message in _context.Mensajes select message;
            query = query.Where(p => p.ConversacionId == IdConversacion)
            .OrderBy(p => p.FechaCreacion);

            return await query.Skip((paginator.PageNumber - 1) * paginator.PageSize)
               .Take(paginator.PageSize)
               .Include(usuario => usuario.Usuario)
               .ToListAsync();
        }
        public async Task<List<Message>> ReadMensajesSinLeer(Guid IdConversacion,Guid AppUserId)
        {
            return await _context.Mensajes.Where(p => p.ConversacionId == IdConversacion && p.Leido == false && p.AppUserId != AppUserId)
                .ToListAsync();
        }
        public Message ReadMensajeId(Guid mensajeId)
        {
            return _context.Mensajes.Where(p => p.Id == mensajeId)
                .FirstOrDefault();
        }
        public Task<List<AppUser>> GetUsuarios(string nombre,CancellationToken cancellationToken)
        {

            if (!string.IsNullOrEmpty(nombre))
            {
                return _context.AppUsers.Where(p => p.Nombres.Contains(nombre) || p.Apellidos.Contains(nombre))
                .ToListAsync(cancellationToken);
            }
            else{
                return _context.AppUsers
                .Take(10)
                .ToListAsync(cancellationToken);
            }

        }
         public async Task<Message> ReadUltimoMensaje(Guid conversacionId)
        {
            return await _context.Mensajes.Where(p => p.ConversacionId == conversacionId)
                .OrderByDescending(p => p.FechaCreacion)
                .FirstOrDefaultAsync();
        }
        public Message ReadUltimoMensajeSocket(Guid conversacionId)
        {
            return _context.Mensajes.Where(p => p.ConversacionId == conversacionId)
               .OrderByDescending(p => p.FechaCreacion)
               .FirstOrDefault();
        }

        public async Task<ConversationUnion> ReadConversacionId(Guid IdConversacion,CancellationToken cancellationToken)
        {
            return await _context.ConversacionUnion.Where(P => P.Id == IdConversacion)
                 .Include(sender => sender.SenderConversacion).ThenInclude(usersender => usersender.SenderUsuario)
                 .Include(receptor => receptor.ReceptorConversacion).ThenInclude(userreceptor => userreceptor.ReceptorUsuario)
                 .FirstOrDefaultAsync(cancellationToken);
        }
        public async Task<ConversationUnion> ReadConversacionUnionId(Guid IdConversacion)
        {
            return await _context.ConversacionUnion.Where(P => P.IdSender == IdConversacion || P.IdReceptor == IdConversacion)
                .FirstOrDefaultAsync();
        }
         public ConversationUnion ReadConversacionUnionIdSocket(Guid IdConversacion)
        {
            return _context.ConversacionUnion.Where(P => P.IdSender == IdConversacion || P.IdReceptor == IdConversacion)
                .FirstOrDefault();
        }
        public List<Message> ReadMensajesSinLeerSocket(Guid IdConversacion, Guid appUserId)
        {
            return _context.Mensajes.Where(p => p.ConversacionId == IdConversacion && p.Leido == false && p.AppUserId != appUserId)
               .ToList();
        }

        public async Task<Conversation> ReadConversacionReceptor(Guid UserSenderId, Guid UserReceptorId, CancellationToken cancellationToken)
        {
            return await _context.Conversacion.Where(P => (P.UserSenderId == UserSenderId && P.UserReceptorId == UserReceptorId) || (P.UserSenderId == UserReceptorId && P.UserReceptorId == UserSenderId))
                 .FirstOrDefaultAsync(cancellationToken);
        }
        public ConversacionesConectados ReadConversacionConectadoReceptor(Guid IdConversacion, Guid UserReceptorId)
        {
            return _context.ConversacionConectados.Where(P => P.ConversacionId == IdConversacion && P.AppUserId == UserReceptorId)
                .FirstOrDefault();
        }
        public List<Message> ReadMensajesReceptorSinLeer(Guid IdConversacion, Guid appUserReceptorId)
        {
            return _context.Mensajes.Where(p => p.ConversacionId == IdConversacion && p.AppUserId == appUserReceptorId && p.Leido == false)
                 .ToList();
        }
        public AppUser ReadUser(Guid id)
        {
            return _context.AppUsers.Where(AppUser => AppUser.Id == id).FirstOrDefault();
        }
        public async Task<AppFile> ReadFileId(Guid fileId)
        {
            return await _context.Files.Where(p => p.Id == fileId)
                .FirstOrDefaultAsync();
        }
        public async Task<List<Message_file>> ReadMensajeFile(Guid messageId)
        {
            return  await _context.MensajesFile.Where(p => p.MensajeId == messageId).ToListAsync();
        }
        public Message UpdateMensajeNoLeido(Message entity)
        {
            _context.Entry(entity).State = EntityState.Modified;
            _context.SaveChanges();
            return entity;
        }
        public UsuariosConectados ReadUsuarioConectado(Guid userReceptorId)
        {
            return _context.UsuarioConectado.Where(p => p.AppUserId == userReceptorId)
                .FirstOrDefault();
        }
        public async Task<Conversation> CreateConversacion(Conversation entity, CancellationToken cancellationToken)
        {
            entity.FechaCreacion = DateTime.Now;

            var result = await _context.AddAsync(entity);

            await _context.SaveChangesAsync();
            return result.Entity;
        }
        public async Task<ConversationUnion> CreateConversacionUnion(ConversationUnion entity, CancellationToken cancellationToken)
        {
            entity.FechaCreacion = DateTime.Now;

            var result = await _context.AddAsync(entity);

            await _context.SaveChangesAsync();
            return result.Entity;
        }


        public async Task<Message> CreateMensaje(Message entity, CancellationToken cancellationToken)
        {
            entity.FechaCreacion = DateTime.Now;

            var result = await _context.AddAsync(entity);

            await _context.SaveChangesAsync();
            return result.Entity;
        }
        public ConversacionesConectados CreateConversacionesConectados(ConversacionesConectados entity)
        {
           
            var result = _context.Add(entity);

            _context.SaveChanges();
            return result.Entity;
        }
        public UsuariosConectados CreateUsuariosConectados(UsuariosConectados entity)
        {
            var result = _context.Add(entity);

            _context.SaveChanges();
            return result.Entity;
        }
        public async Task<Message_file> CreateMensajesFile(Message_file entity, CancellationToken cancellationToken)
        {
            entity.FechaCreacion = DateTime.Now;

            var result = await _context.AddAsync(entity);

            await _context.SaveChangesAsync();
            return result.Entity;
        }

        public List<ConversacionesConectados> ReadConversacionesConectados(Guid id, Guid userId)
        {
            return _context.ConversacionConectados.Where(p => p.ConversacionId == id && p.AppUserId == userId)
              .ToList();
        }
        public ConversacionesConectados ReadConversacionesConectadosToken(string id)
        {
            return _context.ConversacionConectados.Where(p => p.SocketId == id)
              .FirstOrDefault();
        }

        public ConversacionesConectados DeleteConversacionesConectados(Guid IdConversacion,Guid userId)
        {
            var entity = ReadConversacionesConectados(IdConversacion,userId);
            if (entity != null)
            {

                foreach (var item in entity)
                {
                    _context.ConversacionConectados.Remove(item);
                    _context.SaveChanges();

                }
            }

            return null;
        }

        public ConversacionesConectados DeleteConversacionesConectadosToken(string IdSocket)
        {
            var entity = ReadConversacionesConectadosToken(IdSocket);
            if (entity != null)
            {
                _context.ConversacionConectados.Remove(entity);
                _context.SaveChanges();
            }

            return null;
        }
         public List<UsuariosConectados> ReadUsuariosConectados(Guid userId)
        {
            return _context.UsuarioConectado.Where(p => p.AppUserId == userId)
              .ToList();
        }
        public UsuariosConectados ReadUsuariosConectadosToken(string id)
        {
            return _context.UsuarioConectado.Where(p => p.SocketId == id)
              .FirstOrDefault();
        }

        public UsuariosConectados DeleteUsuariosConectados(Guid userId)
        {
            var entity = ReadUsuariosConectados(userId);
            if (entity != null)
            {

                foreach (var item in entity)
                {
                    _context.UsuarioConectado.Remove(item);
                    _context.SaveChanges();

                }
            }

            return null;
        }

        public UsuariosConectados DeleteUsuariosConectadosToken(string IdSocket)
        {
            var entity = ReadUsuariosConectadosToken(IdSocket);
            if (entity != null)
            {
                _context.UsuarioConectado.Remove(entity);
                _context.SaveChanges();
            }

            return null;
        }

        public async Task<List<Message_file>> ReadMessageFile(Guid MensajeId)
        {
            var result = await _context.MensajesFile.Where(p => p.MensajeId == MensajeId).ToListAsync();

            return result;
        }

        public async Task DeleteMensajesFile(Guid MensajeId, CancellationToken cancellationToken)
        {
            var entity = await ReadMessageFile(MensajeId);

            if (entity.Count > 0)
            {
                foreach (var item in entity)
                {
                    _context.MensajesFile.Remove(item);
                    await _context.SaveChangesAsync(cancellationToken);
                }

            }
        }

       
    }
}
