using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using Community.DbContexts;
using Community.Dtos.Pagination.Models;
using Community.Dtos.AppUsers.Models;
using Community.Models;
using Community.Models.interests;
using Community.Models.project;
using Community.Models.contactos;

namespace Community.Repositories.Contactos
{
    public class ContactoRepository : IContactoRepository
    {
        private readonly CommunityDbContext _context;

        public ContactoRepository(CommunityDbContext context)
        {
            _context = context;
        }

        public async Task<Contacto> Create(Contacto entity, CancellationToken cancellationToken)
        {
            var result = await _context.AddAsync(entity);
            await _context.SaveChangesAsync();
            return result.Entity;
        }

    }
}
