using System;
using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;
using Community.Dtos.Pagination.Models;
using Community.Dtos.AppUsers.Models;
using Community.Models;
using Community.Models.interests;
using Community.Models.project;
using Community.Models.contactos;

namespace Community.Repositories.Contactos
{
    public interface IContactoRepository
    {
        Task<Contacto> Create(Contacto entity, CancellationToken cancellationToken);
    
    }
}
