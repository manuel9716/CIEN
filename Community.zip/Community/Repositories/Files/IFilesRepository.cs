using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using Community.Dtos.Files.Models;
using Community.Dtos.Pagination.Models;
using Community.Models;

namespace Community.Repositories.Files
{
    public interface IFilesRepository
    {
        List<AppFile> Create(List<AppFile> entities);
        AppFile CreateSingle(AppFile entity);
        AppFile Read(Guid id);
        AppFile Update(AppFile entity);
        void Delete(Guid id);
        List<AppFile> Search(Paginator paginator, Sorter sorter, SearchFile searchRequest);
        int TotalCount(SearchFile searchRequest);
    }
}