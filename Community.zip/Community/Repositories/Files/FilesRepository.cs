using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Community.DbContexts;
using Community.Dtos.Files.Models;
using Community.Dtos.Pagination.Models;
using Community.Models;
using Microsoft.EntityFrameworkCore;

namespace Community.Repositories.Files
{
    public class FilesRepository : IFilesRepository
    {
        private readonly CommunityDbContext _context;

        public FilesRepository(CommunityDbContext context)
        {
            _context = context;
        }

        public List<AppFile> Create(List<AppFile> entities)
        {
            List<AppFile> results = new List<AppFile>();

            foreach (AppFile file in entities)
            {
                try
                {
                    var result = _context.Add(file);
                    _context.SaveChanges();
                    results.Add(result.Entity);
                }
                catch (Exception ex)
                {
                    var x = ex.Message;
                }
            }

            return results;
        }

        public AppFile CreateSingle(AppFile entity)
        {
            List<AppFile> results = new List<AppFile>();

            var result = new AppFile();
            try
            {
                var response = _context.Add(entity);
                _context.SaveChanges();
                result = response.Entity;
            }
            catch (Exception ex)
            {
                var x = ex.Message;
            }

            return result;
        }

        public AppFile Read(Guid id)
        {
            return _context.Files.Where(f => f.Id == id).FirstOrDefault();
        }

        public AppFile Update(AppFile entity)
        {
            _context.Entry(entity).State = EntityState.Modified;
            _context.SaveChanges();
            return entity;
        }

        public void Delete(Guid id)
        {
            throw new NotImplementedException();
        }
        public List<AppFile> Search(Paginator paginator, Sorter sorter, SearchFile searchRequest)
        {
            var query = this.GetQuery(searchRequest);
            query = this.SortQuery(query, sorter);

            return query.Skip((paginator.PageNumber - 1) * paginator.PageSize)
               .Take(paginator.PageSize).ToList();
        }

        public int TotalCount(SearchFile searchRequest)
        {
            return this.GetQuery(searchRequest).Count();
        }

        private IQueryable<Models.AppFile> GetQuery(SearchFile searchRequest)
        {
            var query = from menu in _context.Files select menu;


            if (!string.IsNullOrEmpty(searchRequest.Name))
            {
                query = query.Where(m => m.Name.ToLower().Contains(searchRequest.Name.ToLower()));
            }
            if (!string.IsNullOrEmpty(searchRequest.ContentType))
            {
                query = query.Where(m => m.ContentType.ToLower().Contains(searchRequest.ContentType.ToLower()));
            }
            if (searchRequest.LengthMin != null)
            {
                query = query.Where(m => m.Length >= searchRequest.LengthMin);
            }
            if (searchRequest.LengthMax != null)
            {
                query = query.Where(m => m.Length <= searchRequest.LengthMax);
            }
            return query;
        }

        private IQueryable<Models.AppFile> SortQuery(IQueryable<Models.AppFile> query, Sorter sorter)
        {

            switch (sorter.SortBy)
            {
                case "id":
                    if (sorter.SortOrder.Trim().ToLower().Equals("asc"))
                    {
                        query = query.OrderBy(x => x.Id);
                    }
                    else
                    {
                        query = query.OrderByDescending(x => x.Id);
                    }
                    break;

                case "name":
                    if (sorter.SortOrder.Trim().ToLower().Equals("asc"))
                    {
                        query = query.OrderBy(x => x.Name);
                    }
                    else
                    {
                        query = query.OrderByDescending(x => x.Name);
                    }
                    break;

                case "contentType":
                    if (sorter.SortOrder.Trim().ToLower().Equals("asc"))
                    {
                        query = query.OrderBy(x => x.ContentType);
                    }
                    else
                    {
                        query = query.OrderByDescending(x => x.ContentType);
                    }
                    break;

                case "length":
                    if (sorter.SortOrder.Trim().ToLower().Equals("asc"))
                    {
                        query = query.OrderBy(x => x.Length);
                    }
                    else
                    {
                        query = query.OrderByDescending(x => x.Length);
                    }
                    break;
            }
   
            return query;
        }

    }
}