﻿using Community.DbContexts;
using Community.Models.tool;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace Community.Repositories.Fases
{
    public class FasesRepository : IFasesRepository
    {
        private readonly CommunityDbContext _context;
        public FasesRepository(CommunityDbContext context)
        {
            _context = context;
        }
        public async Task<ToolFase> CreateFase(ToolFase entity, CancellationToken cancellationToken)
        {
            var result = await _context.AddAsync(entity);
            await _context.SaveChangesAsync();
            return result.Entity;
        }
    }
}
