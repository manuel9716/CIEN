﻿using Community.Models.tool;
using System;
using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;

namespace Community.Repositories.Fases
{
    public interface IFasesRepository
    {
        Task<ToolFase> CreateFase(ToolFase entity, CancellationToken cancellationToken);
    }
}
