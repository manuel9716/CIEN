using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using Community.DbContexts;
using Community.Dtos.Pagination.Models;
using Community.Dtos.AppUsers.Models;
using Community.Models;
using Community.Models.interests;
using Community.Models.project;

namespace Community.Repositories.AppUsers
{
    public class AppUsersRepository : IAppUsersRepository
    {
        private readonly CommunityDbContext _context;

        public AppUsersRepository(CommunityDbContext context)
        {
            _context = context;
        }

        public async Task<AppUser> Create(AppUser entity, CancellationToken cancellationToken)
        {
            var result = await _context.AddAsync(entity);
            await _context.SaveChangesAsync();
            return result.Entity;
        }

        public async Task<AppUser> Read(Guid id, CancellationToken cancellationToken)
        {
            var result = await _context.AppUsers.Where(AppUser => AppUser.Id == id)
                                                .Include(x=>x.AppFile)
                                                .Include(x=>x.PaisResidencia)
                                                .Include(x=>x.DepartamentoResidencia)
                                                .Include(x=>x.MunicipioResidencia)
                                                .Include(x=>x.Organizacion)
                                                .Include(x=>x.AreaDireccionEquipo)
                                                .Include(x=>x.Sector)
                                                .Include(x=>x.Orden)
                                                .Include(x=>x.Profesion)
                                                .Include(x=>x.CargoActual)
                                                .Include(x=>x.Nivel)
                                                .Include(x=>x.ProyectoActual)
                                                .Include(x=>x.ProyectoDestacado)
                                                .Include(x=>x.PreguntaConecta)
                                                .FirstOrDefaultAsync(cancellationToken);
            return result;
        }

        public async Task<AppUser> Update(AppUser entity, CancellationToken cancellationToken)
        {
            _context.Entry(entity).State = EntityState.Modified;
            await _context.SaveChangesAsync(cancellationToken);
            return entity;
        }
        public async Task Delete(Guid id, CancellationToken cancellationToken)
        {
            var entity = await Read(id, cancellationToken);
            if (entity != null)
            {
                _context.AppUsers.Remove(entity);
                await _context.SaveChangesAsync(cancellationToken);
            }
        }

        public Task<List<AppUser>> Search(Paginator paginator, Sorter sorter, SearchAppUser searchRequest, CancellationToken cancellationToken)
        {
            var query = this.GetQuery(searchRequest);
            query = this.SortQuery(query, sorter);

            return query.Skip((paginator.PageNumber - 1) * paginator.PageSize)
               .Take(paginator.PageSize).ToListAsync(cancellationToken);
        }

        public async Task<int> TotalCount(SearchAppUser searchRequest, CancellationToken cancellationToken)
        {
            return await this.GetQuery(searchRequest).CountAsync(cancellationToken);
        }


        private IQueryable<AppUser> GetQuery(SearchAppUser searchRequest)
        {
            var query = from AppUser in _context.AppUsers select AppUser;
            if (!string.IsNullOrEmpty(searchRequest.Nombres))
            {
                query = query.Where(m => m.Nombres.ToLower().Trim().Contains(searchRequest.Nombres.ToLower().Trim()));
            }
            if (!string.IsNullOrEmpty(searchRequest.Apellidos))
            {
                query = query.Where(m => m.Apellidos.ToLower().Trim().Contains(searchRequest.Apellidos.ToLower().Trim()));
            }
            if (searchRequest.PaisResidenciaId != null)
            {
                query = query.Where(m => m.PaisResidenciaId == searchRequest.PaisResidenciaId);
            }
            if (searchRequest.DepartamentoResidenciaId != null)
            {
                query = query.Where(m => m.DepartamentoResidenciaId == searchRequest.DepartamentoResidenciaId);
            }
            if (searchRequest.MunicipioResidenciaId != null)
            {
                query = query.Where(m => m.MunicipioResidenciaId == searchRequest.MunicipioResidenciaId);
            }
            if (searchRequest.FechaNacimientoMin != null)
            {
                query = query.Where(m => m.FechaNacimiento >= searchRequest.FechaNacimientoMin);
            }
            if (searchRequest.FechaNacimientoMax != null)
            {
                query = query.Where(m => m.FechaNacimiento <= searchRequest.FechaNacimientoMax);
            }
            if (searchRequest.GeneroId != null)
            {
                query = query.Where(m => m.GeneroId == searchRequest.GeneroId);
            }
            query = query.Include (x => x.PaisResidencia);
            query = query.Include (x => x.DepartamentoResidencia);
            query = query.Include (x => x.MunicipioResidencia);
            query = query.Include (x => x.Genero);
            return query;
        }

        private IQueryable<AppUser> SortQuery(IQueryable<AppUser> query, Sorter sorter)
        {

            switch (sorter.SortBy)
            {
                case "id":
                    if (sorter.SortOrder.Trim().ToLower().Equals("asc"))
                    {
                        query = query.OrderBy(x => x.Id);
                    }
                    else
                    {
                        query = query.OrderByDescending(x => x.Id);
                    }
                    break;

                // TODO. add cases to order by diferents attributes
            }
            return query;
        }

        public async Task<int> TotalCountPais(string codigo, CancellationToken cancellationToken)
        {
            var result = await _context.AppUsers.Where(x=>x.PaisResidencia.Codigo == codigo).CountAsync();
            return result;
        } 

        public async Task<PerfilEtiqueta> CreatePerfilEtiqueta(PerfilEtiqueta entity, CancellationToken cancellationToken)
        {
            var result = await _context.AddAsync(entity);
            await _context.SaveChangesAsync();
            return result.Entity;
        }

        public async Task<Interest> CreatePerfilTema(Interest entity, CancellationToken cancellationToken)
        {
            var result = await _context.AddAsync(entity);
            await _context.SaveChangesAsync();
            return result.Entity;
        }


        public async Task<List<PerfilEtiqueta>> ReadPerfilEtiqueta(Guid id)
        {
            var result = await _context.PerfilEtiqueta.Where(p => p.AppUserId == id).Include(x=>x.ListaItem).ToListAsync();

            return result;
        }

        public async Task<List<Interest>> ReadPerfilTema(Guid id)
        {
            var result = await _context.Intereses.Where(p => p.AppUserId == id).Include(x=>x.ListaItem).ToListAsync();

            return result;
        }

        public async Task DeletePerfilEtiqueta(Guid Id, CancellationToken cancellationToken)
        {

            var entity = await ReadPerfilEtiqueta(Id);

            if (entity.Count > 0)
            {
                foreach (var item in entity)
                {
                    _context.PerfilEtiqueta.Remove(item);
                    await _context.SaveChangesAsync(cancellationToken);
                }
                
            }
        }

         public async Task DeletePerfilTema(Guid Id, CancellationToken cancellationToken)
        {

            var entity = await ReadPerfilTema(Id);

            if (entity.Count > 0)
            {
                foreach (var item in entity)
                {
                    _context.Intereses.Remove(item);
                    await _context.SaveChangesAsync(cancellationToken);
                }
                
            }
        }

        public async Task<Project> CreateProject(Project entity, CancellationToken cancellationToken)
        {
            var result = await _context.AddAsync(entity);
            await _context.SaveChangesAsync();
            return result.Entity;
        }

        public async Task<Project> UpdateProject(Project entity, CancellationToken cancellationToken)
        {
            _context.Entry(entity).State = EntityState.Modified;
            await _context.SaveChangesAsync(cancellationToken);
            return entity;
        }

        public async Task<Project> ReadProject(Guid id, CancellationToken cancellationToken)
        {
            var result = await _context.Project.Where(x => x.Id == id)
                                                .FirstOrDefaultAsync(cancellationToken);
            return result;
        }

         public async Task<List<Guid?>> GetSugerencias(Guid id, List<Guid> temas, Paginator paginator)
        {


             var query = (from i in _context.Intereses
                               where i.AppUserId != id
                               && temas.Contains((Guid)i.ListaItemId)
                               select i.AppUserId).Distinct();

             return await query.Skip((paginator.PageNumber - 1) * paginator.PageSize)
                .Take(paginator.PageSize)
                .ToListAsync();              

        }


    }
}
