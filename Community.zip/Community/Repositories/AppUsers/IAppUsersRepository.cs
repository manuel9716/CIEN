using System;
using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;
using Community.Dtos.Pagination.Models;
using Community.Dtos.AppUsers.Models;
using Community.Models;
using Community.Models.interests;
using Community.Models.project;

namespace Community.Repositories.AppUsers
{
    public interface IAppUsersRepository
    {
        Task<AppUser> Create(AppUser entity, CancellationToken cancellationToken);
        Task<AppUser> Read(Guid id, CancellationToken cancellationToken);
        Task<AppUser> Update(AppUser entity, CancellationToken cancellationToken);
        Task Delete(Guid id, CancellationToken cancellationToken);
        Task<List<AppUser>> Search(Paginator paginator, Sorter sorter, SearchAppUser searchRequest, CancellationToken cancellationToken);
        Task<int> TotalCount(SearchAppUser searchRequest, CancellationToken cancellationToken);
        Task<int> TotalCountPais(string codigo, CancellationToken cancellationToken);
        Task<PerfilEtiqueta> CreatePerfilEtiqueta(PerfilEtiqueta entity, CancellationToken cancellationToken);
        Task<Interest> CreatePerfilTema(Interest entity, CancellationToken cancellationToken);
        Task<List<PerfilEtiqueta>> ReadPerfilEtiqueta(Guid id);
        Task<List<Interest>> ReadPerfilTema(Guid id);
        Task DeletePerfilEtiqueta(Guid Id, CancellationToken cancellationToken);
        Task DeletePerfilTema(Guid Id, CancellationToken cancellationToken);
        Task<Project> CreateProject(Project entity, CancellationToken cancellationToken);
        Task<Project> UpdateProject(Project entity, CancellationToken cancellationToken);
        Task<Project> ReadProject(Guid id, CancellationToken cancellationToken);
        Task<List<Guid?>> GetSugerencias(Guid id, List<Guid> temas, Paginator paginator);



    }
}
