using Community.DbContexts;
using Community.Dtos.Pagination.Models;
using Community.Models;
using Community.Models.notification;
using Community.Models.publication;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace Community.Repositories.Publications
{
    public class PublicationRepository : IPublicationRepository
    {
        private readonly CommunityDbContext _context;

        public PublicationRepository(CommunityDbContext context)
        {
            _context = context;
        }
        public async Task<List<Publication>> GetPublicaciones(Guid AppUserId, Paginator paginator)
        {

            var query = from publication in _context.Publicacion select publication;
            query = query.Where(p => p.FechaEliminacion == null
            && !p.Publicacionocultar.Any(z => z.AppUserId ==  AppUserId && z.PublicacionId == p.Id)
            && !p.Publicacionreportar.Any(z => z.AppUserId ==  AppUserId && z.PublicacionId == p.Id && z.Aprobacion == 1))
            .OrderByDescending(p => p.FechaCreacion);

             return await query.Skip((paginator.PageNumber - 1) * paginator.PageSize)
                .Take(paginator.PageSize)
                .Include(usuario => usuario.Usuario)
                .Include(comentario => comentario.Publicacioncomentario.Where(z => z.PadreId == null))
                    .ThenInclude(usuario => usuario.Usuario)
                .Include(iteracion => iteracion.Publicacioniteracion)
                    .ThenInclude(item => item.ListaItem)
                .Include(iteracioncomentario => iteracioncomentario.Publicacioncomentario)
                    .ThenInclude(i => i.Comentarioiteracion)
                    .ThenInclude(l => l.ListaItem)
                .ToListAsync();              

        }
        public async Task<List<Publication>> GetPublicacionId(Guid id)
        {
            return await _context.Publicacion.Where(p => p.Id == id)
                .Where(p => p.FechaEliminacion == null)
               .Include(usuario => usuario.Usuario)
              .Include(comentario => comentario.Publicacioncomentario.Where(z => z.PadreId == null))
                   .ThenInclude(usuario => usuario.Usuario)
               .Include(iteracion => iteracion.Publicacioniteracion)
                   .ThenInclude(item => item.ListaItem)
               .Include(iteracioncomentario => iteracioncomentario.Publicacioncomentario)
                   .ThenInclude(i => i.Comentarioiteracion)
                   .ThenInclude(l => l.ListaItem)
               .ToListAsync();
        }

         public async Task<List<Publication>> GetPublicacion(Guid id)
        {
       
                return await _context.Publicacion.Where(p => p.Id == id)
                 .Where(p => p.FechaEliminacion == null)
                .Include(usuario => usuario.Usuario)
                .Include(comentario => comentario.Publicacioncomentario)
                    .ThenInclude(usuario => usuario.Usuario)
                .Include(iteracion => iteracion.Publicacioniteracion)
                    .ThenInclude(item => item.ListaItem)
                .Include(iteracioncomentario => iteracioncomentario.Publicacioncomentario)
                    .ThenInclude(i => i.Comentarioiteracion)
                    .ThenInclude(l => l.ListaItem)
                .ToListAsync();    
        }
        public async Task<Publication> GetPublicacionCompartir(Guid id)
        {
            return await _context.Publicacion.Where(p => p.Id == id)
                 .Where(p => p.FechaEliminacion == null)
                .Include(usuario => usuario.Usuario)
               .Include(comentario => comentario.Publicacioncomentario.Where(z => z.PadreId == null))
                    .ThenInclude(usuario => usuario.Usuario)
                .Include(iteracion => iteracion.Publicacioniteracion)
                    .ThenInclude(item => item.ListaItem)
                .Include(iteracioncomentario => iteracioncomentario.Publicacioncomentario)
                    .ThenInclude(i => i.Comentarioiteracion)
                    .ThenInclude(l => l.ListaItem)
                .FirstOrDefaultAsync();
        }

        public async Task<List<Publication>> GetPublicacionUser(Guid AppUserId,Paginator paginator)
        {
             var query = from publication in _context.Publicacion select publication;
            query = query.Where(p => p.FechaEliminacion == null && p.AppUserId == AppUserId
            && !p.Publicacionocultar.Any(z => z.AppUserId ==  AppUserId && z.PublicacionId == p.Id)
            && !p.Publicacionreportar.Any(z => z.AppUserId ==  AppUserId && z.PublicacionId == p.Id && z.Aprobacion == 1))
            .OrderByDescending(p => p.FechaCreacion);

             return await query.Skip((paginator.PageNumber - 1) * paginator.PageSize)
                .Take(paginator.PageSize)
                .Include(usuario => usuario.Usuario)
                .Include(comentario => comentario.Publicacioncomentario.Where(z => z.PadreId == null))
                    .ThenInclude(usuario => usuario.Usuario)
                .Include(iteracion => iteracion.Publicacioniteracion)
                    .ThenInclude(item => item.ListaItem)
                .Include(iteracioncomentario => iteracioncomentario.Publicacioncomentario)
                    .ThenInclude(i => i.Comentarioiteracion)
                    .ThenInclude(l => l.ListaItem)
                .ToListAsync();    
        }

        public async Task<List<Publication>> GetPublicacionPorId(Guid AppUserId, Paginator paginator)
        {
             var query = from publication in _context.Publicacion select publication;
            query = query.Where(p => p.FechaEliminacion == null && p.AppUserId == AppUserId
            && !p.Publicacionocultar.Any(z => z.AppUserId ==  AppUserId && z.PublicacionId == p.Id)
            && !p.Publicacionreportar.Any(z => z.AppUserId ==  AppUserId && z.PublicacionId == p.Id && z.Aprobacion == 1))
            .OrderByDescending(p => p.FechaCreacion);

             return await query.Skip((paginator.PageNumber - 1) * paginator.PageSize)
                .Take(paginator.PageSize)
                .Include(usuario => usuario.Usuario)
                .Include(comentario => comentario.Publicacioncomentario.Where(z => z.PadreId == null))
                    .ThenInclude(usuario => usuario.Usuario)
                .Include(iteracion => iteracion.Publicacioniteracion)
                    .ThenInclude(item => item.ListaItem)
                .Include(iteracioncomentario => iteracioncomentario.Publicacioncomentario)
                    .ThenInclude(i => i.Comentarioiteracion)
                    .ThenInclude(l => l.ListaItem)
                .ToListAsync();
        }


        public async Task<List<Comment>> GetComentarioComentario(Guid id)
        {
            return await _context.Comentario.Where( p => p.PadreId == id)
             .Include(usuario => usuario.Usuario)
             .Include(comentario => comentario.Publicacion)
                 .ThenInclude(publicacion => publicacion.Publicacioniteracion)
                 .ThenInclude(publicacionIteracion => publicacionIteracion.ListaItem)
            .ToListAsync();
        }
        public async Task<List<Iteracion>> GetFavoritos(Guid AppUserId, Paginator paginator)
        {
            var query = from favorito in _context.Iteracion select favorito;
            query = query.Where(p => p.AppUserId == AppUserId && p.ListaItem.Codigo == "FV" && p.ComentarioId == null
            && !p.Publicacion.Publicacionocultar.Any(z => z.AppUserId ==  AppUserId && z.PublicacionId == p.Id)
            && !p.Publicacion.Publicacionreportar.Any(z => z.AppUserId == AppUserId && z.PublicacionId == p.Id && z.Aprobacion == 1))
                .OrderByDescending(p => p.FechaCreacion);

             return await query.Skip((paginator.PageNumber - 1) * paginator.PageSize)
                .Take(paginator.PageSize)
                 .Include(iteracion => iteracion.Publicacion)
                    .ThenInclude(u => u.Usuario)
                .ToListAsync();    

        }

        public async Task<List<Iteracion>> GetFavorito(Guid AppUserId)
        {

             return await _context.Iteracion.Where(p => p.AppUserId == AppUserId && p.ListaItem.Codigo == "FV" && p.ComentarioId == null
             && !p.Publicacion.Publicacionocultar.Any(z => z.AppUserId ==  AppUserId && z.PublicacionId == p.Id)
             && !p.Publicacion.Publicacionreportar.Any(z => z.AppUserId == AppUserId && z.PublicacionId == p.Id && z.Aprobacion == 1))
                 .Include(iteracion => iteracion.Publicacion)
                    .ThenInclude(u => u.Usuario)
                .OrderByDescending(p => p.FechaCreacion)
                .ToListAsync(); 
        }


        public async Task<Publication> Create(Publication entity, CancellationToken cancellationToken)
        {
            entity.FechaCreacion = DateTime.Now;
            entity.FechaActualizacion = DateTime.Now;

            var result = await _context.AddAsync(entity);
            
            await _context.SaveChangesAsync();
            return result.Entity;
        }
        public async Task<Comment> CreateComentariopublicacion(Comment entity, CancellationToken cancellationToken)
        {
            entity.FechaCreacion = DateTime.Now;
            entity.FechaActualizacion = DateTime.Now;

            var result = await _context.AddAsync(entity);

            await _context.SaveChangesAsync();
            return result.Entity;
        }

        public async Task<Iteracion> CreateIteracionComentario(Iteracion entity, CancellationToken cancellationToken)
        {
            entity.FechaCreacion = DateTime.Now;

            var result = await _context.AddAsync(entity);

            await _context.SaveChangesAsync();
            return result.Entity;
        }

        public async Task<Iteracion> CreateIteracionpublicacion(Iteracion entity, CancellationToken cancellationToken)
        {
            entity.FechaCreacion = DateTime.Now;

            var result = await _context.AddAsync(entity);

            await _context.SaveChangesAsync();
            return result.Entity;
        }

        public async Task<Publication_hide> CreatePublicacionOcultar(Publication_hide entity, CancellationToken cancellationToken)
        {
            entity.FechaCreacion = DateTime.Now;

            var result = await _context.AddAsync(entity);

            await _context.SaveChangesAsync();
            return result.Entity;
        }
        public async Task<Publication_report> CreatePublicacionReportar(Publication_report entity, CancellationToken cancellationToken)
        {
            entity.FechaCreacion = DateTime.Now;

            var result = await _context.AddAsync(entity);

            await _context.SaveChangesAsync();
            return result.Entity;
        }

        public async Task<Publication_file> CreatePublicacionFile(Publication_file entity, CancellationToken cancellationToken)
        {
            entity.FechaCreacion = DateTime.Now;

            var result = await _context.AddAsync(entity);

            await _context.SaveChangesAsync();
            return result.Entity;
        }

        public async Task<List<Publication_file>> ReadPublicacionFile(Guid publicationId)
        {
            var result = await _context.PublicacionFile.Where(p => p.PublicacionId == publicationId).ToListAsync();

            return result;
        }

        public async Task DeletePublicacionFile(Publication_file entity, CancellationToken cancellationToken)
        {
            if (entity != null)
            {
                _context.PublicacionFile.Remove(entity);
                await _context.SaveChangesAsync(cancellationToken);
            }
        }

        public async Task<Publication> Delete(Publication entity, CancellationToken cancellationToken)
        {
            entity.FechaEliminacion = DateTime.Now;
            _context.Entry(entity).State = EntityState.Modified;
            await _context.SaveChangesAsync(cancellationToken);
            return entity;
        }
       

         public async Task<Publication> Read(Guid id, CancellationToken cancellationToken)
        {
            return await _context.Publicacion.Where(p => p.Id == id)
                .Where(p => p.FechaEliminacion == null)
                .Include(usuario => usuario.Usuario)
                .FirstOrDefaultAsync(cancellationToken);
        }
        public async Task<Publication> ReadPublicacionCompartir(Guid idCompartir, Guid AppUserId)
        {
            return await _context.Publicacion.Where(p => p.CompartirId == idCompartir && p.AppUserId == AppUserId)
                .Where(p => p.FechaEliminacion == null)
                .Include(usuario => usuario.Usuario)
                .FirstOrDefaultAsync();
        }

        public async Task<Comment> ReadComentario(Guid id, CancellationToken cancellationToken)
        {
           return await _context.Comentario.Where(p => p.Id == id)
                .FirstOrDefaultAsync(cancellationToken);
        }
         public async Task<List<Comment>> ReadComentariosPublicacion(Guid idPublicacion)
        {
             return await _context.Comentario.Where(p => p.PublicacionId == idPublicacion)
                .ToListAsync();
        }
        public async Task<Comment> ReadComentarioUsuario(Guid id, Guid IdUser, CancellationToken cancellationToken)
        {
            return await _context.Comentario.Where(p => p.Id == id && p.AppUserId == IdUser)
               .FirstOrDefaultAsync(cancellationToken);
        }
        public async Task<Publication_report> ReadReportar(Guid idPublicacion, Guid IdUser, CancellationToken cancellationToken)
        {
            return await _context.PublicacionReportar.Where(p => p.PublicacionId == idPublicacion && p.AppUserId == IdUser)
                .FirstOrDefaultAsync(cancellationToken);
        }

        public async Task<ListaItem> ReadListaItem(Guid id, CancellationToken cancellationToken)
        {
            return await _context.ListasItem.Where(p => p.Id == id)
                .FirstOrDefaultAsync(cancellationToken);
        }

        public async Task<ListaItem> ReadListaItemIteracion(string TipoItem, CancellationToken cancellationToken)
        {
            return await _context.ListasItem.Where(p => p.Codigo == TipoItem)
               .FirstOrDefaultAsync(cancellationToken);
        }
        public async Task<List<Publication>> ReadListaItemIteracionIdPublicacion(Guid IdPublicacion)
        {

             return await _context.Publicacion.Where(p => p.FechaEliminacion == null && p.Id == IdPublicacion)
                .Include(iteracion => iteracion.Publicacioniteracion)
                    .ThenInclude(item => item.ListaItem)
                .ToListAsync();   

        }
         public async Task<List<Comment>> ReadListaItemIteracionIdComentario(Guid IdComentario)
        {
           return await _context.Comentario.Where(p => p.Id == IdComentario)
                .Include(iteracion => iteracion.Comentarioiteracion)
                    .ThenInclude(item => item.ListaItem)
                .ToListAsync();   
        }

        public async Task<AppUser> ReadUser(Guid id, CancellationToken cancellationToken)
        {
            return await _context.AppUsers.Where(p => p.Id == id)
                .FirstOrDefaultAsync(cancellationToken);
        }
        public async Task<Iteracion> ReadIteracion(Guid id, CancellationToken cancellationToken)
        {
           return await _context.Iteracion.Where(p => p.Id == id)
             .FirstOrDefaultAsync(cancellationToken);
        }

        public async Task<Iteracion> ReadIteracionFavorito(Guid id, CancellationToken cancellationToken)
        {
           return await _context.Iteracion.Where(p => p.Id == id && p.ListaItem.Codigo == "FV" && p.ComentarioId == null)
             .Include(usuario => usuario.Usuario)
             .Include(comentario => comentario.Publicacion)
                .ThenInclude(publicacion => publicacion.Publicacioniteracion)
                .ThenInclude(publicacionIteracion => publicacionIteracion.ListaItem)
             .FirstOrDefaultAsync(cancellationToken);
        }

        public async Task<Iteracion> ReadIteracionPublicacion(Guid idpublicacion, Guid AppUserId, Guid ListaItemId, CancellationToken cancellationToken)
        {
             return await _context.Iteracion.Where(p => p.PublicacionId == idpublicacion && p.AppUserId == AppUserId && p.ListaItemId == ListaItemId)
                .FirstOrDefaultAsync(cancellationToken);
        }
        public async Task<Iteracion> ReadIteracionComentario(Guid idcomentario, Guid AppUserId, Guid ListaItemId, CancellationToken cancellationToken)
        {
            return await _context.Iteracion.Where(p => p.ComentarioId == idcomentario && p.AppUserId == AppUserId && p.ListaItemId == ListaItemId)
                .FirstOrDefaultAsync(cancellationToken);
        }
        public async Task<List<Iteracion>> ReadIteracionComentarios(Guid IdComentario)
        {
            return await _context.Iteracion.Where(p => p.ComentarioId == IdComentario && p.ListaItem.Codigo == "ITEMG" && p.PublicacionId == null)
            .ToListAsync();
        }
        public async Task<AppFile> ReadFileId(Guid fileId)
        {
            return await _context.Files.Where(p => p.Id == fileId)
                .FirstOrDefaultAsync();
        }

        public async Task<Publication> Update(Publication entity, CancellationToken cancellationToken)
        {
            entity.FechaActualizacion = DateTime.Now;
            _context.Entry(entity).State = EntityState.Modified;
            await _context.SaveChangesAsync(cancellationToken);
            return entity;
        }
        public async Task DeleteIteracion(Guid id, CancellationToken cancellationToken)
        {
            
            var entity = await ReadIteracion(id, cancellationToken);
            if (entity != null)
            {
                _context.Iteracion.Remove(entity);
                await _context.SaveChangesAsync(cancellationToken);
            }

        }
        public async Task DeletePublicacionFile(Guid PublicacionId, CancellationToken cancellationToken)
        {

            var entity = await ReadPublicacionFile(PublicacionId);

            if (entity.Count > 0)
            {
                foreach (var item in entity)
                {
                    _context.PublicacionFile.Remove(item);
                    await _context.SaveChangesAsync(cancellationToken);
                }
                
            }
        }
        public async Task DeleteComentario(Guid ComentarioId, CancellationToken cancellationToken)
        {
            var entity = await ReadComentario(ComentarioId,cancellationToken);

            if (entity != null)
            {
                    _context.Comentario.Remove(entity);
                    await _context.SaveChangesAsync(cancellationToken);
                
            }

        }

    }
}