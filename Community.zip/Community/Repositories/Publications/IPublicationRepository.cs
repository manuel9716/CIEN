using Community.Dtos.Pagination.Models;
using Community.Models;
using Community.Models.notification;
using Community.Models.publication;
using System;
using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;


namespace Community.Repositories.Publications
{
    public interface IPublicationRepository
    {
        Task<List<Publication>> GetPublicaciones(Guid AppUserId,Paginator paginator);
        Task<List<Publication>> GetPublicacion(Guid id);
        Task<List<Publication>> GetPublicacionId(Guid id);
        Task<Publication> GetPublicacionCompartir(Guid id);
        Task<List<Publication>> GetPublicacionUser(Guid AppUserId,Paginator paginator);
        Task<List<Publication>> GetPublicacionPorId(Guid AppUserId,Paginator paginator);
        Task<List<Comment>> GetComentarioComentario(Guid id);
        Task<List<Iteracion>> GetFavoritos(Guid AppUserId,Paginator paginator);
        Task<List<Iteracion>> GetFavorito(Guid AppUserId);
        Task<Publication> Create(Publication entity, CancellationToken cancellationToken);
        Task<Comment> CreateComentariopublicacion(Comment entity, CancellationToken cancellationToken);
        Task<Iteracion> CreateIteracionpublicacion(Iteracion entity, CancellationToken cancellationToken);
        Task<Iteracion> CreateIteracionComentario(Iteracion entity, CancellationToken cancellationToken);
        Task<Publication_hide> CreatePublicacionOcultar(Publication_hide entity, CancellationToken cancellationToken);
        Task<Publication_report> CreatePublicacionReportar(Publication_report entity, CancellationToken cancellationToken);
        Task<Publication_file> CreatePublicacionFile(Publication_file entity, CancellationToken cancellationToken);
        Task<List<Publication_file>> ReadPublicacionFile(Guid publicationId);
        Task<Publication> Read(Guid id, CancellationToken cancellationToken);
        Task<Publication> ReadPublicacionCompartir(Guid idCompartir, Guid AppUserId);
        Task<AppUser> ReadUser(Guid id, CancellationToken cancellationToken);
        Task<ListaItem> ReadListaItem(Guid id, CancellationToken cancellationToken);
        Task<ListaItem> ReadListaItemIteracion(string TipoItem, CancellationToken cancellationToken);
        Task<List<Publication>> ReadListaItemIteracionIdPublicacion(Guid IdPublicacion);
        Task<List<Comment>> ReadListaItemIteracionIdComentario(Guid IdComentario);
        Task<Comment> ReadComentario(Guid id, CancellationToken cancellationToken);
        Task<List<Comment>> ReadComentariosPublicacion(Guid idPublicacion);
        Task<Comment> ReadComentarioUsuario(Guid id, Guid IdUser, CancellationToken cancellationToken);
        Task<Iteracion> ReadIteracionFavorito(Guid id,CancellationToken cancellationToken);
        Task<Iteracion> ReadIteracionPublicacion(Guid idpublicacion,Guid AppUserId,Guid ListaItemId, CancellationToken cancellationToken);
        Task<Iteracion> ReadIteracionComentario(Guid idcomentario,Guid AppUserId,Guid ListaItemId, CancellationToken cancellationToken);
         Task<List<Iteracion>> ReadIteracionComentarios(Guid IdComentario);
        Task<Publication_report> ReadReportar(Guid idPublicacion, Guid IdUser, CancellationToken cancellationToken);
        Task<AppFile> ReadFileId(Guid fileId);
        Task<Publication> Update(Publication entity, CancellationToken cancellationToken);
        Task<Publication> Delete(Publication entity, CancellationToken cancellationToken);
        Task DeleteIteracion(Guid id, CancellationToken cancellationToken);
        Task DeletePublicacionFile(Guid PublicacionId, CancellationToken cancellationToken);
        Task DeleteComentario(Guid ComentarioId, CancellationToken cancellationToken);
      
    }
}