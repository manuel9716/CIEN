﻿using Community.Models;
using System.Threading.Tasks;
using System.Threading;
using System.Collections.Generic;
using Community.Dtos.Pagination.Models;
using System;
using Community.Dtos.Cocrea.Models.inputsModels;
using Community.Dtos.Cocrea.Models.Retos;
using Community.Dtos.Cocrea.Models.Preguntas;
using Community.Dtos.Cocrea.Models.inputsModels.Preguntas;
using Community.Dtos.Cocrea.Models;
using Community.Dtos.Cocrea.Models.inputsModels.Retos;

namespace Community.Repositories.Cocrea
{
    public interface ICocreaRepository
    {
        Task<CocreaModels> GetListaPreguntas(Paginator paginator);
        Task<CocreaModels> GetListaPreguntasEX(Paginator paginator, Guid actorId);
        Task<PreguntaModels> GetPreguntaById(Paginator paginator,Guid Id, Guid actorId, bool desc, bool fecha);
        Task<CocreaModels> GetPreguntarandom();
        ResponseModels Insertpregunta(InputPreguntaModels Dta, Guid actorId);
        ResponseModels InsertRespPregunta(inputRespuestaModels Dta, Guid actorId);
        ResponseModels DeleteRespPregunta(Guid Id, Guid actorId);
        ResponseModels UpdateRespPregunta(InputUpdRespuestaModels Dta, Guid actorId);
        Task<CocreaComentModels>GetComentarioRespuesta(Paginator paginator, Guid Id);
        ResponseModels InsertComentarRespuesta(InputComRespModels Dta, Guid actorId);
        ResponseModels RespuestaLikeDislike(InputLikeDislikeModels Dta, Guid actorId);
        Task<RetoAdminModels> GetListaRetos(Paginator paginator);
        ResponseModels Insertreto(RetoModels Dta);
        Task<ParticipanteAdminModels> GetListaParticipantes(Paginator paginator);
        ResponseModels Insertparticipante(ParticipanteModels Dta);
        Task<TemaAdminModels> GetListaTemas(Paginator paginator);
        ResponseModels Inserttema(TemaModels Dta);
        Task<IncentivoRetoAdminModels> GetListaIncentivoRetos(Paginator paginator);
        Task<ResponseModels> IncentivoRetoInsert(IncentivoRetoModels Dta);
        Task<DocumentoRetoAdminModels> GetListaDocumentoRetos(Paginator paginator);
        Task<ResponseModels> DocumentoRetoInsert(DocumentoRetoModels Dta);
        Task<EtapaRetoAdminModels> EtapaRetosListaGet(Paginator paginator);
        Task<ResponseModels> EtapaRetoInsert(EtapaRetoModels Dta);
        Task<EntidadRetoAdminModels> EntidadRetosListaGet(Paginator paginator);
        Task<ResponseModels> EntidadRetoInsert(EntidadRetoModels Dta);
        Task<RetoExtendedModels> GetRetoExById(Guid Id);
        ResponseModels InsertRetoCompleto(InputRetoModels Dta, Guid actorId);
        ResponseModels UpdateRetoCompleto(InputUpdRetoModels Dta, Guid actorId);

    }
}
