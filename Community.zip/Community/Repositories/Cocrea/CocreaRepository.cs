﻿using Community.DbContexts;
using Community.Dtos.AppUsers.Models;
using Community.Dtos.Pagination.Models;
using Community.Models.interests;
using Community.Models.project;
using Community.Models;
using Community.Repositories.AppUsers;
using Microsoft.EntityFrameworkCore;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Threading;
using System;
using Community.Dtos.Cocrea.Models;
using Community.Models.Cocrea;
using System.ComponentModel;
using Microsoft.EntityFrameworkCore.Metadata.Internal;
using Community.Dtos.Cocrea.Models.inputsModels.Preguntas;
using Community.Dtos.Cocrea.Models.Preguntas;
using Community.Dtos.Cocrea.Models.Retos;
using System.Data.Common;
using Community.Dtos.Cocrea.Models.inputsModels.Retos;
using System.Security.Cryptography;


namespace Community.Repositories.Cocrea
{
    public class CocreaRepository : ICocreaRepository
    {
        private readonly CommunityDbContext _context;

        public CocreaRepository(CommunityDbContext context)
        {
            _context = context;
        }
        #region Preguntas
        public async Task<CocreaModels> GetListaPreguntas(Paginator paginator)
        {
            CocreaModels preguntasList = new CocreaModels();

            using (var db = _context)
            {
               var  pregList = await (from a in db.Pregunta orderby a.Contador ascending
                                      select new PreguntaModels {
                                          PreguntaId = a.Id,
                                          EntidadId = a.EntidadId,
                                          EntidadNombre = a.EntidadNombre,
                                          GrupoId = a.GrupoId,
                                          GrupoNombre = a.GrupoNombre,
                                          PreguntaTexto = a.PreguntaTexto,
                                          Justificacion = a.Justificacion,
                                          Estado = a.Estado,
                                          FechaCreacion = a.FechaCreacion,
                                          FechaModificacion = a.FechaModificacion,
                                          Autor = a.Autor,
                                          ModificadoPor= a.ModificadoPor,
                                          Contador= a.Contador
                                       }).ToListAsync();

                var PaginatorList = pregList.Skip((paginator.PageNumber - 1) * paginator.PageSize)
               .Take(paginator.PageSize).ToList();

                preguntasList.List = PaginatorList;
                preguntasList.Count = pregList.Count;

            }
                 return preguntasList;
        }

        public async Task<CocreaModels> GetListaPreguntasEX(Paginator paginator, Guid actorId)
        {
            CocreaModels preguntasList = new CocreaModels();
            List<PreguntaModels> Datalist = new List<PreguntaModels>();
           



            using (var db = _context)
            {

               var preguntas = await (from a in db.Pregunta orderby a.Contador ascending
                                       select new PreguntaModels
                                       {
                                           PreguntaId = a.Id,
                                           EntidadId = a.EntidadId,
                                           EntidadNombre = a.EntidadNombre,
                                           GrupoId = a.GrupoId,
                                           GrupoNombre = a.GrupoNombre,
                                           PreguntaTexto = a.PreguntaTexto,
                                           Justificacion = a.Justificacion,
                                           Estado = a.Estado,
                                           FechaCreacion = a.FechaCreacion,
                                           FechaModificacion = a.FechaModificacion,
                                           Autor = a.Autor,
                                           ModificadoPor = a.ModificadoPor,
                                           Contador = a.Contador,
                                       }).ToListAsync();

                  foreach (var item in preguntas)
                  {
                        var respuesta = (from a in db.Respuesta
                                         join b in db.AppUsers on a.Autor equals b.Id
                                         join c in db.Entidad on b.entidadid equals c.Id into nombreentidad
                                         from co in nombreentidad.DefaultIfEmpty()
                                         where a.PreguntaId == item.PreguntaId
                                         select new RespuestaModels
                                         {
                                             RespuestaId = a.Id,
                                             RespuestaTexto = a.RespuestaTexto,
                                             Estado = a.Estado,
                                             FechaCreacion = a.FechaCreacion,
                                             FechaModificacion = a.FechaModificacion,
                                             Autor = a.Autor,
                                             NombreAutor = b.Nombres + " " + b.Apellidos,
                                             Nombreentidad = co.Nombre,
                                             ModificadoPor = a.ModificadoPor,
                                             PreguntaId = a.PreguntaId,
                                             LikesCount = a.LikesCount,
                                             isLike = (db.RespuestaLike.Where(x => x.RespuestasId == a.Id && x.Estado == true && x.Autor == actorId).FirstOrDefault() == null ? false : true)
                                         }).ToList();

                           var  resp = respuesta.Skip((paginator.PageNumber - 1) * paginator.PageSize)
                             .Take(paginator.PageSize).ToList();


                    Datalist.Add(new PreguntaModels
                    {
                            PreguntaId = item.PreguntaId,
                            PreguntaTexto = item.PreguntaTexto,
                            Estado = item.Estado,
                            FechaCreacion = item.FechaCreacion,
                            FechaModificacion = item.FechaModificacion,
                            Autor = item.Autor,
                            ModificadoPor = item.ModificadoPor,
                            EntidadId = item.EntidadId,
                            EntidadNombre = item.EntidadNombre,
                            GrupoId = item.GrupoId,
                            GrupoNombre = item.GrupoNombre,
                            Contador = item.Contador,
                            Justificacion = item.Justificacion,
                            RespuestaList = resp
                    });
                  }
                var PaginatorList = Datalist.Skip((paginator.PageNumber - 1) * paginator.PageSize)
                .Take(paginator.PageSize).ToList();

                preguntasList.List = PaginatorList;
                preguntasList.Count = preguntas.Count;
            }
            return preguntasList;
        }

        public async Task<PreguntaModels> GetPreguntaById(Paginator paginator,Guid Id, Guid actorId, bool desc, bool fecha)
        {
            PreguntaModels pregunta = new PreguntaModels();
            List<RespuestaModels> resp = new List<RespuestaModels>();
            List<RespuestaModels> orderby = new List<RespuestaModels>();

            using (var db = _context)
            {
                pregunta = await (from a in db.Pregunta where a.Id == Id
                                       select new PreguntaModels
                                       {
                                           PreguntaId = a.Id,
                                           EntidadId = a.EntidadId,
                                           EntidadNombre = a.EntidadNombre,
                                           GrupoId = a.GrupoId,
                                           GrupoNombre = a.GrupoNombre,
                                           PreguntaTexto = a.PreguntaTexto,
                                           Justificacion = a.Justificacion,
                                           Estado = a.Estado,
                                           FechaCreacion = a.FechaCreacion,
                                           FechaModificacion = a.FechaModificacion,
                                           Autor = a.Autor,
                                           ModificadoPor = a.ModificadoPor,
                                           Contador = a.Contador
                                       }).FirstOrDefaultAsync();

                var respuesta = (from a in db.Respuesta 
                                 join b in db.AppUsers on a.Autor equals b.Id
                                 join c in db.Entidad on b.entidadid equals c.Id into nombreentidad
                                 from co in nombreentidad.DefaultIfEmpty()
                                 where a.PreguntaId == Id
                                 select new RespuestaModels
                                 {
                                     RespuestaId = a.Id,
                                     RespuestaTexto = a.RespuestaTexto,
                                     Estado = a.Estado,
                                     FechaCreacion = a.FechaCreacion,
                                     FechaModificacion = a.FechaModificacion,
                                     Autor = a.Autor,
                                     NombreAutor = b.Nombres + " " + b.Apellidos,
                                     Nombreentidad = co.Nombre,
                                     ModificadoPor = a.ModificadoPor,
                                     PreguntaId = a.PreguntaId,
                                     LikesCount = a.LikesCount,
                                     isLike = (db.RespuestaLike.Where(x => x.RespuestasId == a.Id && x.Estado == true && x.Autor == actorId).FirstOrDefault() == null ? false : true)
                                 }).ToList();

              

                 resp = respuesta.Skip((paginator.PageNumber - 1) * paginator.PageSize)
                          .Take(paginator.PageSize).ToList();

                if (desc && fecha)
                {
                    orderby = resp.OrderByDescending(x => x.FechaCreacion).ToList();
                }
                if (!desc && fecha)
                {
                    orderby = resp.OrderBy(x => x.FechaCreacion).ToList();
                }
                if (desc && !fecha)
                {
                    orderby = resp.OrderByDescending(x => x.LikesCount).ToList();
                }
                if (!desc && !fecha)
                {
                    orderby = resp.OrderBy(x => x.LikesCount).ToList();
                }

                
                pregunta.RespuestaList = orderby;
            }
              return pregunta;
        }

        public async Task<CocreaModels> GetPreguntarandom()
        {
            var preguntaRandom = new CocreaModels();
            using (var db = _context)
            {
             var random = await ( from a in db.Pregunta.OrderBy(x => Guid.NewGuid()).Take(8)
                                  select new PreguntaModels { 
                                        PreguntaTexto = a.PreguntaTexto,
                                        PreguntaId = a.Id,
                                        FechaCreacion = a.FechaCreacion,
                                        Contador = a.Contador
                                  }).ToListAsync();
                preguntaRandom.Count = random.Count();
                preguntaRandom.List = random;
            }
            return preguntaRandom;
        }

        public ResponseModels Insertpregunta(InputPreguntaModels Dta, Guid actorId)
        {
            var Reponsepreg = new ResponseModels();

            Reponsepreg.IsSuccess = false;

            try
            {
                using (var db = _context)
                {
                    using (var dbTransaction = db.Database.BeginTransaction())
                    {
                        try
                        {
                            var insertpregunta = new Pregunta();
                            insertpregunta.EntidadId = Dta.EntidadId;
                            insertpregunta.EntidadNombre = Dta.EntidadNombre;
                            insertpregunta.GrupoId = Dta.GrupoId;
                            insertpregunta.GrupoNombre = Dta.GrupoNombre;
                            insertpregunta.PreguntaTexto = Dta.PreguntaTexto;
                            insertpregunta.Justificacion = Dta.Justificacion;
                            insertpregunta.Estado = true;
                            insertpregunta.FechaCreacion = DateTime.Now;
                            insertpregunta.FechaModificacion = DateTime.Now;
                            insertpregunta.Autor = actorId;
                            insertpregunta.ModificadoPor = actorId;
                            insertpregunta.Contador = 0;

                            db.Entry(insertpregunta).State = EntityState.Added;
                            db.SaveChanges();
                            dbTransaction.Commit();
                            Reponsepreg.IsSuccess = true;
                            Reponsepreg.Message = "Registro insertado correctamente a la base de datos";
                        }
                        catch (Exception Ex)
                        {
                            dbTransaction.Rollback();
                            Reponsepreg.Message = "Se genero un error al insertar el registro en la base de datos:" + Ex;
                        }
                    }
                }
            }
            catch (Exception Ex)
            {
                Reponsepreg.Message = "Se genero un error al insertar el registro en la base de datos:" + Ex;
            }
            return Reponsepreg;
        }

        public ResponseModels InsertRespPregunta(inputRespuestaModels Dta, Guid actorId)
        {
            var ReponsepregRes = new ResponseModels();

            ReponsepregRes.IsSuccess = false;
            try
            {
                using (var db = _context)
                {
                    var RespXpreg = (from a in db.Pregunta 
                                     where a.Id == Dta.PreguntaId
                                     select new PreguntaModels
                                     { Contador=a.Contador}).FirstOrDefault();

                    if (RespXpreg != null)
                    {
                        if (RespXpreg.Contador < 100)
                        {
                            var contador = RespXpreg.Contador + 1;
                            var estado = contador == 100 ? false : true; 
                            using (var dbTransaction = db.Database.BeginTransaction())
                            {
                                try
                                {
                                    var insertRespuesta = new Respuesta();
                                    insertRespuesta.RespuestaTexto = Dta.RespuestaTexto;
                                    insertRespuesta.Estado = true;
                                    insertRespuesta.FechaCreacion = DateTime.Now;
                                    insertRespuesta.FechaModificacion = DateTime.Now;
                                    insertRespuesta.Autor = actorId;
                                    insertRespuesta.ModificadoPor = actorId;
                                    insertRespuesta.PreguntaId = Dta.PreguntaId;
                                    insertRespuesta.LikesCount = 0;
                                    db.Entry(insertRespuesta).State = EntityState.Added;

                                    var updatePregunt = db.Pregunta.FirstOrDefault(x => x.Id == Dta.PreguntaId);
                                    updatePregunt.Contador = contador;
                                    updatePregunt.ModificadoPor = actorId;
                                    updatePregunt.FechaModificacion = DateTime.Now;
                                    updatePregunt.Estado = estado;
                                    db.Pregunta.Attach(updatePregunt);
                                    db.Entry(updatePregunt).Property(x => x.Contador).IsModified = true;
                                    db.Entry(updatePregunt).Property(x => x.ModificadoPor).IsModified = true;
                                    db.Entry(updatePregunt).Property(x => x.FechaModificacion).IsModified = true;
                                    db.Entry(updatePregunt).Property(x => x.Estado).IsModified = true;
                                    db.SaveChanges();
                                    dbTransaction.Commit();
                                    ReponsepregRes.IsSuccess = true;
                                    ReponsepregRes.Message = "Registro insertado correctamente a la base de datos";
                                }
                                catch (Exception Ex)
                                {

                                    dbTransaction.Rollback();
                                    ReponsepregRes.Message = "Se genero un error al insertar el registro en la base de datos:" + Ex;

                                }
                            }
                        }
                        else
                        {
                            ReponsepregRes.Message = "Esta pregunta ya alcanzo la cantidad de respuestas permitidas.";
                        }
                    }
                    else
                    {
                        ReponsepregRes.Message = "pregunta no encontrada.";
                    }
                }
            }
            catch (Exception Ex)
            {
                ReponsepregRes.Message = "Se genero un error al insertar el registro en la base de datos:" + Ex;

            }
            return ReponsepregRes;
        }

        public ResponseModels DeleteRespPregunta(Guid Id, Guid actorId)
        {
            var ResponseDele = new ResponseModels();

            ResponseDele.IsSuccess = false;

            try
            {
                using (var db = _context)
                {
                    var pregunta = (from a in db.Pregunta
                                    join b in db.Respuesta on a.Id equals b.PreguntaId
                                    where b.Id == Id
                                    select new PreguntaModels { PreguntaId = a.Id,Contador = a.Contador,Autor = a.Autor }).FirstOrDefault();

                    if(pregunta != null)
                    {
                        if (pregunta.Autor == actorId)
                        {
                            var contador = pregunta.Contador - 1;
                            using (var dbTransaction = db.Database.BeginTransaction())
                            {
                                try
                                {
                                    var RepuestDate = db.Respuesta.Where(x => x.Id == Id).FirstOrDefault();
                                    if (RepuestDate != null)
                                    {
                                        db.Respuesta.Remove(RepuestDate);
                                        db.SaveChanges();

                                        var updatePregunt = db.Pregunta.FirstOrDefault(x => x.Id == pregunta.PreguntaId);
                                        updatePregunt.Contador = contador;
                                        updatePregunt.ModificadoPor = actorId;
                                        updatePregunt.FechaModificacion = DateTime.Now;
                                        updatePregunt.Estado = true;
                                        db.Pregunta.Attach(updatePregunt);
                                        db.Entry(updatePregunt).Property(x => x.Contador).IsModified = true;
                                        db.Entry(updatePregunt).Property(x => x.ModificadoPor).IsModified = true;
                                        db.Entry(updatePregunt).Property(x => x.FechaModificacion).IsModified = true;
                                        db.Entry(updatePregunt).Property(x => x.Estado).IsModified = true;
                                        db.SaveChanges();

                                        dbTransaction.Commit();
                                        ResponseDele.IsSuccess = true;
                                        ResponseDele.Message = "La respuesta fue eliminada correctamente";
                                    }
                                    else
                                    {
                                        ResponseDele.Message = "Respuesta no encontrada en la base de datos";
                                    }
                                }
                                catch (Exception Ex)
                                {
                                    dbTransaction.Rollback();
                                    ResponseDele.Message = "Ocurrio un error al eliminar la respuesta :" + Id + "   mas detalle del error:" + Ex;
                                }
                            }
                        }
                        else
                        {
                            ResponseDele.Message = "!No puede eliminar la respuesta¡ El usuario actual no corresponde con el autor de la respuesta";
                        }
                    }
                    else
                    {
                        ResponseDele.Message = "Respuesta no encontrada en la base de datos";
                    }
                }
            }
            catch (Exception Ex)
            {
                ResponseDele.Message = "Ocurrio un error al eliminar la respuesta :" + Id + "   mas detalle del error:" + Ex;
            }
               return ResponseDele;
        }

        public ResponseModels UpdateRespPregunta(InputUpdRespuestaModels Dta, Guid actorId)
        {
            var ResponseUpd = new ResponseModels();
            ResponseUpd.IsSuccess = false;
            try
            {
                using (var db = _context)
                {
                    using (var dbTransaction = db.Database.BeginTransaction())
                    {
                        try
                        {
                            var updRespuesta = db.Respuesta.Where(x => x.Id == Dta.RespuestaId).FirstOrDefault();
                            if (updRespuesta != null)
                            {
                                if (updRespuesta.Autor == actorId)
                                {
                                    updRespuesta.RespuestaTexto = Dta.RespuestaTexto;
                                    updRespuesta.FechaModificacion = DateTime.Now;
                                    db.Respuesta.Attach(updRespuesta);
                                    db.Entry(updRespuesta).Property(x => x.RespuestaTexto).IsModified = true;
                                    db.Entry(updRespuesta).Property(x => x.FechaModificacion).IsModified = true;
                                    db.SaveChanges();
                                    dbTransaction.Commit();
                                    ResponseUpd.IsSuccess = true;
                                    ResponseUpd.Message = "La respuesta fue editada correctamente";
                                }
                                else
                                {
                                  ResponseUpd.Message = "!No puede editar la respuesta¡ El usuario actual no corresponde con el autor de la respuesta";
                                }
                            }
                            else
                            {
                              ResponseUpd.Message = "Respuesta no encontrada en la base de datos";
                            }
                        }
                        catch (Exception Ex)
                        {
                            dbTransaction.Rollback();
                            ResponseUpd.Message = "Ocurrio un error al eliminar la respuesta :" + Dta.RespuestaId + "   mas detalle del error:" + Ex;
                        }
                    }
                }
            }
            catch (Exception Ex)
            {
                ResponseUpd.Message = "Ocurrio un error al eliminar la respuesta :" + Dta.RespuestaId + "   mas detalle del error:" + Ex; 
            }
             return ResponseUpd;
        }

        public async Task<CocreaComentModels> GetComentarioRespuesta(Paginator paginator, Guid Id)
        {
            var response = new CocreaComentModels();

            using (var db = _context)
            {
                var ExisteRespuesta = db.Respuesta.Where(x=>x.Id == Id).FirstOrDefault();
                   if(ExisteRespuesta != null)
                   {
                    var comentarios = await (from a in db.RespuestaComentario
                                             join b in db.AppUsers on a.Autor equals b.Id
                                             where a.RespuestaId == Id
                                             select new ComentRespuestaModels
                                             {
                                                ComentarioId = a.Id,
                                                ComentarioTexto = a.ComentarioTexto,
                                                Estado = a.Estado,
                                                FechaCreacion = a.FechaCreacion,
                                                FechaModificacion = a.FechaModificacion,
                                                Autor=a.Autor,
                                                NombreAutor = b.Nombres+" "+b.Apellidos,
                                                ModificadoPor=a.ModificadoPor,
                                                RespuestaId=a.RespuestaId
                                             }).ToListAsync();

                        var coment = comentarios.Skip((paginator.PageNumber - 1) * paginator.PageSize)
                       .Take(paginator.PageSize).ToList();

                    response.Count = comentarios.Count;
                    response.List = coment;
                   }
            }
                return response;
        }

        public ResponseModels InsertComentarRespuesta(InputComRespModels Dta, Guid actorId)
        {
            var response = new ResponseModels();
            response.IsSuccess = false;

            try
            {
                using (var db = _context)
                {
                    using (var dbTransaction = db.Database.BeginTransaction())
                    {
                        try
                        {
                            var Existrespuesta = db.Respuesta.Where(x => x.Id == Dta.RespuestaId).FirstOrDefault();
                            if (Existrespuesta != null)
                            {
                                var insertComentRespuesta = new RespuestaComentario();
                                insertComentRespuesta.RespuestaId = Dta.RespuestaId;
                                insertComentRespuesta.ComentarioTexto = Dta.ComentarioTexto;
                                insertComentRespuesta.FechaCreacion = DateTime.Now;
                                insertComentRespuesta.FechaCreacion = DateTime.Now;
                                insertComentRespuesta.Autor = actorId;
                                insertComentRespuesta.ModificadoPor = actorId;
                                insertComentRespuesta.Estado = true;

                                db.Entry(insertComentRespuesta).State = EntityState.Added;
                                db.SaveChanges();
                                dbTransaction.Commit();
                                response.IsSuccess = true;
                                response.Message = "Registro insertado correctamente a la base de datos";
                            }
                            else
                            {
                                response.Message = "Respuesta no encontrada en la base de datos";
                            }
                        }
                        catch (Exception Ex)
                        {
                            dbTransaction.Rollback();
                            response.Message = "Ocurrio un error al insertar el comentario a la respuesta: " + Dta.RespuestaId + "   mas detalle del error:" + Ex;

                        }
                    }
                }
            }
            catch (Exception Ex)
            {
                response.Message = "Ocurrio un error al insertar el comentario a la respuesta: " + Dta.RespuestaId + "   mas detalle del error:" + Ex;
            }
            return response;
        }

        public ResponseModels  RespuestaLikeDislike (InputLikeDislikeModels Dta, Guid actorId)
        {
            var response = new ResponseModels();
            response.IsSuccess = false;

            try
            {
                using (var db = _context)
                {
                    var valirespuesta = db.Respuesta.Where(x => x.Id == Dta.RespuestaId).FirstOrDefault();
                    if (valirespuesta != null)
                    {
                        using (var dbTransaction = db.Database.BeginTransaction())
                        {
                            try
                            {
                                var valiLike = db.RespuestaLike.Where(x => x.RespuestasId == Dta.RespuestaId && x.Autor == actorId).FirstOrDefault();
                                if (valiLike != null)
                                {
                                    if (Dta.Dta && !valiLike.Estado)
                                    {
                                        var contador = valirespuesta.LikesCount + 1;

                                        valiLike.Estado = Dta.Dta;
                                        valiLike.FechaModificacion = DateTime.Now;
                                        valiLike.ModificadoPor = actorId;
                                        db.RespuestaLike.Attach(valiLike);
                                        db.Entry(valiLike).Property(x => x.Estado).IsModified = true;
                                        db.Entry(valiLike).Property(x => x.FechaModificacion).IsModified = true;
                                        db.Entry(valiLike).Property(x => x.ModificadoPor).IsModified = true;

                                        valirespuesta.LikesCount = contador;
                                        valirespuesta.ModificadoPor = actorId;
                                        valirespuesta.FechaModificacion = DateTime.Now;
                                        db.Respuesta.Attach(valirespuesta);
                                        db.Entry(valirespuesta).Property(x => x.LikesCount).IsModified = true;
                                        db.Entry(valirespuesta).Property(x => x.ModificadoPor).IsModified = true;
                                        db.Entry(valirespuesta).Property(x => x.FechaModificacion).IsModified = true;
                                        db.SaveChanges();
                                        dbTransaction.Commit();
                                        response.IsSuccess = true;
                                        response.Message = "Se actualizo el like exitosamente.";
                                    }
                                    if(!Dta.Dta && valiLike.Estado)
                                    {
                                        var contador = valirespuesta.LikesCount!=0?valirespuesta.LikesCount - 1:0;

                                        valiLike.Estado = Dta.Dta;
                                        valiLike.FechaModificacion = DateTime.Now;
                                        valiLike.ModificadoPor = actorId;
                                        db.RespuestaLike.Attach(valiLike);
                                        db.Entry(valiLike).Property(x => x.Estado).IsModified = true;
                                        db.Entry(valiLike).Property(x => x.FechaModificacion).IsModified = true;
                                        db.Entry(valiLike).Property(x => x.ModificadoPor).IsModified = true;

                                        valirespuesta.LikesCount = contador;
                                        valirespuesta.ModificadoPor = actorId;
                                        valirespuesta.FechaModificacion = DateTime.Now;
                                        db.Respuesta.Attach(valirespuesta);
                                        db.Entry(valirespuesta).Property(x => x.LikesCount).IsModified = true;
                                        db.Entry(valirespuesta).Property(x => x.ModificadoPor).IsModified = true;
                                        db.Entry(valirespuesta).Property(x => x.FechaModificacion).IsModified = true;
                                        db.SaveChanges();
                                        dbTransaction.Commit();
                                        response.IsSuccess = true;
                                        response.Message = "Se actualizo el dislike exitosamente.";
                                    }
                                }
                                if(valiLike == null && Dta.Dta)
                                {
                                    var contador = valirespuesta.LikesCount + 1;

                                    var insertLike = new RespuestaLike();
                                    insertLike.Estado = Dta.Dta;
                                    insertLike.FechaCreacion = DateTime.Now;
                                    insertLike.FechaModificacion = DateTime.Now;
                                    insertLike.Autor = actorId;
                                    insertLike.ModificadoPor = actorId;
                                    insertLike.RespuestasId = Dta.RespuestaId;
                                    db.Entry(insertLike).State = EntityState.Added;

                                    valirespuesta.LikesCount = contador;
                                    valirespuesta.ModificadoPor = actorId;
                                    valirespuesta.FechaModificacion = DateTime.Now;
                                    db.Respuesta.Attach(valirespuesta);
                                    db.Entry(valirespuesta).Property(x => x.LikesCount).IsModified = true;
                                    db.Entry(valirespuesta).Property(x => x.ModificadoPor).IsModified = true;
                                    db.Entry(valirespuesta).Property(x => x.FechaModificacion).IsModified = true;

                                    db.SaveChanges();
                                    dbTransaction.Commit();
                                    response.IsSuccess = true;
                                    response.Message = "Registro insertado correctamente a la base de datos";
                                }
                            }
                            catch (Exception Ex)
                            {
                                dbTransaction.Rollback();
                                response.Message = "Ocurrio un error al insertar/actualizar el like: " + Dta.RespuestaId + "   mas detalle del error:" + Ex;

                            }
                        }
                    }
                    else
                    {
                        response.Message = "Respuesta no encontrada en la base de datos";
                    }

                }
            }
            catch (Exception Ex)
            {
                response.Message = "Ocurrio un error al insertar/actualizar el like: " + Dta.RespuestaId + "   mas detalle del error:" + Ex;
            }
                return response;

        }

        #endregion
        #region Retos
        #region Reto
        public async Task<RetoAdminModels> GetListaRetos(Paginator paginator)
        {
            var retoExtended = new RetoAdminModels();
            var RetoTempList =new List<RetoExtendedModels>(); 

               var relist = await(from a in _context.Reto select  a).ToListAsync();

                foreach (var item in relist)
                {
                var Incentivo = (from a in _context.IncentivoReto where a.RetoId == item.Id select new IncentivoRetoModels {IncentivoRetoId = a.Id,RetoId = a.RetoId,Nombre = a.Nombre,Descripcion = a.Descripcion,Estado = a.Estado}).ToList();
                var Documento = (from a in _context.DocumentoReto where a.RetoId == item.Id select new DocumentoRetoModels {DocumentoRetoId = a.Id,RetoId = a.RetoId,Tipo = a.Tipo,Webp = a.Webp,Base64 = a.Base64,NombreDocumento = a.NombreDocumento,FlagPortada = a.FlagPortada}).ToList();
                var Etapa = (from a in _context.EtapaReto where a.RetoId == item.Id select new EtapaRetoModels { EtapaRetoId = a.Id, RetoId = a.RetoId, Nombre = a.Nombre, FechaInicial = a.FechaInicial, FechaFinal = a.FechaFinal, Estado = a.Estado }).ToList();
                var Entidad = (from a in _context.EntidadReto where a.RetoId == item.Id select new EntidadRetoModels { EntidadRetoId = a.Id, RetoId = a.RetoId, EntidadId = a.EntidadId, NombreEntidad = a.NombreEntidad, Estado = a.Estado }).ToList();
                var TemaList = (from a in _context.TemaReto join b in _context.Tema on a.TemaId equals b.Id where a.RetoId == item.Id select new TemaRetoModels { Id = a.Id, RetoId = a.RetoId, Estado = a.Estado, TemaId = a.TemaId, nombreTema = b.Nombre, estadoTema = b.Estado }).ToList();
                var participante = (from a in _context.ParticipanteReto join b in _context.Participante on a.ParticipanteId equals b.Id where a.RetoId == item.Id select new ParticipanteRetoModels { ParticipanteRetoId = a.Id, RetoId = a.RetoId, Estado = a.Estado, ParticipanteId = a.ParticipanteId, nombreParticipante = b.Nombre, estadoparticipante = b.Estado, }).ToList();

                RetoTempList.Add(new RetoExtendedModels { RetoId = item.Id, Titulo = item.Titulo, Descripcion = item.Descripcion, FechaCreacion = item.FechaCreacion, Vistas = item.Vistas, Requisitos = item.Requisitos, Estado = item.Estado, Autor = item.Autor, FlagEstado = item.FlagEstado, IncentivoList = Incentivo, DocumentoList = Documento, EtapaList = Etapa, EntidadList = Entidad, TemaList = TemaList, ParticipanteList = participante }); }

             var PaginatorList = RetoTempList.Skip((paginator.PageNumber - 1) * paginator.PageSize)
              .Take(paginator.PageSize).ToList();
              var orderby = PaginatorList.OrderByDescending(x => x.FechaCierre).ToList();
            retoExtended.List = orderby;
            retoExtended.Count = RetoTempList.Count;

            return retoExtended;
        }

        public ResponseModels Insertreto(RetoModels Dta)
        {
            var Reponsereto = new ResponseModels();

            Reponsereto.IsSuccess = false;

            try
            {
                using (var db = _context)
                {
                    using (var dbTransaction = db.Database.BeginTransaction())
                    {
                        var insertreto = new Reto();
                        insertreto.Titulo = Dta.Titulo;
                        insertreto.Descripcion = Dta.Descripcion;
                        insertreto.FechaCreacion = DateTime.Now;
                        insertreto.FechaCierre = DateTime.Now;
                        insertreto.Vistas = Dta.Vistas;
                        insertreto.Requisitos = Dta.Requisitos;
                        insertreto.Estado = Dta.Estado;
                        insertreto.Autor = Dta.Autor;
                        insertreto.FlagEstado = Dta.FlagEstado;
                        

                        db.Entry(insertreto).State = EntityState.Added;
                        db.SaveChanges();
                        dbTransaction.Commit();
                        Reponsereto.IsSuccess = true;
                        Reponsereto.Message = "Registro insertado correctamente a la base de datos";
                    }
                }
            }
            catch (Exception Ex)
            {
                Reponsereto.Message = "Se genero un error al insertar el registro en la base de datos:" + Ex;
            }

            return Reponsereto;
        }
        public async Task<Reto> GetRetoById(Guid Id)
        {
            Reto reto = new Reto();

                 reto = await (from a in _context.Reto
                                  where a.Id == Id
                                  select new Reto
                                  {
                                      Id = a.Id,
                                      Titulo = a.Titulo,
                                      Descripcion = a.Descripcion,
                                      FechaCreacion = a.FechaCreacion,
                                      Vistas = a.Vistas,
                                      Requisitos = a.Requisitos,
                                      Estado = a.Estado,
                                      Autor = a.Autor,
                                      FlagEstado = a.FlagEstado
                                  }).FirstOrDefaultAsync();
            return reto;
        }
        public async Task<RetoExtendedModels> GetRetoExById(Guid Id)
        {
            RetoExtendedModels retoExtended = new RetoExtendedModels();
            

                var reto = await GetRetoById(Id);
                retoExtended.RetoId = reto.Id;
                retoExtended.Titulo = reto.Titulo;
                retoExtended.Descripcion = reto.Descripcion;
                retoExtended.FechaCreacion = reto.FechaCreacion;
                retoExtended.Vistas = reto.Vistas;
                retoExtended.Requisitos = reto.Requisitos;
                retoExtended.Estado = reto.Estado;
                retoExtended.Autor = reto.Autor;
                retoExtended.FlagEstado = reto.FlagEstado;
                retoExtended.IncentivoList = GetIncentivoById(Id).Result.List;
                retoExtended.DocumentoList = GetDocumentoById(Id).Result.List;
                retoExtended.EtapaList = GetEtapaById(Id).Result.List;
                retoExtended.EntidadList = GetEntidadById(Id).Result.List;
                retoExtended.TemaList = GetTemaExByRetoId(Id).Result.List;
                retoExtended.ParticipanteList = GetParticipanteExByRetoId(Id).Result.List;

            return retoExtended;
        }

        public ResponseModels InsertRetoCompleto(InputRetoModels Dta, Guid actorId)
        {
            var Responseret = new ResponseModels();

            Responseret.IsSuccess = false;

            try
            {
                using (var db = _context)
                {

                    using (var dbTransaction = db.Database.BeginTransaction())
                    {
                        try
                        {
                            var insertreto = new Reto();
                            insertreto.Titulo = Dta.Titulo;
                            insertreto.Descripcion = Dta.Descripcion;
                            insertreto.FechaCreacion = Dta.FechaCreacion;
                            insertreto.FechaCierre = Dta.FechaCierre;
                            insertreto.Vistas = Dta.Vistas;
                            insertreto.Requisitos = Dta.Requisitos;
                            insertreto.Estado = Dta.Estado;
                            insertreto.Autor = Dta.Autor;
                            insertreto.FlagEstado = Dta.FlagEstado;
                            db.Entry(insertreto).State = EntityState.Added;



                            foreach (var item in Dta.IncRetoList)
                            {
                                var insertincentivo = new IncentivoReto();
                                insertincentivo.RetoId = insertreto.Id;
                                insertincentivo.Nombre = item.Nombre;
                                insertincentivo.Descripcion = item.Descripcion;
                                insertincentivo.Estado = item.Estado;
                                db.Entry(insertincentivo).State = EntityState.Added;

                                
                            }

                            foreach (var item in Dta.DocRetoList)
                            {
                                var insertdocumento = new DocumentoReto();
                                insertdocumento.RetoId = insertreto.Id;
                                insertdocumento.Tipo = item.Tipo;
                                insertdocumento.Webp = item.Webp;
                                insertdocumento.Base64 = item.Base64;
                                insertdocumento.NombreDocumento = item.NombreDocumento;
                                insertdocumento.FlagPortada = item.FlagPortada;
                                db.Entry(insertdocumento).State = EntityState.Added;
                            }


                            foreach (var item in Dta.EtaRetoList)
                            {
                                var insertetapa = new EtapaReto();
                                insertetapa.RetoId = insertreto.Id;
                                insertetapa.Nombre = item.Nombre;
                                insertetapa.FechaInicial = item.FechaInicial;
                                insertetapa.FechaFinal = item.FechaFinal;
                                insertetapa.Estado = item.Estado;
                                db.Entry(insertetapa).State = EntityState.Added;
                            }

                            foreach (var item in Dta.EntRetoList)
                            {
                                var insertentidad = new EntidadReto();
                                insertentidad.RetoId = insertreto.Id;
                                insertentidad.NombreEntidad = item.NombreEntidad;
                                insertentidad.Estado = item.Estado;
                                db.Entry(insertentidad).State = EntityState.Added;
                            }

                            foreach (var item in Dta.TemRetoList)
                            {
                                var inserttema = new TemaReto();
                                inserttema.RetoId = insertreto.Id;
                                inserttema.TemaId = item.TemaId;
                                inserttema.Estado = true;
                                db.Entry(inserttema).State = EntityState.Added;
                            }

                            foreach (var item in Dta.PartiRetoList)
                            {
                                var insertparticipante = new ParticipanteReto();
                                insertparticipante.RetoId = insertreto.Id;
                                insertparticipante.ParticipanteId = item.ParticipanteId;
                                insertparticipante.Estado = true;
                                db.Entry(insertparticipante).State = EntityState.Added;
                            }
                            db.SaveChanges();
                            dbTransaction.Commit();
                            Responseret.IsSuccess = true;
                            Responseret.Message = "Registro insertado correctamente a la base de datos";

                        }
                        catch (Exception Ex)
                        {
                            dbTransaction.Rollback();
                            Responseret.Message = "Se genero un error al insertar el registro en la base de datos:" + Ex;

                        }
                    }
                }
            }
            catch (Exception Ex)
            {

                Responseret.Message = "Se genero un error al insertar el registro en la base de datos:" + Ex;
            }
            return Responseret;
        }

        public ResponseModels UpdateRetoCompleto(InputUpdRetoModels Dta, Guid actorId)
        {
            var ResponseUpd = new ResponseModels();

            ResponseUpd.IsSuccess = false;

            try
            {
                using (var db = _context)
                {

                    using (var dbTransaction = db.Database.BeginTransaction())
                    {
                        try
                        {
                            var updReto= db.Reto.Where(x => x.Id == Dta.IdReto).FirstOrDefault();
                            if (updReto != null)
                            {
                                if (updReto.Autor == actorId)
                                {
                                    
                                    updReto.Titulo = Dta.Titulo;
                                    updReto.Descripcion = Dta.Descripcion;
                                    updReto.FechaCierre = Dta.FechaCierre;
                                    updReto.Requisitos = Dta.Requisitos;
                                    updReto.Estado = Dta.Estado;
                                    updReto.FlagEstado = Dta.FlagEstado;
                                    db.Entry(updReto).Property(x => x.Titulo).IsModified = true;
                                    db.Entry(updReto).Property(x => x.Descripcion).IsModified = true;
                                    db.Entry(updReto).Property(x => x.FechaCierre).IsModified = true;
                                    db.Entry(updReto).Property(x => x.Requisitos).IsModified = true;
                                    db.Entry(updReto).Property(x => x.Estado).IsModified = true;
                                    db.Entry(updReto).Property(x => x.FlagEstado).IsModified = true;



                                    var incentivoReto = db.IncentivoReto.Where(x => x.RetoId == Dta.IdReto);
                                    if (incentivoReto !=null)
                                    {
                                        foreach (var element in incentivoReto)
                                        {
                                          if (element.RetoId == Dta.IdReto)
                                            {
                                                db.IncentivoReto.Remove(element);
                                                db.SaveChanges();
                                            }
                                        }
                                    }

                                    var documentoReto = db.DocumentoReto.Where(x => x.RetoId == Dta.IdReto);
                                    if (documentoReto != null)
                                    {
                                        foreach (var element in documentoReto)
                                        {
                                            if (element.RetoId == Dta.IdReto)
                                            {
                                                db.DocumentoReto.Remove(element);
                                                db.SaveChanges();
                                            }
                                        }
                                    }
                                  
                                    var etapaReto = db.EtapaReto.Where(x => x.RetoId == Dta.IdReto);
                                    if (etapaReto != null)
                                    {
                                        foreach (var element in etapaReto)
                                        {
                                            if (element.RetoId == Dta.IdReto)
                                            {
                                                db.EtapaReto.Remove(element);
                                                db.SaveChanges();
                                            }
                                        }
                                    }

                                    var entidadReto = db.EntidadReto.Where(x => x.RetoId == Dta.IdReto);
                                    if (entidadReto != null)
                                    {
                                        foreach (var element in entidadReto)
                                        {
                                            if (element.RetoId == Dta.IdReto)
                                            {
                                                db.EntidadReto.Remove(element);
                                                db.SaveChanges();
                                            }
                                        }
                                    }

                                    var temaReto = db.TemaReto.Where(x => x.RetoId == Dta.IdReto);
                                    if (temaReto != null)
                                    {
                                        foreach (var element in temaReto)
                                        {
                                            if (element.RetoId == Dta.IdReto)
                                            {
                                                db.TemaReto.Remove(element);
                                                db.SaveChanges();
                                            }
                                        }
                                    }

                                  
                                    var participanteReto = db.ParticipanteReto.Where(x => x.RetoId == Dta.IdReto);
                                    if (participanteReto != null)
                                    {
                                        foreach (var element in participanteReto)
                                        {
                                            if (element.RetoId == Dta.IdReto)
                                            {
                                                db.ParticipanteReto.Remove(element);
                                                db.SaveChanges();
                                            }
                                        }
                                    }


                                    foreach (var item in Dta.IncRetoList)
                                    {
                                        var updtincentivo = new IncentivoReto();
                                        updtincentivo.RetoId = updReto.Id;
                                        updtincentivo.Nombre = item.Nombre;
                                        updtincentivo.Descripcion = item.Descripcion;
                                        updtincentivo.Estado = item.Estado;
                                        db.Entry(updtincentivo).State = EntityState.Added;
                                    }

                                    foreach (var item in Dta.DocRetoList)
                                    {
                                        var updtdocumento = new DocumentoReto();
                                        updtdocumento.RetoId = updReto.Id;
                                        updtdocumento.Tipo = item.Tipo;
                                        updtdocumento.Webp = item.Webp;
                                        updtdocumento.Base64 = item.Base64;
                                        updtdocumento.NombreDocumento = item.NombreDocumento;
                                        updtdocumento.FlagPortada = item.FlagPortada;
                                        db.Entry(updtdocumento).State = EntityState.Added;
                                    }

                                    foreach (var item in Dta.EtaRetoList)
                                    {
                                        var updtetapa = new EtapaReto();
                                        updtetapa.RetoId = updReto.Id;
                                        updtetapa.Nombre = item.Nombre;
                                        updtetapa.FechaInicial = item.FechaInicial;
                                        updtetapa.FechaFinal = item.FechaFinal;
                                        updtetapa.Estado = item.Estado;
                                        db.Entry(updtetapa).State = EntityState.Added;
                                    }

                                    foreach (var item in Dta.EntRetoList)
                                    {
                                        var updentidad = new EntidadReto();
                                        updentidad.RetoId = updReto.Id;
                                        updentidad.NombreEntidad = item.NombreEntidad;
                                        updentidad.Estado = item.Estado;
                                        db.Entry(updentidad).State = EntityState.Added;
                                    }

                                    foreach (var item in Dta.TemRetoList)
                                    {
                                        var updtema = new TemaReto();
                                        updtema.RetoId = updReto.Id;
                                        updtema.TemaId = item.TemaId;
                                        updtema.Estado = true;
                                        db.Entry(updtema).State = EntityState.Added;
                                    }

                                    foreach (var item in Dta.PartiRetoList)
                                    {
                                        var updparticipante = new ParticipanteReto();
                                        updparticipante.RetoId = updReto.Id;
                                        updparticipante.ParticipanteId = item.ParticipanteId;
                                        updparticipante.Estado = true;
                                        db.Entry(updparticipante).State = EntityState.Added;
                                    }
                                    db.SaveChanges();
                                    dbTransaction.Commit();
                                    ResponseUpd.IsSuccess = true;
                                    ResponseUpd.Message = "Registro insertado correctamente a la base de datos";
                                }
                            }
                        }
                        catch (Exception Ex)
                        {
                            dbTransaction.Rollback();
                            ResponseUpd.Message = "Se genero un error al insertar el registro en la base de datos:" + Ex;

                        }
                    }
                }
            }
            catch (Exception Ex)
            {

                ResponseUpd.Message = "Se genero un error al insertar el registro en la base de datos:" + Ex;
            }
            return ResponseUpd;
        }

        #endregion
        #region Participante

        public async Task<ParticipanteAdminModels> GetListaParticipantes(Paginator paginator)
        {
            ParticipanteAdminModels participanteList = new ParticipanteAdminModels();

            using (var db = _context)
            {
                var partList = await (from a in db.Participante
                                      select new ParticipanteModels
                                      {
                                          ParticipanteId = a.Id,
                                          Nombre = a.Nombre,
                                          Estado = a.Estado
                                      }).ToListAsync();

                var PaginatorList = partList.Skip((paginator.PageNumber - 1) * paginator.PageSize)
               .Take(paginator.PageSize).ToList();

                participanteList.List = PaginatorList;
                participanteList.Count = partList.Count;

            }
            return participanteList;
        }
        public ResponseModels Insertparticipante(ParticipanteModels Dta)
        {
            var Reponseparticipante = new ResponseModels();

            Reponseparticipante.IsSuccess = false;

            try
            {
                using (var db = _context)
                {
                    using (var dbTransaction = db.Database.BeginTransaction())
                    {
                        var insertparticipante = new Participante();
                        insertparticipante.Nombre = Dta.Nombre;
                        insertparticipante.Estado = Dta.Estado;

                        db.Entry(insertparticipante).State = EntityState.Added;
                        db.SaveChanges();
                        dbTransaction.Commit();
                        Reponseparticipante.IsSuccess = true;
                        Reponseparticipante.Message = "Registro insertado correctamente a la base de datos";
                    }
                }
            }
            catch (Exception Ex)
            {
                Reponseparticipante.Message = "Se genero un error al insertar el registro en la base de datos:" + Ex;
            }

            return Reponseparticipante;
        }
        public async Task<Participante> GetParticipanteById(Guid Id)
        {
            Participante participante = new Participante();

            participante = await (from a in _context.Participante
                          where a.Id == Id
                          select new Participante
                          {
                              Id = a.Id,
                              Nombre = a.Nombre,
                              Estado = a.Estado

                          }).FirstOrDefaultAsync();
            return participante;
        }
        public async Task<ParticipanteRetoAdminModels> GetParticipanteRetoByRetoId(Guid Id)
        {
            ParticipanteRetoAdminModels participanteretoList = new ParticipanteRetoAdminModels();


            {
                var partreList = await (from a in _context.ParticipanteReto
                                       where a.RetoId == Id
                                       select new ParticipanteRetoModels
                                       {
                                           ParticipanteRetoId = a.Id,
                                           RetoId = a.Id,
                                           Estado = a.Estado,
                                       }).ToListAsync();



                participanteretoList.List = partreList;
                participanteretoList.Count = partreList.Count;

            }
            return participanteretoList;
        }
        public async Task<ParticipanteRetoAdminModels> GetParticipanteExByRetoId(Guid Id)
        {
            ParticipanteRetoAdminModels list = new ParticipanteRetoAdminModels();

            using (var db = _context)
            {
                try
                {
                    var participanteRetos = await (from a in db.ParticipanteReto
                                                   join b in db.Participante on a.ParticipanteId equals b.Id
                                                   where a.RetoId == Id
                                                   select new ParticipanteRetoModels
                                                   {
                                                       ParticipanteRetoId = a.Id,
                                                       RetoId = a.RetoId,
                                                       Estado = a.Estado,
                                                       ParticipanteId = a.ParticipanteId,
                                                       nombreParticipante = b.Nombre,
                                                       estadoparticipante = b.Estado,
                                                   }).ToListAsync();

                    list.List = participanteRetos;
                    list.Count = participanteRetos.Count;
                }
                catch (Exception Ex)
                {

                    throw;
                }
            }

            return list;
        }

        #endregion
        #region Tema
        public async Task<TemaAdminModels> GetListaTemas(Paginator paginator)
        {
            TemaAdminModels temaList = new TemaAdminModels();

            using (var db = _context)
            {
                var temList = await (from a in db.Tema
                                      select new TemaModels
                                      {
                                          TemaId = a.Id,
                                          Nombre = a.Nombre,
                                          Estado = a.Estado,
                                          Descripcion = a.Descripcion
                                      }).ToListAsync();

                var PaginatorList = temList.Skip((paginator.PageNumber - 1) * paginator.PageSize)
               .Take(paginator.PageSize).ToList();

                temaList.List = PaginatorList;
                temaList.Count = temList.Count;

            }
            return temaList;
        }
        public ResponseModels Inserttema(TemaModels Dta)
        {
            var Reponsetema = new ResponseModels();

            Reponsetema.IsSuccess = false;

            try
            {
                using (var db = _context)
                {
                    using (var dbTransaction = db.Database.BeginTransaction())
                    {
                        var inserttema = new Tema();
                        inserttema.Nombre = Dta.Nombre;
                        inserttema.Estado = Dta.Estado;
                        inserttema.Descripcion = Dta.Descripcion;

                        db.Entry(inserttema).State = EntityState.Added;
                        db.SaveChanges();
                        dbTransaction.Commit();
                        Reponsetema.IsSuccess = true;
                        Reponsetema.Message = "Registro insertado correctamente a la base de datos";
                    }
                }
            }
            catch (Exception Ex)
            {
                Reponsetema.Message = "Se genero un error al insertar el registro en la base de datos:" + Ex;
            }

            return Reponsetema;
        }
        public async Task<Tema> GetTemaById(Guid Id)
        {
            Tema tema = new Tema();


            using (var db = _context)
            {
                tema = await (from a in db.Tema
                              where a.Id == Id
                              select new Tema
                              {
                                  Id = a.Id,
                                  Nombre = a.Nombre,
                                  Estado = a.Estado,
                                  Descripcion = a.Descripcion,

                              }).FirstOrDefaultAsync(); 
            }
            return tema;
        }
        public async Task<TemaRetoAdminModels> GetTemaRetoByRetoId(Guid Id)
        {
            TemaRetoAdminModels temaretoList = new TemaRetoAdminModels();



            using (var db = _context)
            {
                var temreList = await (from a in db.TemaReto
                                       where a.RetoId == Id
                                       select new TemaRetoModels
                                       {
                                           Id = a.Id,
                                           RetoId = a.Id,
                                           Estado = a.Estado,
                                           TemaId = a.TemaId,
                                       }).ToListAsync();



                temaretoList.List = temreList;
                temaretoList.Count = temreList.Count; 
            }
            return temaretoList;
        }
        public async Task<TemaRetoAdminModels> GetTemaExByRetoId(Guid Id)
        {
            TemaRetoAdminModels list = new TemaRetoAdminModels();

          
                var temaRetos = await (from a in _context.TemaReto
                                       join b in _context.Tema on a.TemaId equals b.Id
                                       where a.RetoId == Id
                                       select new TemaRetoModels
                                       {
                                           Id = a.Id,
                                           RetoId = a.RetoId,
                                           Estado = a.Estado,
                                           TemaId = a.TemaId,
                                           nombreTema = b.Nombre,
                                           estadoTema = b.Estado
                                       }).ToListAsync();
                list.List = temaRetos;
                list.Count = temaRetos.Count; 
            

            return list;
        }
        #endregion
        #region IncentivoReto
        public async Task<IncentivoRetoAdminModels> GetListaIncentivoRetos(Paginator paginator)
        {
            IncentivoRetoAdminModels incentivoretoList = new IncentivoRetoAdminModels();

            using (var db = _context)
            {
                var incentivoreList = await (from a in db.IncentivoReto
                                      select new IncentivoRetoModels
                                      {
                                          IncentivoRetoId = a.Id,
                                          RetoId = a.RetoId,
                                          Nombre = a.Nombre,
                                          Descripcion = a.Descripcion,
                                          Estado = a.Estado
                                      }).ToListAsync();

                var PaginatorList = incentivoreList.Skip((paginator.PageNumber - 1) * paginator.PageSize)
               .Take(paginator.PageSize).ToList();

                incentivoretoList.List = PaginatorList;
                incentivoretoList.Count = incentivoreList.Count;

            }
            return incentivoretoList;
        }
        public async Task<ResponseModels> IncentivoRetoInsert(IncentivoRetoModels Dta)
        {
            var Reponseincentivoreto = new ResponseModels();

            Reponseincentivoreto.IsSuccess = false;

            try
            {
                    using (var dbTransaction = _context.Database.BeginTransaction())
                    {
                        var insertincentivoreto = new IncentivoReto();
                        insertincentivoreto.Reto = await GetRetoById(Dta.RetoId);
                        insertincentivoreto.Nombre = Dta.Nombre;
                        insertincentivoreto.Descripcion = Dta.Descripcion;
                        insertincentivoreto.Estado = Dta.Estado;

                        _context.Entry(insertincentivoreto).State = EntityState.Added;
                        _context.SaveChanges();
                        dbTransaction.Commit();
                        Reponseincentivoreto.IsSuccess = true;
                        Reponseincentivoreto.Message = "Registro insertado correctamente a la base de datos";
                    }
            }
            catch (Exception Ex)
            {
                Reponseincentivoreto.Message = "Se genero un error al insertar el registro en la base de datos:" + Ex;
            }

            return Reponseincentivoreto;
        }
        public async Task<IncentivoRetoAdminModels> GetIncentivoById(Guid Id)
        {
            IncentivoRetoAdminModels retoList = new IncentivoRetoAdminModels();

            var retos = await (from a in _context.IncentivoReto
                          where a.RetoId == Id
                          select new IncentivoRetoModels
                          {
                              IncentivoRetoId = a.Id,
                              RetoId = a.RetoId,
                              Nombre = a.Nombre,
                              Descripcion = a.Descripcion,
                              Estado = a.Estado
                          }).ToListAsync();
            retoList.List = retos;
            retoList.Count = retos.Count;
            return retoList;
        }
        #endregion
        #region DocumentoReto
        public async Task<DocumentoRetoAdminModels> GetListaDocumentoRetos(Paginator paginator)
        {
            DocumentoRetoAdminModels documentoretoList = new DocumentoRetoAdminModels();

                var documentoreList = await (from a in _context.DocumentoReto
                                             select new DocumentoRetoModels
                                             {
                                                 DocumentoRetoId = a.Id,
                                                 RetoId = a.RetoId,
                                                 Tipo = a.Tipo,
                                                 Webp = a.Webp,
                                                 Base64 = a.Base64,
                                                 NombreDocumento = a.NombreDocumento,
                                                 FlagPortada = a.FlagPortada
                                                 
                                             }).ToListAsync();

                var PaginatorList = documentoreList.Skip((paginator.PageNumber - 1) * paginator.PageSize)
               .Take(paginator.PageSize).ToList();

                documentoretoList.List = PaginatorList;
                documentoretoList.Count = documentoreList.Count;

            
            return documentoretoList;
        }
        public async Task<ResponseModels> DocumentoRetoInsert(DocumentoRetoModels Dta)
        {
            var Reponsedocumentoreto = new ResponseModels();

            Reponsedocumentoreto.IsSuccess = false;

            try
            {
                using (var dbTransaction = _context.Database.BeginTransaction())
                {
                    var insertdocumentoreto = new DocumentoReto();
                    insertdocumentoreto.Reto = await GetRetoById(Dta.RetoId);
                    insertdocumentoreto.Tipo = Dta.Tipo;
                    insertdocumentoreto.Webp = Dta.Webp;
                    insertdocumentoreto.Base64 = Dta.Base64;
                    insertdocumentoreto.NombreDocumento = Dta.NombreDocumento;
                    insertdocumentoreto.FlagPortada = Dta.FlagPortada;

                    _context.Entry(insertdocumentoreto).State = EntityState.Added;
                    _context.SaveChanges();
                    dbTransaction.Commit();
                    Reponsedocumentoreto.IsSuccess = true;
                    Reponsedocumentoreto.Message = "Registro insertado correctamente a la base de datos";
                }
            }
            catch (Exception Ex)
            {
                Reponsedocumentoreto.Message = "Se genero un error al insertar el registro en la base de datos:" + Ex;
            }

            return Reponsedocumentoreto;
        }
        public async Task<DocumentoRetoAdminModels> GetDocumentoById(Guid Id)
        {
            DocumentoRetoAdminModels documentoList = new DocumentoRetoAdminModels();

            var retos = await (from a in _context.DocumentoReto
                               where a.RetoId == Id
                               select new DocumentoRetoModels
                               {
                                   DocumentoRetoId = a.Id,
                                   RetoId = a.RetoId,
                                   Tipo = a.Tipo,
                                   Webp = a.Webp,
                                   Base64 = a.Base64,
                                   NombreDocumento = a.NombreDocumento,
                                   FlagPortada = a.FlagPortada
                               }).ToListAsync();
            documentoList.List = retos;
            documentoList.Count = retos.Count;
            return documentoList;
        }

        #endregion
        #region EtapaReto
        public async Task<EtapaRetoAdminModels> EtapaRetosListaGet(Paginator paginator)
        {
            EtapaRetoAdminModels etaparetoList = new EtapaRetoAdminModels();

            var etapareList = await (from a in _context.EtapaReto
                                         select new EtapaRetoModels
                                         {
                                             EtapaRetoId = a.Id,
                                             RetoId = a.RetoId,
                                             Nombre = a.Nombre,
                                             FechaInicial = a.FechaInicial,
                                             FechaFinal = a.FechaFinal,
                                             Estado = a.Estado
                                         }).ToListAsync();

            var PaginatorList = etapareList.Skip((paginator.PageNumber - 1) * paginator.PageSize)
           .Take(paginator.PageSize).ToList();

            etaparetoList.List = PaginatorList;
            etaparetoList.Count = etapareList.Count;


            return etaparetoList;
        }
        public async Task<ResponseModels> EtapaRetoInsert(EtapaRetoModels Dta)
        {
            var Reponseetapareto = new ResponseModels();

            Reponseetapareto.IsSuccess = false;

            try
            {
                using (var dbTransaction = _context.Database.BeginTransaction())
                {
                    var insertetapareto = new EtapaReto();
                    insertetapareto.Reto = await GetRetoById(Dta.RetoId);
                    insertetapareto.Nombre = Dta.Nombre;
                    insertetapareto.FechaInicial = Dta.FechaInicial;
                    insertetapareto.FechaFinal = Dta.FechaFinal;
                    insertetapareto.Estado = Dta.Estado;

                    _context.Entry(insertetapareto).State = EntityState.Added;
                    _context.SaveChanges();
                    dbTransaction.Commit();
                    Reponseetapareto.IsSuccess = true;
                    Reponseetapareto.Message = "Registro insertado correctamente a la base de datos";
                }
            }
            catch (Exception Ex)
            {
                Reponseetapareto.Message = "Se genero un error al insertar el registro en la base de datos:" + Ex;
            }

            return Reponseetapareto;
        }
        public async Task<EtapaRetoAdminModels> GetEtapaById(Guid Id)
        {
            EtapaRetoAdminModels etapaList = new EtapaRetoAdminModels();

            var retos = await (from a in _context.EtapaReto
                               where a.RetoId == Id
                               select new EtapaRetoModels
                               {
                                   EtapaRetoId = a.Id,
                                   RetoId = a.RetoId,
                                   Nombre = a.Nombre,
                                   FechaInicial = a.FechaInicial,
                                   FechaFinal = a.FechaFinal,
                                   Estado = a.Estado
                               }).ToListAsync();
            etapaList.List = retos;
            etapaList.Count = retos.Count;
            return etapaList;
        }
        #endregion
        #region EntidadReto
        public async Task<EntidadRetoAdminModels> EntidadRetosListaGet(Paginator paginator)
        {
            EntidadRetoAdminModels entidadretoList = new EntidadRetoAdminModels();

            var entidadreList = await (from a in _context.EntidadReto
                                     select new EntidadRetoModels
                                     {
                                         EntidadRetoId = a.Id,
                                         RetoId = a.RetoId,
                                         EntidadId = a.EntidadId,
                                         NombreEntidad = a.NombreEntidad,
                                         Estado = a.Estado
                                     }).ToListAsync();

            var PaginatorList = entidadreList.Skip((paginator.PageNumber - 1) * paginator.PageSize)
           .Take(paginator.PageSize).ToList();

            entidadretoList.List = PaginatorList;
            entidadretoList.Count = entidadreList.Count;


            return entidadretoList;
        }
        public async Task<ResponseModels> EntidadRetoInsert(EntidadRetoModels Dta)
        {
            var Reponseentidadreto = new ResponseModels();

            Reponseentidadreto.IsSuccess = false;

            try
            {
                using (var dbTransaction = _context.Database.BeginTransaction())
                {
                    var insertentidadreto = new EntidadReto();
                    insertentidadreto.Reto = await GetRetoById(Dta.RetoId);
                    insertentidadreto.EntidadId = Dta.EntidadId;
                    insertentidadreto.NombreEntidad = Dta.NombreEntidad;
                    insertentidadreto.Estado = Dta.Estado;

                    _context.Entry(insertentidadreto).State = EntityState.Added;
                    _context.SaveChanges();
                    dbTransaction.Commit();
                    Reponseentidadreto.IsSuccess = true;
                    Reponseentidadreto.Message = "Registro insertado correctamente a la base de datos";
                }
            }
            catch (Exception Ex)
            {
                Reponseentidadreto.Message = "Se genero un error al insertar el registro en la base de datos:" + Ex;
            }

            return Reponseentidadreto;
        }
        public async Task<EntidadRetoAdminModels> GetEntidadById(Guid Id)
        {
            EntidadRetoAdminModels entidadList = new EntidadRetoAdminModels();

            var retos = await (from a in _context.EntidadReto
                               where a.RetoId == Id
                               select new EntidadRetoModels
                               {
                                   EntidadRetoId = a.Id,
                                   RetoId = a.RetoId,
                                   EntidadId = a.EntidadId,
                                   NombreEntidad = a.NombreEntidad,
                                   Estado = a.Estado
                               }).ToListAsync();
            entidadList.List = retos;
            entidadList.Count = retos.Count;
            return entidadList;
        }
        #endregion
        #endregion
    }
}
