﻿using Community.Models.tool;
using System;
using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;

namespace Community.Repositories.Equipos
{
    public interface IEquiposRepository
    {
        Task<ToolTeam> CreateEquipo(ToolTeam entity, CancellationToken cancellationToken);
    }
}
