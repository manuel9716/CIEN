﻿using Community.DbContexts;
using Community.Models.tool;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace Community.Repositories.Equipos
{
    public class EquiposRepository : IEquiposRepository
    {
        private readonly CommunityDbContext _context;
        public EquiposRepository(CommunityDbContext context)
        {
            _context = context;
        }
        public async Task<ToolTeam> CreateEquipo(ToolTeam entity, CancellationToken cancellationToken)
        {
            var result = await _context.AddAsync(entity);
            await _context.SaveChangesAsync();
            return result.Entity;
        }
    }
}
