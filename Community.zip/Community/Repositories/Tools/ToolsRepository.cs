﻿using Community.DbContexts;
using Community.Models.tool;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace Community.Repositories.Tools
{
    public class ToolsRepository : IToolsRepository
    {
        private readonly CommunityDbContext _context;
        public ToolsRepository(CommunityDbContext context)
        {
            _context = context;
        }

        public async Task<Tool> Create(Tool entity, CancellationToken cancellationToken)
        {
            var result = await _context.AddAsync(entity);
            await _context.SaveChangesAsync();
            return result.Entity;
        }
        public async Task<Tool> Read(Guid id, CancellationToken cancellationToken)
        {
            return await _context.Herramienta.Where(Tool => Tool.AppUserId == id)
                //.Include(tool => tool.TipoRecurso)
                    //.ThenInclude(ListasItem => ListasItem.TipoRecursoID)
                //.Include(t => t.ToolFases)
                //.Include(t => t.ToolTareas)
                //.Include(t => t.ToolEquipos)
                .FirstOrDefaultAsync(cancellationToken);
        }
        public async Task<Tool> Update(Tool entity, CancellationToken cancellationToken)
        {
            _context.Entry(entity).State = EntityState.Modified;
            await _context.SaveChangesAsync(cancellationToken);
            return entity;
        }
    }
}
