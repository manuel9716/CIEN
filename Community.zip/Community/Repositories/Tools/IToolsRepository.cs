﻿using Community.Models.tool;
using System;
using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;

namespace Community.Repositories.Tools
{
    public interface IToolsRepository
    {
        Task<Tool> Create(Tool entity, CancellationToken cancellationToken);
        Task<Tool> Read(Guid id, CancellationToken cancellationToken);
        Task<Tool> Update(Tool entity, CancellationToken cancellationToken);
    }
}
