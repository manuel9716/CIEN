﻿using Community.Models.tool;
using System;
using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;

namespace Community.Repositories.Tareas
{
    public interface ITareasRepository
    {
        Task<ToolTask> CreateTarea(ToolTask entity, CancellationToken cancellationToken);
    }
}
