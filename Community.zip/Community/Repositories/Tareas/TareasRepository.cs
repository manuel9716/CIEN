﻿using Community.DbContexts;
using Community.Models.tool;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace Community.Repositories.Tareas
{
    public class TareasRepository : ITareasRepository
    {
        private readonly CommunityDbContext _context;
        public TareasRepository(CommunityDbContext context)
        {
            _context = context;
        }
        public async Task<ToolTask> CreateTarea(ToolTask entity, CancellationToken cancellationToken)
        {
            var result = await _context.AddAsync(entity);
            await _context.SaveChangesAsync();
            return result.Entity;
        }
    }
}
