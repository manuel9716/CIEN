﻿using Community.DbContexts;
using Community.Dtos.Pagination.Models;
using Community.Models;
using Community.Models.ChatBot;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace Community.Repositories.ChatBot
{
    public class ChatBotRepository : IChatBotRepository
    {
        private readonly CommunityDbContext _context;

        public ChatBotRepository(CommunityDbContext context)
        {
            _context = context;
        }

        public async Task<List<MensajeChatbot>> GetMensajesChatBot(string llave, string email)
        {

            var query = from chatBot in _context.ChatBot select chatBot;
            query = query.Where(p => p.Llave == llave);

            return await query.Where(p => p.Llave.Contains(llave))
                .ToListAsync();

        }

        public async Task<AppUser> Read(string email)
        {
            var result = await _context.AppUsers.Where(AppUser => AppUser.EmailContacto == email)
                                                .FirstOrDefaultAsync();
            return result;
        }

    }
}
