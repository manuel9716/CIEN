﻿using Community.Models.ChatBot;
using System.Collections.Generic;
using System.Threading.Tasks;
using System;
using Community.Models;

namespace Community.Repositories.ChatBot
{
    public interface IChatBotRepository
    {

        Task<List<MensajeChatbot>> GetMensajesChatBot(string llave, string email);

        Task<AppUser> Read(string email);

    }
}
