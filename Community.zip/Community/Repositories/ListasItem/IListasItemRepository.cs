using System;
using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;
using Community.Dtos.ListasItem.Models;
using Community.Dtos.Pagination.Models;
using Community.Models;
using Community.Models.profiles;

namespace Community.Repositories.ListasItem
{
    public interface IListasItemRepository
    {
        Task<ListaItem> Create(ListaItem entity, CancellationToken cancellationToken);
        Task <ListaItem> Read(Guid id, CancellationToken cancellationToken);
        Task<ListaItem> Update(ListaItem entity, CancellationToken cancellationToken);
        Task Delete(Guid id, CancellationToken cancellationToken);
        Task<List<ListaItem>> Search(Paginator paginator, Sorter sorter, SearchListaItem searchRequest, CancellationToken cancellationToken);
        Task<int> TotalCount(SearchListaItem searchRequest, CancellationToken cancellationToken);
        Task<List<ListaItem>> GetItemsByCodigoPadre(string codigoPadre);
        Task<List<ListaItem>> GetItemsByPadreId(Guid padreId);
        Task<RespuestaEtiqueta> ReadEtiquetaByRespuesta(Guid id, CancellationToken cancellationToken);

    }
}
