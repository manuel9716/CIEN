using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using Community.DbContexts;
using Community.Dtos.ListasItem.Models;
using Community.Dtos.Pagination.Models;
using Community.Models;
using Community.Models.profiles;
using Microsoft.EntityFrameworkCore;

namespace Community.Repositories.ListasItem
{
    public class ListasItemRepository : IListasItemRepository
    {
        private readonly CommunityDbContext _context;

        public ListasItemRepository(CommunityDbContext context)
        {
            _context = context;
        }

        public async Task<ListaItem> Create(ListaItem entity, CancellationToken cancellationToken)
        {
            var result = await _context.AddAsync(entity);
            await _context.SaveChangesAsync();
            return result.Entity;
        }

        public async Task<ListaItem> Read(Guid id, CancellationToken cancellationToken)
        {
            return await _context.ListasItem.Where(listaitem => listaitem.Id == id).FirstOrDefaultAsync(cancellationToken);
        }

        public async Task<ListaItem> Update(ListaItem entity, CancellationToken cancellationToken)
        {
            _context.Entry(entity).State = EntityState.Modified;
            await _context.SaveChangesAsync(cancellationToken);
            return entity;
        }
        public async Task Delete(Guid id, CancellationToken cancellationToken)
        {
            var entity = await Read(id, cancellationToken);
            if (entity != null)
            {
                _context.ListasItem.Remove(entity);
                await _context.SaveChangesAsync(cancellationToken);
            }
        }

        public Task<List<ListaItem>> Search(Paginator paginator, Sorter sorter, SearchListaItem searchRequest, CancellationToken cancellationToken)
        {
            var query = this.GetQuery(searchRequest);
            query = this.SortQuery(query, sorter);

            return query.Skip((paginator.PageNumber - 1) * paginator.PageSize)
               .Take(paginator.PageSize).ToListAsync(cancellationToken);
        }

        public async Task<int> TotalCount(SearchListaItem searchRequest, CancellationToken cancellationToken)
        {
            return await this.GetQuery(searchRequest).CountAsync(cancellationToken);
        }


        private IQueryable<ListaItem> GetQuery(SearchListaItem searchRequest)
        {
            var query = from listaitem in _context.ListasItem select listaitem;

            query = query.Where(m => m.PadreId == searchRequest.PadreId);

            query = query.Where(m => m.FechaEliminacion == null);

            if (!string.IsNullOrEmpty(searchRequest.Nombre))
            {
                query = query.Where(m => m.Nombre.ToLower().Trim().Contains(searchRequest.Nombre.ToLower().Trim()));
            }

            if (!string.IsNullOrEmpty(searchRequest.Codigo))
            {
                query = query.Where(m => m.Codigo.ToLower().Trim().Contains(searchRequest.Codigo.ToLower().Trim()));
            }

            return query;
        }

        private IQueryable<ListaItem> SortQuery(IQueryable<ListaItem> query, Sorter sorter)
        {

            switch (sorter.SortBy)
            {

                case "codigo":
                    if (sorter.SortOrder.Trim().ToLower().Equals("asc"))
                    {
                        query = query.OrderBy(x => x.Codigo);
                    }
                    else
                    {
                        query = query.OrderByDescending(x => x.Codigo);
                    }
                    break;

                case "nombre":
                    if (sorter.SortOrder.Trim().ToLower().Equals("asc"))
                    {
                        query = query.OrderBy(x => x.Nombre);
                    }
                    else
                    {
                        query = query.OrderByDescending(x => x.Nombre);
                    }
                    break;

                case "fechaCreacion":
                    if (sorter.SortOrder.Trim().ToLower().Equals("asc"))
                    {
                        query = query.OrderBy(x => x.FechaCreacion);
                    }
                    else
                    {
                        query = query.OrderByDescending(x => x.FechaCreacion);
                    }
                    break;

                case "fechaActualizacion":
                    if (sorter.SortOrder.Trim().ToLower().Equals("asc"))
                    {
                        query = query.OrderBy(x => x.FechaActualizacion);
                    }
                    else
                    {
                        query = query.OrderByDescending(x => x.FechaActualizacion);
                    }
                    break;
            }
            return query;
        }

        public async Task<List<ListaItem>> GetItemsByCodigoPadre(string codigoPadre)
        {
              return await _context.ListasItem
                .Where(l => l.Padre.Codigo.Equals(codigoPadre) && l.FechaEliminacion == null)
                .OrderBy(l => l.Orden)
                //.OrderBy(l => l.Nombre)
                .ToListAsync();
        }
        

        public async Task<List<ListaItem>> GetItemsByPadreId(Guid padreId)
        {
            return await _context.ListasItem.Where(l => l.Padre.Id == padreId && l.FechaEliminacion == null).OrderBy(l => l.Orden).OrderBy(l => l.Nombre).ToListAsync();
        }

        public async Task<RespuestaEtiqueta> ReadEtiquetaByRespuesta(Guid id, CancellationToken cancellationToken)
        {
            return await _context.RespuestaEtiqueta.Where(x => x.RespuestaId == id).Include(x=>x.Etiqueta).FirstOrDefaultAsync(cancellationToken);
        }
    }
}
