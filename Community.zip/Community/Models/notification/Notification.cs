using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Community.Models.publication;
namespace Community.Models.notification
{
    [Table(name: "notificacion")]
    public class Notification
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        [Column(name: "id")]
        public Guid Id { get; set; }
        [Required]
        [Column(name: "fecha_creacion")]
        public DateTime FechaCreacion { get; set; }
        [Column(name: "user_id")]
        public Guid UserId { get; set; }
        public AppUser User { get; set; }
        [Column(name: "user_origen_id")]
        public Guid UserOrigenId { get; set; }
        public AppUser UserOrigen { get; set; }
        public string descripcion { get; set; }
        public string enlace { get; set; }

        [Column(name: "publicacion_id")]
        public System.Nullable<Guid> PublicacionId { get; set; }
        public Publication Publicacion { get; set; }

        [Column(name: "iteracion_id")]
        public System.Nullable<Guid> IteracionId { get; set; }
         public Iteracion Iteracion { get; set; }
        public bool activa { get; set; }


    }
}