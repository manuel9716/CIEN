using Community.Models.publication;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Community.Models.interests;
using Community.Models.Messages;
using Community.Models.notification;
using Community.Models.tool;
using Community.Models.experience;
using Community.Models.Learn;
using Community.Models.project;
using Community.Models.contactos;
using Community.Models.entidad;

namespace Community.Models
{
    [Table(name: "app_user")]
    public class AppUser
    {
        [Key]
        [Column(name: "id")]
        public Guid Id { get; set; }
        [Column(name: "nombres")]
        public String Nombres { get; set; }
        [Column(name: "apellidos")]
        public String Apellidos { get; set; }
        [Column(name: "pais_id")]
        public Guid PaisResidenciaId { get; set; }
        public ListaItem PaisResidencia { get; set; }
        [Column(name: "departamento_id")]
        public Guid DepartamentoResidenciaId { get; set; }
        public ListaItem DepartamentoResidencia { get; set; }
        [Column(name: "municipio_id")]
        public Guid MunicipioResidenciaId { get; set; }
        public ListaItem MunicipioResidencia { get; set; }
        [Column(name: "fecha_nacimiento")]
        public DateTime FechaNacimiento { get; set; }
        [Column(name: "genero_id")]
        public Guid GeneroId { get; set; }
        public ListaItem Genero { get; set; }

        [Column(name: "entidad_id")]
        public Guid? entidadid { get; set; }
        public entidad.entidad Entidad { get; set; }

        [Column(name: "notificar")]
        public Boolean Notificar { get; set; }
        [Column(name: "mostrar_correo")]
        public Boolean MostrarCorreo { get; set; }
        [Column(name: "mostrar_telefono")]
        public Boolean MostrarTelefono { get; set; }
        [Column(name: "mostrar_redes")]
        public Boolean MostrarRedes { get; set; }
        [Column(name: "fecha_eliminacion")]
        public System.Nullable<DateTime> FechaEliminacion { get; set; }
        [Column(name: "motivo_eliminacion_id")]
        public Guid? MotivoEliminacionId { get; set; }
        public ListaItem MotivoEliminacion { get; set; }
        
        [Column(name: "organizacion_id")]
        public Guid? OrganizacionId { get; set; }
        public ListaItem Organizacion { get; set; }

        [Column(name: "area_direccion_equipo_id")]
        public Guid? AreaDireccionEquipoId { get; set; }
        public ListaItem AreaDireccionEquipo { get; set; }

        [Column(name: "sector_id")]
        public Guid? SectorId { get; set; }
        public ListaItem Sector { get; set; }

        [Column(name: "orden_id")]
        public Guid? OrdenId { get; set; }
        public ListaItem Orden { get; set; }

        [Column(name: "profesion_id")]
        public Guid? ProfesionId { get; set; }
        public ListaItem Profesion { get; set; }

        [Column(name: "cargoactual_id")]
        public Guid? CargoActualId { get; set; }
        public ListaItem CargoActual { get; set; }

        [Column(name: "nivel_id")]
        public Guid? NivelId { get; set; }
        public ListaItem Nivel { get; set; }

        [Column(name: "proyecto_actual_id")]
        public Guid? ProyectoActualId { get; set; }
        public Project ProyectoActual { get; set; }

        [Column(name: "proyecto_destacado_id")]
        public Guid? ProyectoDestacadoId { get; set; }
        public Project ProyectoDestacado { get; set; }
        
        [Column(name: "celular")]
        public string CelularContacto { get; set; }

        [Column(name: "email")]
        public string EmailContacto { get; set; }

        [Column(name: "linkedin")]
        public string Linkedin { get; set; }

        [Column(name: "twitter")]
        public string Twitter { get; set; }

        [Column(name: "app_file_id")]
        public Guid? AppFileId { get; set; }
        public AppFile AppFile { get; set; }

        public Guid? PreguntaConectaId { get; set; }
        public ListaItem PreguntaConecta { get; set; }
        public ICollection<Publication> AppUserpublicacion { get; set; }

        public ICollection<Comment> AppUsercomentario { get; set; }
          
        public ICollection<Iteracion> AppUseriteracion { get; set; }
        public ICollection<Publication_hide> AppUserpublicacionocultar { get; set; }
        public ICollection<Publication_report> AppUserpublicacionreportar { get; set; }
        public ICollection<Interest> AppUserIntereses { get; set; }    
        public ICollection<Message> AppUserMensaje { get; set; }
        public ICollection<Conversation> AppUserSender { get; set; }
        public ICollection<Conversation> AppUserReceptor { get; set; }  
        public ICollection<UsuariosConectados> AppUserConectados { get; set; }
        public ICollection<ConversacionesConectados> AppUserSalasConectados { get; set; }     
        public ICollection<Notification> AppUsernoticacionorigen { get; set; }      
        public ICollection<Notification> AppUsernoticaciondestino { get; set; }          
        public ICollection<Tool> AppUserTool { get; set; }
        public ICollection<Experience> AppUserExperience { get; set; }
        public ICollection<Oferta> AppUseroferta { get; set; }
        public ICollection<PerfilEtiqueta> AppUserEtiquetas { get; set; } 
        public ICollection<Contacto> AppUserContactoUser { get; set; } 
        public ICollection<Contacto> AppUserContacto { get; set; } 

    }
}

