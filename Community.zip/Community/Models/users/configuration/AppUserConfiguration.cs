using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using Community.Models;

namespace Community.Models.users.configuration
{
    /// <summary>
    /// Configuración del ORM para la entidad Usuario
    /// </summary>
    public class AppUserConfiguration : IEntityTypeConfiguration<AppUser>
    {
        /// <summary>
        /// Configuración del ORM
        /// </summary>
        /// <param name="configuration">Configurador</param>
        public void Configure(EntityTypeBuilder<AppUser> modelBuilder)
        {
            modelBuilder.HasOne(p => p.PaisResidencia)
            .WithMany(l => l.AppUsersPaisResidencia)
            .HasForeignKey(p => p.PaisResidenciaId)
            .HasPrincipalKey(l => l.Id)
            .OnDelete(DeleteBehavior.NoAction)
            .HasConstraintName("LISTA_APPUSER_PAISRESIDENCIA_FK");

            modelBuilder.HasOne(p => p.DepartamentoResidencia)
            .WithMany(l => l.AppUsersDepartamentoResidencia)
            .HasForeignKey(p => p.DepartamentoResidenciaId)
            .HasPrincipalKey(l => l.Id)
            .OnDelete(DeleteBehavior.NoAction)
            .HasConstraintName("LISTA_APPUSER_DEPARTAMENTORESIDENCIA_FK");

            modelBuilder.HasOne(p => p.MunicipioResidencia)
            .WithMany(l => l.AppUsersMunicipioResidencia)
            .HasForeignKey(p => p.MunicipioResidenciaId)
            .HasPrincipalKey(l => l.Id)
            .OnDelete(DeleteBehavior.NoAction)
            .HasConstraintName("LISTA_APPUSER_MUNICIPIORESIDENCIA_FK");

            modelBuilder.HasOne(p => p.Genero)
            .WithMany(l => l.AppUsersGenero)
            .HasForeignKey(p => p.GeneroId)
            .HasPrincipalKey(l => l.Id)
            .OnDelete(DeleteBehavior.NoAction)
            .HasConstraintName("LISTA_APPUSER_GENERO_FK");

            modelBuilder.HasOne(p => p.MotivoEliminacion)
            .WithMany(l => l.AppUsersMotivoEliminacion)
            .HasForeignKey(p => p.MotivoEliminacionId)
            .HasPrincipalKey(l => l.Id)
            .OnDelete(DeleteBehavior.NoAction)
            .HasConstraintName("LISTA_APPUSER_MOTIVO_ELIMINACION_FK");

             modelBuilder.Property(c => c.Notificar)
            .HasDefaultValueSql("0"); 

            modelBuilder.Property(c => c.MostrarCorreo)
            .HasDefaultValueSql("0");    

            modelBuilder.Property(c => c.MostrarTelefono)
            .HasDefaultValueSql("0");   

            modelBuilder.Property(c => c.MostrarRedes)
            .HasDefaultValueSql("0");     

/*
            //perfiles
            modelBuilder.HasOne(p => p.Organizacion)
            .WithMany(l => l.AppUserOrganizacion)
            .HasForeignKey(p => p.OrganizacionId)
            .HasPrincipalKey(l => l.Id)
            .OnDelete(DeleteBehavior.NoAction)
            .HasConstraintName("LISTA_APPUSER_ORGANIZACION_FK");

            modelBuilder.HasOne(p => p.AreaDireccionEquipo)
            .WithMany(l => l.AppUserAreaDireccionEquipo)
            .HasForeignKey(p => p.AreaDireccionEquipoId)
            .HasPrincipalKey(l => l.Id)
            .OnDelete(DeleteBehavior.NoAction)
            .HasConstraintName("LISTA_APPUSER_AreaDireccionEquipo_FK");

            modelBuilder.HasOne(p => p.Sector)
            .WithMany(l => l.AppUserSector)
            .HasForeignKey(p => p.SectorId)
            .HasPrincipalKey(l => l.Id)
            .OnDelete(DeleteBehavior.NoAction)
            .HasConstraintName("LISTA_APPUSER_Sector_FK");

            modelBuilder.HasOne(p => p.Orden)
            .WithMany(l => l.AppUserOrden)
            .HasForeignKey(p => p.OrdenId)
            .HasPrincipalKey(l => l.Id)
            .OnDelete(DeleteBehavior.NoAction)
            .HasConstraintName("LISTA_APPUSER_Orden_FK");

            modelBuilder.HasOne(p => p.Profesion)
            .WithMany(l => l.AppUserProfesion)
            .HasForeignKey(p => p.ProfesionId)
            .HasPrincipalKey(l => l.Id)
            .OnDelete(DeleteBehavior.NoAction)
            .HasConstraintName("LISTA_APPUSER_Profesion_FK");

            modelBuilder.HasOne(p => p.CargoActual)
            .WithMany(l => l.AppUserCargoActual)
            .HasForeignKey(p => p.CargoActualId)
            .HasPrincipalKey(l => l.Id)
            .OnDelete(DeleteBehavior.NoAction)
            .HasConstraintName("LISTA_APPUSER_CargoActual_FK");

            modelBuilder.HasOne(p => p.Nivel)
            .WithMany(l => l.AppUserNivel)
            .HasForeignKey(p => p.NivelId)
            .HasPrincipalKey(l => l.Id)
            .OnDelete(DeleteBehavior.NoAction)
            .HasConstraintName("LISTA_APPUSER_Nivel_FK");

            modelBuilder.HasOne(p => p.ProyectoActual)
            .WithMany(l => l.AppUserProyectoActual)
            .HasForeignKey(p => p.ProyectoActualId)
            .HasPrincipalKey(l => l.Id)
            .OnDelete(DeleteBehavior.NoAction)
            .HasConstraintName("LISTA_APPUSER_ProyectoActual_FK");

            modelBuilder.HasOne(p => p.ProyectoDestacado)
            .WithMany(l => l.AppUserProyectoDestacado)
            .HasForeignKey(p => p.ProyectoDestacadoId)
            .HasPrincipalKey(l => l.Id)
            .OnDelete(DeleteBehavior.NoAction)
            .HasConstraintName("LISTA_APPUSER_ProyectoDestacado_FK");*/


        }
    }
}
