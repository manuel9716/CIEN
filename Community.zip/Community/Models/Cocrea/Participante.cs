﻿using Microsoft.EntityFrameworkCore.Metadata.Internal;
using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;
using System;

namespace Community.Models.Cocrea
{
    [Table(name: "Participantes")]
    public class Participante
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        [Column(name: "Id")]
        public Guid Id { get; set; }

        [Required]
        [MaxLength(255)]
        [Column(TypeName = "VARCHAR")]
        public string Nombre { get; set; }

        [Required]
        [MaxLength(255)]
        [Column(TypeName = "BIT")]
        public bool Estado { get; set; }
    }
}
