﻿using System.ComponentModel.DataAnnotations;
using System;
using System.ComponentModel.DataAnnotations.Schema;

namespace Community.Models.Cocrea
{
    [Table(name: "RespuestaComentarios")]
    public class RespuestaComentario
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        [Column(name: "Id")]
        public Guid Id { get; set; }


        [Required]
        [MaxLength(500)]
        [Column(TypeName = "VARCHAR")]
        public string ComentarioTexto { get; set; }

        [Required]
        [Column(TypeName = "BIT")]
        public bool Estado { get; set; }

        [Required]
        public DateTime FechaCreacion { get; set; }

        public DateTime FechaModificacion { get; set; }

        [Required]
        public Guid Autor { get; set; }

        public Guid ModificadoPor { get; set; }

        [Required]
        public Guid RespuestaId { get; set; }

        [Required]
        [ForeignKey("RespuestaId")]
        public virtual Respuesta Respuesta { get; set; }
    }
}
