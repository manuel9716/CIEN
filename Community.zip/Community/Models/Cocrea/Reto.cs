﻿using System.ComponentModel.DataAnnotations;
using System;
using System.ComponentModel.DataAnnotations.Schema;

namespace Community.Models.Cocrea
{
    [Table(name: "Retos")]
    public class Reto
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        [Column(name: "Id")]
        public Guid Id { get; set; }

        [Required]
        [MaxLength(255)]
        [Column(TypeName = "VARCHAR")]
        public string Titulo { get; set; }

        [Required]
        [MaxLength(500)]
        public string Descripcion { get; set; }

        public DateTime FechaCreacion { get; set; }

        public DateTime FechaCierre { get; set; }

        [Required]
        public int Vistas { get; set; }

        [Required]
        [MaxLength(500)]
        public string Requisitos { get; set; }

        [Required]
        [MaxLength(100)]
        [Column(TypeName = "VARCHAR")]
        public string Estado { get; set; }

        [Required]
        public Guid Autor { get; set; }

        [Required]
        [Column(TypeName = "BIT")]
        public bool FlagEstado { get; set; }
    }
}
