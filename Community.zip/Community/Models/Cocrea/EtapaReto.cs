﻿using Microsoft.EntityFrameworkCore.Metadata.Internal;
using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;
using System;

namespace Community.Models.Cocrea
{
    [Table(name: "EtapaRetos")]
    public class EtapaReto
    {

        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        [Column(name: "Id")]

        public Guid Id { get; set; }

        [Required]
        public Guid RetoId { get; set; }

        [Required]
        [ForeignKey("RetoId")]
        public virtual Reto Reto { get; set; }

        [Required]
        [Column(TypeName = "varchar(MAX)")]
        public string Nombre { get; set; }

        [Required]
        public DateTime FechaInicial { get; set; }

        public DateTime FechaFinal { get; set; }

        [Required]
        [MaxLength(255)]
        [Column(TypeName = "BIT")]

        public bool Estado { get; set; }
    }
}
