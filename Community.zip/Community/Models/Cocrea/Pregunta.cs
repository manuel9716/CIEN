﻿using System.ComponentModel.DataAnnotations;
using System;
using System.ComponentModel.DataAnnotations.Schema;

namespace Community.Models.Cocrea
{
    [Table(name: "Preguntas")]
    public class Pregunta
    {

        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        [Column(name: "Id")]
        public Guid Id { get; set; }

        [Required]
        public Guid EntidadId { get; set; }

        [Required]
        [MaxLength(255)]
        [Column(TypeName = "VARCHAR")]
        public string EntidadNombre { get; set; }

        [Required]
        public Guid GrupoId { get; set; }

        [Required]
        [MaxLength(255)]
        [Column(TypeName = "VARCHAR")]
        public string GrupoNombre { get; set; }

        [Required]
        [MaxLength(500)]
        [Column(TypeName = "VARCHAR")]
        public string PreguntaTexto { get; set; }

        [Required]
        [MaxLength(500)]
        [Column(TypeName = "VARCHAR")]
        public string Justificacion { get; set; }

        [Required]
        [MaxLength(100)]
        [Column(TypeName = "BIT")]
        public bool Estado { get; set; }

        [Required]
        public DateTime FechaCreacion { get; set; }

        public DateTime FechaModificacion { get; set; }

        [Required]
        public Guid Autor { get; set; }

        public Guid ModificadoPor { get; set; }

        [Required]
        public int Contador { get; set; }

    }
}
