﻿using Microsoft.EntityFrameworkCore.Metadata.Internal;
using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;
using System;

namespace Community.Models.Cocrea
{
    [Table(name: "ParticipanteRetos")]
    public class ParticipanteReto
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        [Column(name: "Id")]
        public Guid Id { get; set; }

        [Required]
        public Guid RetoId { get; set; }

        [Required]
        [ForeignKey("RetoId")]
        public virtual Reto Reto { get; set; }

        [Required]
        public Guid ParticipanteId { get; set; }

        [Required]
        [ForeignKey("ParticipanteId")]
        public virtual Participante Participante { get; set; }

        [Required]
        [MaxLength(255)]
        [Column(TypeName = "BIT")]
        public bool Estado { get; set; }
    }
}
