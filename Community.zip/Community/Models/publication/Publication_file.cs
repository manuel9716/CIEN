using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Community.Models.publication
{
    [Table(name: "publicacion_file")]
    public class Publication_file
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        [Column(name: "id")]
        public Guid Id { get; set; }
        [Required]
        [Column(name: "fecha_creacion")]
        public DateTime FechaCreacion { get; set; }
        [Column(name: "publicacion_id")]
        public Guid PublicacionId { get; set; }
        public Publication Publicacion { get; set; }
        [Column(name: "appfile_id")]
        public Guid AppFileId { get; set; }
        public AppFile AppFile { get; set; }

    }
}