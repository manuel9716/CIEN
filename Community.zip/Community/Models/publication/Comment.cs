using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;

namespace Community.Models.publication
{
    [Table(name: "publicacion_comentario")]
    public class Comment
    {
        
            [Key]
            [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
            [Column(name: "id")]
            public Guid Id { get; set; }
            [Required]
            [Column(name: "descripcion", TypeName = "Varchar (500)")]
            public String Descripcion { get; set; }

            [Column(name: "padre_id")]
            public System.Nullable<Guid> PadreId { get; set; }
            public Comment Padre { get; set; }
            [Required]
            [Column(name: "fecha_creacion")]
            public DateTime FechaCreacion { get; set; }
            [Required]
            [Column(name: "fecha_actualizacion")]
            public DateTime FechaActualizacion { get; set; }
            [Column(name: "user_id")]
            public System.Nullable<Guid> AppUserId { get; set; }
            public AppUser Usuario { get; set; }

            [Column(name: "publicacion_id")]
            public Guid PublicacionId { get; set; }
            public ICollection<Comment> Comentario { get; set; }
            public Publication Publicacion { get; set; }
            public ICollection<Iteracion> Comentarioiteracion { get; set; }

    }
}