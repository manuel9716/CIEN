using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Community.Models.publication
{
    [Table(name: "publicacion_ocultar")]
    public class Publication_hide
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        [Column(name: "id")]
        public Guid Id { get; set; }
        [Required]
        [Column(name: "fecha_creacion")]
        public DateTime FechaCreacion { get; set; }
        [Column(name: "user_id")]
        public AppUser Usuario { get; set; }
        public System.Nullable<Guid> AppUserId { get; set; }
        [Column(name: "publicacion_id")]
        public Guid PublicacionId { get; set; }
        public Publication Publicacion { get; set; }
        [Column(name: "listaitem_id")]
        public System.Nullable<Guid> ListaItemId { get; set; }
        public ListaItem ListaItem { get; set; }
        public string Otro { get; set; }

    }
}