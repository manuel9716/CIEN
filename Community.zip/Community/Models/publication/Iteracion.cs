using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Community.Models.notification;

namespace Community.Models.publication
{
    [Table(name: "iteracion")]
    public class Iteracion
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        [Column(name: "id")]
        public Guid Id { get; set; }
        [Required]
        [Column(name: "fecha_creacion")]
        public DateTime FechaCreacion { get; set; }
        [Column(name: "user_id")]
        public AppUser Usuario { get; set; }
        public System.Nullable<Guid> AppUserId { get; set; }
        [Column(name: "publicacion_id")]
        public System.Nullable<Guid> PublicacionId { get; set; }
        public Publication Publicacion { get; set; }
        [Column(name: "comentario_id")]
        public System.Nullable<Guid> ComentarioId { get; set; }
        public Comment Comentario { get; set; }
        [Column(name: "listaitem_id")]
        public System.Nullable<Guid> ListaItemId { get; set; }
        public ListaItem ListaItem { get; set; }
        public ICollection<Notification> Iteracionnotificacion { get; set; }


    }
}
