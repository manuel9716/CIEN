using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;
using Community.Models.notification;

namespace Community.Models.publication
{

    [Table(name: "publicacion")]
    public class Publication
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        [Column(name: "id")]
        public Guid Id { get; set; }
        [Required]
        [Column(name: "descripcion", TypeName = "Varchar (500)")]
         public string Descripcion { get; set; }
        [Required]
        [Column(name: "fecha_creacion")]
        public DateTime FechaCreacion { get; set; }
        [Required]
        [Column(name: "fecha_actualizacion")]
        public DateTime FechaActualizacion { get; set; }
        [Column(name: "user_id")]
        public System.Nullable<Guid> AppUserId { get; set; }
        public AppUser Usuario { get; set; }
        [Column(name: "fecha_eliminacion")]
        public System.Nullable<DateTime> FechaEliminacion { get; set; }   
        public string UrlGif { get; set; }    
        [Column(name: "compartir_id")]
        public System.Nullable<Guid> CompartirId { get; set; }
        public Publication Compartir { get; set; }
        public ICollection<Comment> Publicacioncomentario { get; set; }
        public ICollection<Iteracion> Publicacioniteracion { get; set; }
        public ICollection<Publication_hide> Publicacionocultar { get; set; }

        public ICollection<Publication_report> Publicacionreportar { get; set; }
        public ICollection<Publication_file> Publicacionfile { get; set; }
        public ICollection<Notification> Publicacionnotificacion { get; set; }
        public ICollection<Publication> Publicacion { get; set; }
    }
}