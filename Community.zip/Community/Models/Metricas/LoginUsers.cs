﻿using System.ComponentModel.DataAnnotations;
using System;
using System.ComponentModel.DataAnnotations.Schema;

namespace Community.Models.Metricas
{

    [Table(name: "LoginUsers")]
    public class LoginUsers
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        [Column(name: "Id")]
        public Guid Id { get; set; }

        [Required]
        public Guid Iduser { get; set; }

        [Required]
        [MaxLength(500)]
        [Column(TypeName = "VARCHAR")]
        public string  Nombre { get; set; }

        [Required]
        [MaxLength(500)]
        [Column(TypeName = "VARCHAR")]
        public string Usuario { get; set; }

        [Required]
        [MaxLength(500)]
        [Column(TypeName = "VARCHAR")]
        public string Correo { get; set; }

        [Required]
        public DateTime FechaCreacion { get; set; }

    }
}
