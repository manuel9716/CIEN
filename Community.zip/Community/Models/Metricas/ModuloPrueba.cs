﻿using System.ComponentModel.DataAnnotations;
using System;
using System.ComponentModel.DataAnnotations.Schema;

namespace Community.Models.Metricas
{
    [Table(name: "ModuloPruebas")]
    public class ModuloPrueba
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        [Column(name: "Id")]
        public Guid Id { get; set; }

        [Required]
        [MaxLength(255)]
        [Column(TypeName = "VARCHAR")]
        public string TipoPagina { get; set; }

        [Required]
        public DateTime FechaCreacion { get; set; }

    }
}
