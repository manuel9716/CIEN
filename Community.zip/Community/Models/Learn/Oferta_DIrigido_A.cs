using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Community.Models.Learn
{
    [Table(name: "oferta_dirigido_a")]
    public class Oferta_DIrigido_A
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        [Column(name: "id")]
        public Guid Id { get; set; }
        [Required]
        [Column(name: "dirigido_a_id")]
        public Guid DirigidoAId { get; set; }
        [Required]
        public ListaItem ListaItemDirigidoA { get; set; }
        [Required]
        [Column(name: "fecha_creacion")]
        public DateTime FechaCreacion { get; set; }
        [Column(name: "oferta_id")]
        public Guid OfertaId { get; set; }
        public Oferta Oferta { get; set; }

    }
}
