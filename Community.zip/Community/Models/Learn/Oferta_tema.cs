using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Community.Models.Learn
{
    [Table(name: "oferta_tema")]
    public class Oferta_tema
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        [Column(name: "id")]
        public Guid Id { get; set; }
        [Required]
        [Column(name: "tema_id")]
        public Guid TemaId { get; set; }
        [Required]
        public ListaItem ListaItemTema { get; set; }
        [Required]
        [Column(name: "fecha_creacion")]
        public DateTime FechaCreacion { get; set; }
        [Column(name: "oferta_id")]
        public Guid OfertaId { get; set; }
        public Oferta Oferta { get; set; }
    }
}
