using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Community.Models.Learn
{
    [Table(name: "oferta_modulo")]
    public class Oferta_modulo
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        [Column(name: "id")]
        public Guid Id { get; set; }
        [Required]
        [Column(name: "Descripcion", TypeName = "Varchar (400)")]
        public string Descripcion { get; set; }
        [Required]
        [Column(name: "fecha_creacion")]
        public DateTime FechaCreacion { get; set; }
        [Column(name: "oferta_id")]
        public Guid OfertaId { get; set; }
        public Oferta Oferta { get; set; }
    }
}
