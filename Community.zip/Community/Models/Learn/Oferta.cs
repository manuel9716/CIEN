using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Community.Models.Learn
{
    [Table(name: "oferta")]
    public class Oferta
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        [Column(name: "id")]
        public Guid Id { get; set; }
        [Required]
        [Column(name: "titulo", TypeName = "Varchar (50)")]
        public string Titulo { get; set; }
        [Required]
        [Column(name: "tipo_id")]
        public Guid TipoId { get; set; }
        [Column(name: "tipo_otro", TypeName = "Varchar (100)")]
        public string TipoOtro { get; set; }
        [Column(name: "tema_otro", TypeName = "Varchar (100)")]
        public string TemaOtro { get; set; }
        [Required]
        [Column(name: "modalidad_id")]
        public Guid ModalidadId { get; set; }
        [Required]
        public ListaItem ListaItemTipo { get; set; }
        [Column(name: "tiempo_id")]
        public Guid TiempoId { get; set; }
        public ListaItem ListaItemTiempo { get; set; }
        [Required]
        [Column(name: "contenido", TypeName = "Varchar (500)")]
        public string Contenido { get; set; }
        [Required]
        [Column(name: "existe_requisito_previo")]
        public bool ExisteRequisitoPrevio { get; set; }
        [Column(name: "requisito_previo_cuales", TypeName = "Varchar (500)")]
        public string RequisitoPrevioCuales { get; set; }
        [Column(name: "url", TypeName = "Varchar (500)")]
        public string Url { get; set; }
        [Column(name: "etiquetas", TypeName = "Varchar (1000)")]
        public string Etiquetas { get; set; }
        [Column(name: "nombre_contacto", TypeName = "Varchar (200)")]
        public string NombreContacto { get; set; }
        [Column(name: "dependencia_contacto", TypeName = "Varchar (100)")]
        public string DependenciaContacto { get; set; }
        [Column(name: "correo_contacto", TypeName = "Varchar (100)")]
        public string CorreoContacto { get; set; }
        [Column(name: "Indicativo_celular_contacto", TypeName = "Varchar (10)")]
        public string IndicativoCelularContacto { get; set; }
        [Column(name: "Numero_celular_contacto", TypeName = "Varchar (10)")]
        public string NumeroCelularContacto { get; set; }
        [Column(name: "esta_interesado_conocer_ofertas")]
        public bool EstaInteresadoConocerOfertas { get; set; }
        public Guid AppFilePortadaId { get; set; }
        public AppFile AppFilePortada { get; set; }
        [Column(name: "urlVideo", TypeName = "Varchar (500)")]
        public string UrlVideo { get; set; }
        [Column(name: "ocultar")]
        public bool Ocultar { get; set; } = true;
        [Required]
        [Column(name: "fecha_creacion")]
        public DateTime FechaCreacion { get; set; }
        [Required]
        [Column(name: "fecha_actualizacion")]
        public DateTime FechaActualizacion { get; set; }
        [Column(name: "user_id")]
        public System.Nullable<Guid> AppUserId { get; set; }
        public AppUser Usuario { get; set; }
        public ICollection<Oferta_file> Ofertafile { get; set; }
        public ICollection<Oferta_DIrigido_A> OfertaDirigidoA { get; set; }
        public ICollection<Oferta_tema> OfertaTema { get; set; }
        public ICollection<Oferta_modulo> OfertaModulo { get; set; }
    }
}
