using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;

namespace Community.Models.interests
{
    [Table(name: "perfil_etiqueta")]
    public class PerfilEtiqueta
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        [Column(name: "id")]
        public Guid Id { get; set; }

        [Column(name: "user_id")]
        public System.Nullable<Guid> AppUserId { get; set; }
        public AppUser AppUser { get; set; }

        [Column(name: "listaitem_id")]
        public System.Nullable<Guid> ListaItemId { get; set; }
        public ListaItem ListaItem { get; set; }
    }
}
