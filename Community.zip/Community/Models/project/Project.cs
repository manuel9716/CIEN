using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Community.Models.project
{
    [Table(name: "proyecto")]
    public class Project
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        [Column(name: "id")]
        public Guid Id { get; set; }
        
        [Column(name: "nombre")]
        public String Nombre { get; set; }

        [Column(name: "descripcion")]
        public String Descripcion { get; set; }

        [Column(name: "finalizacion")]
        public int Finalizacion { get; set; }

        [Column(name: "etiquetas")]
        public String Etiquetas { get; set; }

        //Listas
        public ICollection<AppUser> AppUserProyectoActual { get; set; }
        public ICollection<AppUser> AppUserProyectoDestacado { get; set; }

    }
}