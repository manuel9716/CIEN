using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using Community.Models;

namespace Community.Models.project.configuration
{
    /// <summary>
    /// Configuración del ORM para la entidad Project
    /// </summary>
    public class ProjectConfiguration : IEntityTypeConfiguration<Project>
    {
        /// <summary>
        /// Configuración del ORM
        /// </summary>
        /// <param name="configuration">Configurador</param>
        public void Configure(EntityTypeBuilder<Project> modelBuilder)
        {
            modelBuilder.Property(p => p.Etiquetas)
           .HasColumnType("nvarchar(max)");
        }
    }
}
