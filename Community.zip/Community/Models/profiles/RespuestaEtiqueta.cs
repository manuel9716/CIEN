using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;

namespace Community.Models.profiles
{
    [Table(name: "respuesta_etiqueta")]
    public class RespuestaEtiqueta
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        [Column(name: "id")]
        public Guid Id { get; set; }

        [Column(name: "respuesta_id")]
        public System.Nullable<Guid> RespuestaId { get; set; }
        public ListaItem Respuesta { get; set; }

         [Column(name: "etiqueta_id")]
        public System.Nullable<Guid> EtiquetaId { get; set; }
        public ListaItem Etiqueta { get; set; }
    }
}
