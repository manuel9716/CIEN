﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text.Json.Serialization;
using System.Threading.Tasks;

namespace Community.Models.tool
{
    [Table(name: "Herramienta_Fases")]
    public class ToolFase
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        [Column(name: "id")]
        public Guid Id { get; set; }
        [Required]
        [Column(name: "tool_id")]
        public Guid toolId { get; set; }
        [JsonIgnore]
        public Tool tool { get; set; }
        [Column(name: "fases_id")]
        public Guid FasesID { get; set; }
        public ListaItem Fases { get; set; }
    }
}
