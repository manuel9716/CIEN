﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text.Json.Serialization;
using System.Threading.Tasks;

namespace Community.Models.tool
{
    [Table(name: "Herramienta_Tareas")]
    public class ToolTask
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        [Column(name: "id")]
        public Guid Id { get; set; }
        [Column(name: "tool_id")]
        public Guid toolId { get; set; }
        [JsonIgnore]
        public Tool tool { get; set; }
        [Column(name: "tareas_id")]
        public Guid TareasID { get; set; }
        public ListaItem Tareas { get; set; }
    }
}
