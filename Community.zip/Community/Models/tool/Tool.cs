﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;

namespace Community.Models.tool
{
    [Table(name: "Herramienta")]
    public class Tool
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        [Column(name: "id")]
        public Guid Id { get; set; }

        [Column(name: "user_id")]
        public Guid AppUserId { get; set; }
        public AppUser Usuario { get; set; }

        public DateTime FechaCreacion { get; set; }

        [Column(name: "tipo_recurso_id")]
        public System.Nullable<Guid> TipoRecursoID { get; set; }
        public ListaItem TipoRecurso { get; set; }
        [Column(name: "descripcion")]
        public String DescripcionInnovador { get; set; }
        [Required]
        [Column(name: "informacion_herramienta")]
        public String NombreHerramienta { get; set; }
        [Required]
        [Column(name: "opcion_recuerso")]
        public Boolean Recurso { get; set; }
        [Column(name: "descripcion_recurso")]
        public String DescripcionRecurso { get; set; }
        [Column(name: "Que_es")]
        public String Que_Es { get; set; }
        [Column(name: "para_que_sirve")]
        public String Para_Que_Sirve { get; set; }
        [Column(name: "valor_como_se_usa")]
        public Boolean valor_como_se_usa { get; set; }
        [Column(name: "como_se_usa")]
        public String Como_Se_usa { get; set; }
        [Column(name: "tipo_herramienta")]
        public System.Nullable<Guid> TipoHerramientaID { get; set; }
        public ListaItem TipoHerramienta { get; set; }
        [Column(name:"etiquetas")]
        public String Etiqueta { get; set; }
        public ICollection<ToolFase> ToolFases { get; set; }
        public ICollection<ToolTask> ToolTareas { get; set; }        
        public ICollection<ToolTeam> ToolEquipos { get; set; }
    }
}