﻿using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Community.Models.tool
{
    [Table(name: "Herramienta_Archivo")]
    public class Tool_file
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        [Column(name: "id")]
        public Guid Id { get; set; }
        [Required]
        [Column(name: "fecha_creacion")]
        public DateTime FechaCreacion { get; set; }
        [Column(name: "herramienta_id")]
        public Guid HerramientaId { get; set; }
        public Tool Herramienta { get; set; }
        [Column(name: "appfile_id")]
        public Guid AppFileId { get; set; }
        public AppFile AppFile { get; set; }
    }
}
