﻿using Microsoft.EntityFrameworkCore.Metadata.Internal;
using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;
using System;

namespace Community.Models.ChatBot
{
    [Table(name: "ChatBot")]
    public class MensajeChatbot
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        [Column(name: "IDChatBot")]
        public int IDChatBot { get; set; }

        [Required]
        [Column(name: "HtmlTexto")]
        public string HtmlTexto { get; set; }

        [Required]
        [Column(name: "Tipo")]
        public string Tipo { get; set; }

        [Required]
        [Column(name: "Llave")]
        public string Llave { get; set; }

        [Required]
        [Column(name: "Ubicacion")]
        public int Ubicacion { get; set; }

        [Column(name: "Anterior")]
        public string Anterior { get; set; }

        [Column(name: "Ejecucion")]
        public string Ejecucion { get; set; }

        [Column(name: "Siguiente")]
        public string Siguiente { get; set; }

        [Required]
        [Column(name: "FechaCreacion")]
        public DateTime FechaCreacion { get; set; }

        [Column(name: "UsuarioCreacion")]
        public string UsuarioCreacion { get; set; }

        [Column(name: "Estado")]
        public int Estado { get; set; }


    }
}
