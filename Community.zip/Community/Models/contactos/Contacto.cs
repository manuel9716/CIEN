using Community.Models.publication;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Community.Models.interests;
using Community.Models.Messages;
using Community.Models.notification;
using Community.Models.tool;
using Community.Models.experience;
using Community.Models.Learn;
using Community.Models.project;

namespace Community.Models.contactos
{
    [Table(name: "contacto")]
    public class Contacto
    {
        [Key]
        [Column(name: "id")]
        public Guid Id { get; set; }
        

        [Column(name: "user_id")]
        public Guid UserId { get; set; }
        public AppUser AppUser { get; set; }

        [Column(name: "contacto_id")]
        public Guid ContactId { get; set; }
        public AppUser Contact { get; set; }
        
        [Column(name: "respuesta_contacto_id")]
        public Guid? RespuestaContactoId { get; set; }
        public ListaItem RespuestaContacto { get; set; }

        [Required]
        [Column(name: "fecha_creacion")]
        public DateTime FechaCreacion { get; set; }     

    }
}

