using Community.Models.interests;
using Community.Models.publication;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Community.Models.tool;
using Community.Models.Learn;
using Community.Models.profiles;
using Community.Models.contactos;

namespace Community.Models
{
    [Table(name: "listas_community")]
    public class ListaItem
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        [Column(name: "id")]
        public Guid Id { get; set; }

        [Required]
        [Column(name: "codigo", TypeName = "Varchar (255)")]
        public String Codigo { get; set; }

        [Required]
        [Column(name: "nombre", TypeName = "Varchar (255)")]
        public String Nombre { get; set; }

        [Required]
        [Column(name: "orden")]
        public int Orden { get; set; }

        [Column(name: "padre_id")]
        public System.Nullable<Guid> PadreId { get; set; }
        public ListaItem Padre { get; set; }

        [Required]
        [Column(name: "fecha_creacion")]
        public DateTime FechaCreacion { get; set; }

        [Required]
        [Column(name: "fecha_actualizacion")]
        public DateTime FechaActualizacion { get; set; }

        [Column(name: "fecha_eliminacion")]
        public System.Nullable<DateTime> FechaEliminacion { get; set; }

        //Listas
        public ICollection<ListaItem> Items { get; set; }
        public ICollection<AppUser> AppUsersPaisResidencia { get; set; }
        public ICollection<AppUser> AppUsersDepartamentoResidencia { get; set; }
        public ICollection<AppUser> AppUsersMunicipioResidencia { get; set; }
        public ICollection<AppUser> AppUsersGenero { get; set; }

        //public ICollection<AppUser> AppUsersEntidad { get; set; }
        public ICollection<AppUser> AppUsersMotivoEliminacion { get; set; }
        public ICollection<Iteracion> IteracionLIstaItem { get; set; }
        public ICollection<Publication_hide> publicacionocultarLIstaItem { get; set; }
        public ICollection<Publication_report> publicacionreportarLIstaItem { get; set; }
        public ICollection<Interest> interestsListaItem { get; set; }
        public ICollection<AppUser> AppUserOrganizacion { get; set; }
        public ICollection<AppUser> AppUserAreaDireccionEquipo { get; set; }
        public ICollection<AppUser> AppUserSector { get; set; }
        public ICollection<AppUser> AppUserOrden { get; set; }
        public ICollection<AppUser> AppUserProfesion { get; set; }
        public ICollection<AppUser> AppUserCargoActual { get; set; }
        public ICollection<AppUser> AppUserNivel { get; set; }

        //public ICollection<Tool> TipoRecursoID { get; set; }
        //public ICollection<Tool> PasoID { get; set; }
        //public ICollection<Tool> DiagnosticoID { get; set; }
        //public ICollection<Tool> FormularioID { get; set; }
        //public ICollection<Tool> ImplementacionID { get; set; }
        //public ICollection<Tool> EvaluacionID { get; set; }
        //public ICollection<Tool> DifusionID { get; set; }
        //public ICollection<Tool> EntenderID { get; set; }
        //public ICollection<Tool> DefinirID { get; set; }
        //public ICollection<Tool> IdeasID { get; set; }
        //public ICollection<Tool> ColaborarID { get; set; }
        //public ICollection<Tool> AnalizarID { get; set; }
        //public ICollection<Tool> ProbarID { get; set; }
        //public ICollection<Tool> ComunicarID { get; set; }
        //public ICollection<Tool> GestionarCID { get; set; }
        //public ICollection<Tool> GestionEquipoID { get; set; }
        //public ICollection<Tool> GestionCambioID { get; set; }
        //public ICollection<Tool> TipoHerramientaID { get; set; }

        public ICollection<Oferta> OfertaLIstaItemTipo { get; set; }
        public ICollection<Oferta> OfertaLIstaItemTiempo { get; set; }
        public ICollection<Oferta_tema> OfertaLIstaItemTema { get; set; }
        public ICollection<Oferta_DIrigido_A> OfertaLIstaItemDirigidoA { get; set; }
        public ICollection<Tool> ListaTipoRecurso { get; set; }
        public ICollection<Tool> ListaTipoHerramienta { get; set; }        
        public ICollection<ToolFase> ListaItemFase { get; set; }
        public ICollection<ToolTask> ListaItemTarea { get; set; }
        public ICollection<ToolTeam> ListaItemEquipo { get; set; }
        public ICollection<RespuestaEtiqueta> RespuestaEtiquetaListaRespuesta { get; set; }
        public ICollection<RespuestaEtiqueta> RespuestaEtiquetaListaEtiqueta { get; set; }
        public ICollection<PerfilEtiqueta> EtiquetasListaItem { get; set; }
        public ICollection<AppUser> AppUserPreguntaConnecta { get; set; }
        public ICollection<Contacto> AppUserRespuestaConnecta { get; set; }

    }
}
