using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Community.Models.Messages
{
    [Table(name: "Conversacion")]
    public class Conversation
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        [Column(name: "id")]
        public Guid Id { get; set; }
        [Column(name: "user_sender_id")]
        public System.Nullable<Guid> UserSenderId { get; set; }
        public AppUser SenderUsuario { get; set; }
        [Column(name: "user_receptor_id")]
        public System.Nullable<Guid> UserReceptorId { get; set; }
        public AppUser ReceptorUsuario { get; set; }
        [Required]
        [Column(name: "fecha_creacion")]
        public DateTime FechaCreacion { get; set; }
        // public ICollection<Message> conversacionMensaje { get; set; }
        public ICollection<ConversationUnion> ConversacionSender { get; set; }
        public ICollection<ConversationUnion> ConversacionReceptor { get; set; }

    }
}

