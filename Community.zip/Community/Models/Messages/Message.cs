using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Community.Models.Messages
{
    [Table(name: "Mensaje")]
    public class Message
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        [Column(name: "id")]
        public Guid Id { get; set; }
        [Required]
        [Column(name: "mensaje", TypeName = "nvarchar(500)")]
        public string Mensaje { get; set; }
        [Required]
        [Column(name: "fecha_creacion")]
        public DateTime FechaCreacion { get; set; }
        [Column(name: "user_id")]
        public System.Nullable<Guid> AppUserId { get; set; }
        public AppUser Usuario { get; set; }
        [Column(name: "conversacion_id")]
        public Guid ConversacionId { get; set; }
        public ConversationUnion ConversacionUnion { get; set; }
        
        [Column(name: "leido")]
        public bool Leido { get; set; } = false;
         public string UrlGif { get; set; }
        public ICollection<Message_file> Messagefile { get; set; }

    }
}
