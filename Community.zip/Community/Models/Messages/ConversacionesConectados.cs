using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Community.Models.Messages
{
    [Table(name: "ConversacionesConectadas")]
    public class ConversacionesConectados
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        [Column(name: "id")]
        public Guid Id { get; set; }
        [Column(name: "conversacion_id")]
        public Guid ConversacionId { get; set; }
        public ConversationUnion Conversacion { get; set; }
        public System.Nullable<Guid> AppUserId { get; set; }
        public AppUser Usuario { get; set; }
        public string SocketId { get; set; }
    }
}
