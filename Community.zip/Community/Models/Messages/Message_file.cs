using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Community.Models.Messages
{
    [Table(name: "mensaje_file")]
    public class Message_file
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        [Column(name: "id")]
        public Guid Id { get; set; }
        [Required]
        [Column(name: "fecha_creacion")]
        public DateTime FechaCreacion { get; set; }
        [Column(name: "mensaje_id")]
        public Guid MensajeId { get; set; }
        public Message Mensaje { get; set; }
        [Column(name: "appfile_id")]
        public Guid AppFileId { get; set; }
        public AppFile AppFile { get; set; }
    }
}
