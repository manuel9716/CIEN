using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Community.Models.Messages
{
    [Table(name: "UsuariosConectadosChat")]
    public class UsuariosConectados
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        [Column(name: "id")]
        public Guid Id { get; set; }
        [Column(name: "user_id")]
        public System.Nullable<Guid> AppUserId { get; set; }
        public AppUser Usuario { get; set; }
        public string SocketId { get; set; }
    }
}
