using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Community.Models.Messages
{
    [Table(name: "Conversacion_Union")]
    public class ConversationUnion
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        [Column(name: "id")]
        public Guid Id { get; set; }
        public Guid IdSender { get; set; }
        public Guid IdReceptor { get; set; }
        public Conversation SenderConversacion { get; set; }
        public Conversation ReceptorConversacion { get; set; }
        [Required]
        [Column(name: "fecha_creacion")]
        public DateTime FechaCreacion { get; set; }
        public ICollection<Message> ConversacionMensaje { get; set; }
        public ICollection<ConversacionesConectados> ConversacionSala { get; set; }


    }
}