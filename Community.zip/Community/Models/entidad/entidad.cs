﻿using System.ComponentModel.DataAnnotations;
using System;
using System.ComponentModel.DataAnnotations.Schema;
using Community.Models.Cocrea;

namespace Community.Models.entidad
{
    [Table(name: "entidad")]
    public class entidad
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        [Column(name: "Id")]
        public Guid Id { get; set; }

        [MaxLength(255)]
        [Column(TypeName = "VARCHAR")]
        public string Nombre { get; set; }

        [MaxLength(255)]
        [Column(TypeName = "VARCHAR")]
        public string contacto { get; set; }

        [Required]
        public Guid ciudad_id { get; set; }
        public Guid? orden_id { get; set; }
        public Guid? sector_id { get; set; }
        public Guid? app_file_id { get; set; }

        [Required]
        [ForeignKey("ciudad_id")]
        public virtual ListaItem ciudadid { get; set; }

        [ForeignKey("orden_id")]
        public virtual ListaItem ordenid { get; set; }
        [ForeignKey("sector_id")]
        public virtual ListaItem sectorid { get; set; }

        [ForeignKey("app_file_id")]
        public virtual AppFile appfileid { get; set; }

    }
}
