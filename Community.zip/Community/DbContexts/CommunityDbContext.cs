using Microsoft.EntityFrameworkCore;
using Community.Models;
using Community.Models.publication;
using Community.Models.interests;
using Community.Models.Messages;
using Community.Models.notification;
using Community.Models.tool;
using Community.Models.experience;
using Community.Models.Learn;
using Community.Models.project;
using Community.Models.profiles;
using Community.Models.contactos;
using Community.Models.Cocrea;
using Community.Models.entidad;
using Community.Models.ChatBot;
using Community.Models.Metricas;

namespace Community.DbContexts
{
    public class CommunityDbContext : DbContext
    {
        public CommunityDbContext() { }

        public CommunityDbContext(DbContextOptions<CommunityDbContext> options) : base(options)
        { }

        public virtual DbSet<ListaItem> ListasItem { get; set; }
        public virtual DbSet<AppUser> AppUsers { get; set; }
        public virtual DbSet<Publication> Publicacion { get; set; }
        public virtual DbSet<Comment> Comentario { get; set; }
        public virtual DbSet<Iteracion> Iteracion { get; set; }
        public virtual DbSet<Publication_hide> PublicacionOcultar { get; set; }
        public virtual DbSet<Publication_report> PublicacionReportar { get; set; }
        public virtual DbSet<Publication_file> PublicacionFile { get; set; }
        public virtual DbSet<Interest> Intereses { get; set; }        

        //Files
        public virtual DbSet<AppFile> Files { get; set; }

        //mensajes
        public virtual DbSet<Conversation> Conversacion { get; set; }
        public virtual DbSet<Message> Mensajes { get; set; }    
        public virtual DbSet<ConversationUnion> ConversacionUnion { get; set; }    
        public virtual DbSet<UsuariosConectados> UsuarioConectado { get; set; }
        public virtual DbSet<ConversacionesConectados> ConversacionConectados { get; set; }
        public virtual DbSet<Message_file> MensajesFile { get; set; }
        
        //Notificaciones
        public virtual DbSet<Notification> Notificacion { get; set; }

        //Herramienta
        public virtual DbSet<Tool> Herramienta { get; set; }

        //Experiencia
        public virtual DbSet<Experience> Expereiencia { get; set; }

        //Aprende
        public virtual DbSet<Oferta> Oferta { get; set; }
        public virtual DbSet<Oferta_DIrigido_A> OfertaDirigidoA { get; set; }
        public virtual DbSet<Oferta_modulo> OfertaModulo { get; set; }
        public virtual DbSet<Oferta_tema> OfertaTema { get; set; }
        public virtual DbSet<Oferta_file> OfertaFile { get; set; }

        //PROJECT
        public virtual DbSet<Project> Project { get; set; }

        //PROFILE
        public virtual DbSet<RespuestaEtiqueta> RespuestaEtiqueta { get; set; }
        public virtual DbSet<PerfilEtiqueta> PerfilEtiqueta { get; set; }
        
        //Conecta con
        public virtual DbSet<Contacto> Contacto { get; set; }
        // entidad
        public virtual DbSet<entidad> Entidad { get; set; } 

        //Cocrea
        public virtual DbSet<Pregunta> Pregunta { get; set; }
        public virtual DbSet<Respuesta> Respuesta { get; set; }
        public virtual DbSet<RespuestaComentario> RespuestaComentario { get; set; }
        public virtual DbSet<RespuestaLike> RespuestaLike { get; set; }
        public virtual DbSet<DocumentoReto> DocumentoReto { get; set; }
        public virtual DbSet<EntidadReto> EntidadReto { get; set; }
        public virtual DbSet<EtapaReto> EtapaReto { get; set; }
        public virtual DbSet<IncentivoReto> IncentivoReto { get; set; }
        public virtual DbSet<Participante> Participante { get; set; }
        public virtual DbSet<ParticipanteReto> ParticipanteReto { get; set; }
        public virtual DbSet<Reto> Reto { get; set; }
        public virtual DbSet<Tema> Tema { get; set; }
        public virtual DbSet<TemaReto> TemaReto { get; set; }

        //ChatBot
        public virtual DbSet<MensajeChatbot> ChatBot { get; set; }

        //Metricas
        public virtual DbSet<LoginUsers> Loginuser { get; set; }
        public virtual DbSet<ModuloPrueba> ModuloPrueba { get; set; }


        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            //ListaItem
            modelBuilder.Entity<ListaItem>()
            .HasOne(d => d.Padre)
            .WithMany(p => p.Items)
            .HasForeignKey(d => d.PadreId)
            .HasPrincipalKey(p => p.Id)
            .OnDelete(DeleteBehavior.NoAction)
            .HasConstraintName("LISTA_ITEM_PADRE_COMMUNITY_FK");

            modelBuilder.Entity<ListaItem>()
            .HasIndex(l => l.Codigo)
            .IsUnique();

            modelBuilder.Entity<ListaItem>()
            .Property(l => l.FechaCreacion)
            .HasDefaultValueSql("getdate()");

            modelBuilder.Entity<ListaItem>()
            .Property(l => l.FechaActualizacion)
            .HasDefaultValueSql("getdate()");

            modelBuilder.Entity<ListaItem>()
            .Property(l => l.Orden)
            .HasDefaultValue(0);

            //AppUser
            modelBuilder.Entity<AppUser>()
            .HasOne(p => p.PaisResidencia)
            .WithMany(l => l.AppUsersPaisResidencia)
            .HasForeignKey(p => p.PaisResidenciaId)
            .HasPrincipalKey(l => l.Id)
            .OnDelete(DeleteBehavior.NoAction)
            .HasConstraintName("LISTA_APPUSER_PAISRESIDENCIA_FK");

            modelBuilder.Entity<AppUser>()
            .HasOne(p => p.DepartamentoResidencia)
            .WithMany(l => l.AppUsersDepartamentoResidencia)
            .HasForeignKey(p => p.DepartamentoResidenciaId)
            .HasPrincipalKey(l => l.Id)
            .OnDelete(DeleteBehavior.NoAction)
            .HasConstraintName("LISTA_APPUSER_DEPARTAMENTORESIDENCIA_FK");

            modelBuilder.Entity<AppUser>()
            .HasOne(p => p.MunicipioResidencia)
            .WithMany(l => l.AppUsersMunicipioResidencia)
            .HasForeignKey(p => p.MunicipioResidenciaId)
            .HasPrincipalKey(l => l.Id)
            .OnDelete(DeleteBehavior.NoAction)
            .HasConstraintName("LISTA_APPUSER_MUNICIPIORESIDENCIA_FK");

            modelBuilder.Entity<AppUser>()
            .HasOne(p => p.Genero)
            .WithMany(l => l.AppUsersGenero)
            .HasForeignKey(p => p.GeneroId)
            .HasPrincipalKey(l => l.Id)
            .OnDelete(DeleteBehavior.NoAction)
            .HasConstraintName("LISTA_APPUSER_GENERO_FK");

            modelBuilder.Entity<AppUser>()
            .HasOne(p => p.MotivoEliminacion)
            .WithMany(l => l.AppUsersMotivoEliminacion)
            .HasForeignKey(p => p.MotivoEliminacionId)
            .HasPrincipalKey(l => l.Id)
            .OnDelete(DeleteBehavior.NoAction)
            .HasConstraintName("LISTA_APPUSER_MOTIVO_ELIMINACION_FK");

            //Publication
           modelBuilder.Entity<Publication>()
           .Property(p => p.Descripcion)
           .HasColumnType("nvarchar(500)");
            
           modelBuilder.Entity<Publication>()
           .Property(p => p.UrlGif)
           .HasColumnType("nvarchar(max)");

           modelBuilder.Entity<Publication>()
           .HasOne(p => p.Usuario)
           .WithMany(l => l.AppUserpublicacion)
           .HasForeignKey(p => p.AppUserId)
           .HasPrincipalKey(l => l.Id)
           .OnDelete(DeleteBehavior.NoAction)
           .HasConstraintName("LISTA_PUBLICACIONES_APPUSER_FK");

           modelBuilder.Entity<Publication>()
           .HasOne(d => d.Compartir)
           .WithMany(p => p.Publicacion)
           .HasForeignKey(d => d.CompartirId)
           .HasPrincipalKey(p => p.Id)
           .OnDelete(DeleteBehavior.NoAction)
           .HasConstraintName("PUBLICACION_COMPARTIR_FK");

            //Commnet
            modelBuilder.Entity<Comment>()
            .Property(p => p.Descripcion)
            .HasColumnType("nvarchar(500)");

            modelBuilder.Entity<Comment>()
            .HasOne(p => p.Usuario)
            .WithMany(l => l.AppUsercomentario)
            .HasForeignKey(p => p.AppUserId)
            .HasPrincipalKey(l => l.Id)
            .OnDelete(DeleteBehavior.NoAction)
            .HasConstraintName("LISTA_COMENTARIOS_APPUSER_FK");

            modelBuilder.Entity<Comment>()
            .HasOne(p => p.Publicacion)
            .WithMany(l => l.Publicacioncomentario)
            .HasForeignKey(p => p.PublicacionId)
            .HasPrincipalKey(l => l.Id)
            .OnDelete(DeleteBehavior.NoAction)
            .HasConstraintName("LISTA_COMENTARIOS_PUBLICACION_FK");

            //Iteracion
            modelBuilder.Entity<Iteracion>()
            .HasOne(p => p.Usuario)
            .WithMany(l => l.AppUseriteracion)
            .HasForeignKey(p => p.AppUserId)
            .HasPrincipalKey(l => l.Id)
            .OnDelete(DeleteBehavior.NoAction)
            .HasConstraintName("LISTA_ITERACION_APPUSER_FK");

            modelBuilder.Entity<Iteracion>()
            .HasOne(p => p.Publicacion)
            .WithMany(l => l.Publicacioniteracion)
            .HasForeignKey(p => p.PublicacionId)
            .HasPrincipalKey(l => l.Id)
            .OnDelete(DeleteBehavior.NoAction)
            .HasConstraintName("LISTA_ITERACION_PUBLICACION_FK");

            modelBuilder.Entity<Iteracion>()
            .HasOne(p => p.Comentario)
            .WithMany(l => l.Comentarioiteracion)
            .HasForeignKey(p => p.ComentarioId)
            .HasPrincipalKey(l => l.Id)
            .OnDelete(DeleteBehavior.NoAction)
            .HasConstraintName("LISTA_ITERACION_COMENTARIO_FK");

            modelBuilder.Entity<Iteracion>()
            .HasOne(p => p.ListaItem)
            .WithMany(l => l.IteracionLIstaItem)
            .HasForeignKey(p => p.ListaItemId)
            .HasPrincipalKey(l => l.Id)
            .OnDelete(DeleteBehavior.NoAction)
            .HasConstraintName("LISTA_ITERACION_LISTAITEM_FK");

            //Publication_hide
            modelBuilder.Entity<Publication_hide>()
            .HasOne(p => p.Usuario)
            .WithMany(l => l.AppUserpublicacionocultar)
            .HasForeignKey(p => p.AppUserId)
            .HasPrincipalKey(l => l.Id)
            .OnDelete(DeleteBehavior.NoAction)
            .HasConstraintName("LISTA_PUBLICACION_OCULTAR_APPUSER_FK");

            modelBuilder.Entity<Publication_hide>()
            .HasOne(p => p.Publicacion)
            .WithMany(l => l.Publicacionocultar)
            .HasForeignKey(p => p.PublicacionId)
            .HasPrincipalKey(l => l.Id)
            .OnDelete(DeleteBehavior.NoAction)
            .HasConstraintName("LISTA_PUBLICACION_OCULTAR_PUBLICACION_FK");

            modelBuilder.Entity<Publication_hide>()
            .HasOne(p => p.ListaItem)
            .WithMany(l => l.publicacionocultarLIstaItem)
            .HasForeignKey(p => p.ListaItemId)
            .HasPrincipalKey(l => l.Id)
            .OnDelete(DeleteBehavior.NoAction)
            .HasConstraintName("LISTA_PUBLICACION_OCULTAR_LISTAITEM_FK");

            //publication_repport
            modelBuilder.Entity<Publication_report>()
            .HasOne(p => p.Usuario)
            .WithMany(l => l.AppUserpublicacionreportar)
            .HasForeignKey(p => p.AppUserId)
            .HasPrincipalKey(l => l.Id)
            .OnDelete(DeleteBehavior.NoAction)
            .HasConstraintName("LISTA_PUBLICACION_REPORTAR_APPUSER_FK");

            modelBuilder.Entity<Publication_report>()
            .HasOne(p => p.Publicacion)
            .WithMany(l => l.Publicacionreportar)
            .HasForeignKey(p => p.PublicacionId)
            .HasPrincipalKey(l => l.Id)
            .OnDelete(DeleteBehavior.NoAction)
            .HasConstraintName("LISTA_PUBLICACION_REPORTAR_PUBLICACION_FK");

            //publication_file
            modelBuilder.Entity<Publication_file>()
            .HasOne(p => p.AppFile)
            .WithMany(l => l.publicacionfileAppFile)
            .HasForeignKey(p => p.AppFileId)
            .HasPrincipalKey(l => l.Id)
            .OnDelete(DeleteBehavior.NoAction)
            .HasConstraintName("LISTA_PUBLICACION_FILE_APPFILE_FK");

            modelBuilder.Entity<Publication_file>()
            .HasOne(p => p.Publicacion)
            .WithMany(l => l.Publicacionfile)
            .HasForeignKey(p => p.PublicacionId)
            .HasPrincipalKey(l => l.Id)
            .OnDelete(DeleteBehavior.NoAction)
            .HasConstraintName("LISTA_PUBLICACION_FILE_PUBLICACION_FK");

            modelBuilder.Entity<Comment>()
            .HasOne(d => d.Padre)
            .WithMany(p => p.Comentario)
            .HasForeignKey(d => d.PadreId)
            .HasPrincipalKey(p => p.Id)
            .OnDelete(DeleteBehavior.NoAction)
            .HasConstraintName("COMENTARIO_PADRE_FK");

            modelBuilder.Entity<AppFile>()
            .Property(c => c.CreatedAt)
            .HasDefaultValueSql("getdate()");

            modelBuilder.Entity<AppFile>()
            .Property(c => c.UpdatedAt)
            .HasDefaultValueSql("getdate()");

            modelBuilder.Entity<Interest>()
            .HasOne(p => p.Usuario)
            .WithMany(p => p.AppUserIntereses)
            .HasForeignKey(p => p.AppUserId)
            .HasPrincipalKey(l => l.Id)
            .OnDelete(DeleteBehavior.NoAction)
            .HasConstraintName("LISTA_INTERESES_APPUSER_FK");

            modelBuilder.Entity<Interest>()
            .HasOne(p => p.ListaItem)
            .WithMany(l => l.interestsListaItem)
            .HasForeignKey(p => p.ListaItemId)
            .HasPrincipalKey(l => l.Id)
            .OnDelete(DeleteBehavior.NoAction)
            .HasConstraintName("LISTA_INTERESES_SEGERENCIA_FK"); 

            modelBuilder.Entity<AppUser>()
            .Property(c => c.Notificar)
            .HasDefaultValueSql("0"); 

            modelBuilder.Entity<AppUser>()
            .Property(c => c.MostrarCorreo)
            .HasDefaultValueSql("0");    

            modelBuilder.Entity<AppUser>()
            .Property(c => c.MostrarTelefono)
            .HasDefaultValueSql("0");   

            modelBuilder.Entity<AppUser>()
            .Property(c => c.MostrarRedes)
            .HasDefaultValueSql("0");     

            //mensajes
            modelBuilder.Entity<Conversation>()
            .HasOne(p => p.SenderUsuario)
            .WithMany(l => l.AppUserSender)
            .HasForeignKey(p => p.UserSenderId)
            .HasPrincipalKey(l => l.Id)
            .OnDelete(DeleteBehavior.NoAction)
            .HasConstraintName("CONVERSACIONES_APPUSERSENDER_FK");

            modelBuilder.Entity<Conversation>()
            .HasOne(p => p.ReceptorUsuario)
            .WithMany(l => l.AppUserReceptor)
            .HasForeignKey(p => p.UserReceptorId)
            .HasPrincipalKey(l => l.Id)
            .OnDelete(DeleteBehavior.NoAction)
            .HasConstraintName("CONVERSACIONES_APPUSERRECEPTOR_FK");

            modelBuilder.Entity<ConversationUnion>()
            .HasOne(p => p.SenderConversacion)
            .WithMany(l => l.ConversacionSender)
            .HasForeignKey(p => p.IdSender)
            .HasPrincipalKey(l => l.Id)
            .OnDelete(DeleteBehavior.NoAction)
            .HasConstraintName("CONVERSACIONUNION_CONVERSACIONSENDER_FK");

            modelBuilder.Entity<ConversationUnion>()
            .HasOne(p => p.ReceptorConversacion)
            .WithMany(l => l.ConversacionReceptor)
            .HasForeignKey(p => p.IdReceptor)
            .HasPrincipalKey(l => l.Id)
            .OnDelete(DeleteBehavior.NoAction)
            .HasConstraintName("CONVERSACIONUNION_CONVERSACIONRECEPTOR_FK");

            modelBuilder.Entity<Message>()
            .HasOne(p => p.Usuario)
            .WithMany(l => l.AppUserMensaje)
            .HasForeignKey(p => p.AppUserId)
            .HasPrincipalKey(l => l.Id)
            .OnDelete(DeleteBehavior.NoAction)
            .HasConstraintName("MENSAJES_APPUSER_FK");

            modelBuilder.Entity<Message>()
            .HasOne(p => p.ConversacionUnion)
            .WithMany(l => l.ConversacionMensaje)
            .HasForeignKey(p => p.ConversacionId)
            .HasPrincipalKey(l => l.Id)
            .OnDelete(DeleteBehavior.NoAction)
            .HasConstraintName("MENSAJES_CONVERSACION_FK");

            modelBuilder.Entity<UsuariosConectados>()
            .HasOne(p => p.Usuario)
            .WithMany(l => l.AppUserConectados)
            .HasForeignKey(p => p.AppUserId)
            .HasPrincipalKey(l => l.Id)
            .OnDelete(DeleteBehavior.NoAction)
            .HasConstraintName("USUARIOCONECTADO_APPUSER_FK");

            modelBuilder.Entity<ConversacionesConectados>()
            .HasOne(p => p.Conversacion)
            .WithMany(l => l.ConversacionSala)
            .HasForeignKey(p => p.ConversacionId)
            .HasPrincipalKey(l => l.Id)
            .OnDelete(DeleteBehavior.NoAction)
            .HasConstraintName("CONVERSACIONCONECTADO_CONVERSACION_FK");

            modelBuilder.Entity<ConversacionesConectados>()
            .HasOne(p => p.Usuario)
            .WithMany(l => l.AppUserSalasConectados)
            .HasForeignKey(p => p.AppUserId)
            .HasPrincipalKey(l => l.Id)
            .OnDelete(DeleteBehavior.NoAction)
            .HasConstraintName("CONVERSACIONCONECTADO_USUARIOS_FK");
            
            modelBuilder.Entity<Message_file>()
            .HasOne(p => p.AppFile)
            .WithMany(l => l.mensajefileAppFile)
            .HasForeignKey(p => p.AppFileId)
            .HasPrincipalKey(l => l.Id)
            .OnDelete(DeleteBehavior.NoAction)
            .HasConstraintName("MENSAJE_FILE_APPFILE_FK");

            modelBuilder.Entity<Message_file>()
            .HasOne(p => p.Mensaje)
            .WithMany(l => l.Messagefile)
            .HasForeignKey(p => p.MensajeId)
            .HasPrincipalKey(l => l.Id)
            .OnDelete(DeleteBehavior.NoAction)
            .HasConstraintName("MENSAJES_FILE_MENSAJES_FK");

            //aprende
            modelBuilder.Entity<Oferta>()
            .HasOne(p => p.ListaItemTiempo)
            .WithMany(l => l.OfertaLIstaItemTiempo)
            .HasForeignKey(p => p.TiempoId)
            .HasPrincipalKey(l => l.Id)
            .OnDelete(DeleteBehavior.NoAction)
            .HasConstraintName("OFERTA_LISTAITEMTIEMPO_FK");

            modelBuilder.Entity<Oferta>()
            .HasOne(p => p.ListaItemTipo)
            .WithMany(l => l.OfertaLIstaItemTipo)
            .HasForeignKey(p => p.TipoId)
            .HasPrincipalKey(l => l.Id)
            .OnDelete(DeleteBehavior.NoAction)
            .HasConstraintName("OFERTA_LISTAITEMTIPO_FK");

            modelBuilder.Entity<Oferta>()
            .HasOne(p => p.Usuario)
            .WithMany(l => l.AppUseroferta)
            .HasForeignKey(p => p.AppUserId)
            .HasPrincipalKey(l => l.Id)
            .OnDelete(DeleteBehavior.NoAction)
            .HasConstraintName("OFERTA_APPUSER_FK");

            modelBuilder.Entity<Oferta_file>()
            .HasOne(p => p.AppFile)
            .WithMany(l => l.OfertafileAppFile)
            .HasForeignKey(p => p.AppFileId)
            .HasPrincipalKey(l => l.Id)
            .OnDelete(DeleteBehavior.NoAction)
            .HasConstraintName("OFERTA_FILE_APPFILE_FK");

            modelBuilder.Entity<Oferta_file>()
            .HasOne(p => p.Oferta)
            .WithMany(l => l.Ofertafile)
            .HasForeignKey(p => p.OfertaId)
            .HasPrincipalKey(l => l.Id)
            .OnDelete(DeleteBehavior.NoAction)
            .HasConstraintName("OFERTA_FILE_OFERTA_FK");

            modelBuilder.Entity<Oferta>()
            .HasOne(p => p.AppFilePortada)
            .WithMany(l => l.OfertaPortadaAppFile)
            .HasForeignKey(p => p.AppFilePortadaId)
            .HasPrincipalKey(l => l.Id)
            .OnDelete(DeleteBehavior.NoAction)
            .HasConstraintName("OFERTA_PORTADA_FILE_OFERTA_FK");

            modelBuilder.Entity<Oferta_DIrigido_A>()
            .HasOne(p => p.Oferta)
            .WithMany(l => l.OfertaDirigidoA)
            .HasForeignKey(p => p.OfertaId)
            .HasPrincipalKey(l => l.Id)
            .OnDelete(DeleteBehavior.NoAction)
            .HasConstraintName("OFERTA_DIRIGIDO_A_OFERTA_FK");

            modelBuilder.Entity<Oferta_DIrigido_A>()
            .HasOne(p => p.ListaItemDirigidoA)
            .WithMany(l => l.OfertaLIstaItemDirigidoA)
            .HasForeignKey(p => p.DirigidoAId)
            .HasPrincipalKey(l => l.Id)
            .OnDelete(DeleteBehavior.NoAction)
            .HasConstraintName("OFERTA_LISTAITEMDIRIGIDOA_FK");

            modelBuilder.Entity<Oferta_tema>()
            .HasOne(p => p.Oferta)
            .WithMany(l => l.OfertaTema)
            .HasForeignKey(p => p.OfertaId)
            .HasPrincipalKey(l => l.Id)
            .OnDelete(DeleteBehavior.NoAction)
            .HasConstraintName("OFERTA_TEMA_OFERTA_FK");

            modelBuilder.Entity<Oferta_tema>()
            .HasOne(p => p.ListaItemTema)
            .WithMany(l => l.OfertaLIstaItemTema)
            .HasForeignKey(p => p.TemaId)
            .HasPrincipalKey(l => l.Id)
            .OnDelete(DeleteBehavior.NoAction)
            .HasConstraintName("OFERTA_LISTAITEMTEMA_FK");

            modelBuilder.Entity<Oferta_modulo>()
            .HasOne(p => p.Oferta)
            .WithMany(l => l.OfertaModulo)
            .HasForeignKey(p => p.OfertaId)
            .HasPrincipalKey(l => l.Id)
            .OnDelete(DeleteBehavior.NoAction)
            .HasConstraintName("OFERTA_MODULO_OFERTA_FK");
            
            //perfiles
            modelBuilder.Entity<AppUser>()
            .HasOne(p => p.Organizacion)
            .WithMany(l => l.AppUserOrganizacion)
            .HasForeignKey(p => p.OrganizacionId)
            .HasPrincipalKey(l => l.Id)
            .OnDelete(DeleteBehavior.NoAction)
            .HasConstraintName("LISTA_PERFIL_ORGANIZACION_FK");
            
            modelBuilder.Entity<AppUser>()
            .HasOne(p => p.AreaDireccionEquipo)
            .WithMany(l => l.AppUserAreaDireccionEquipo)
            .HasForeignKey(p => p.AreaDireccionEquipoId)
            .HasPrincipalKey(l => l.Id)
            .OnDelete(DeleteBehavior.NoAction)
            .HasConstraintName("LISTA_PERFIL_AreaDireccionEquipo_FK");
            
            modelBuilder.Entity<AppUser>()
            .HasOne(p => p.Sector)
            .WithMany(l => l.AppUserSector)
            .HasForeignKey(p => p.SectorId)
            .HasPrincipalKey(l => l.Id)
            .OnDelete(DeleteBehavior.NoAction)
            .HasConstraintName("LISTA_PERFIL_Sector_FK");

            modelBuilder.Entity<AppUser>()
            .HasOne(p => p.Orden)
            .WithMany(l => l.AppUserOrden)
            .HasForeignKey(p => p.OrdenId)
            .HasPrincipalKey(l => l.Id)
            .OnDelete(DeleteBehavior.NoAction)
            .HasConstraintName("LISTA_PERFIL_Orden_FK");

            modelBuilder.Entity<AppUser>()
            .HasOne(p => p.Profesion)
            .WithMany(l => l.AppUserProfesion)
            .HasForeignKey(p => p.ProfesionId)
            .HasPrincipalKey(l => l.Id)
            .OnDelete(DeleteBehavior.NoAction)
            .HasConstraintName("LISTA_PERFIL_Profesion_FK");   

            modelBuilder.Entity<AppUser>()
            .HasOne(p => p.CargoActual)
            .WithMany(l => l.AppUserCargoActual)
            .HasForeignKey(p => p.CargoActualId)
            .HasPrincipalKey(l => l.Id)
            .OnDelete(DeleteBehavior.NoAction)
            .HasConstraintName("LISTA_PERFIL_CargoActual_FK");

            modelBuilder.Entity<AppUser>()
            .HasOne(p => p.Nivel)
            .WithMany(l => l.AppUserNivel)
            .HasForeignKey(p => p.NivelId)
            .HasPrincipalKey(l => l.Id)
            .OnDelete(DeleteBehavior.NoAction)
            .HasConstraintName("LISTA_PERFIL_NIvel_FK");

            //Notifiacion     
            modelBuilder.Entity<Notification>()
            .HasOne(p => p.User)
            .WithMany(l => l.AppUsernoticaciondestino)
            .HasForeignKey(p => p.UserId)
            .HasPrincipalKey(l => l.Id)
            .OnDelete(DeleteBehavior.NoAction)
            .HasConstraintName("NOTIFICACION_APPUSER_DESTINO_FK");

            modelBuilder.Entity<Notification>()
            .HasOne(p => p.UserOrigen)
            .WithMany(l => l.AppUsernoticacionorigen)
            .HasForeignKey(p => p.UserOrigenId)
            .HasPrincipalKey(l => l.Id)
            .OnDelete(DeleteBehavior.NoAction)
            .HasConstraintName("NOTIFICACION_APPUSER_ORIGEN_FK");

            modelBuilder.Entity<Notification>()
            .HasOne(p => p.Publicacion)
            .WithMany(l => l.Publicacionnotificacion)
            .HasForeignKey(p => p.PublicacionId)
            .HasPrincipalKey(l => l.Id)
            .OnDelete(DeleteBehavior.NoAction)
            .HasConstraintName("NOTIFICACION_PUBLICACION_FK");

            modelBuilder.Entity<Notification>()
            .HasOne(p => p.Iteracion)
            .WithMany(l => l.Iteracionnotificacion)
            .HasForeignKey(p => p.IteracionId)
            .HasPrincipalKey(l => l.Id)
            .OnDelete(DeleteBehavior.NoAction)
            .HasConstraintName("NOTIFICACION_ITERACION_FK");

             modelBuilder.Entity<Notification>()
            .Property(l => l.activa)
            .HasDefaultValue(1);

            //Herramientas
            modelBuilder.Entity<Tool>()
            .HasOne(p => p.Usuario)
            .WithMany(l => l.AppUserTool)
            .HasForeignKey(p => p.AppUserId)
            .HasPrincipalKey(l => l.Id)
            .OnDelete(DeleteBehavior.NoAction)
            .HasConstraintName("Usuario_Tool_FK");

            //modelBuilder.Entity<Tool>()
            //.HasOne(p => p.TipoRecurso)
            //.WithMany(l => l.ListaTipoRecurso)
            //.HasForeignKey(p => p.TipoRecursoID)
            //.HasPrincipalKey(l => l.Id)
            //.OnDelete(DeleteBehavior.NoAction)
            //.HasConstraintName("LISTA_Tool_TipoRecurso_FK");

            //modelBuilder.Entity<Tool>()
            //.HasOne(p => p.TipoHerramienta)
            //.WithMany(l => l.ListaTipoHerramienta)
            //.HasForeignKey(p => p.TipoHerramientaID)
            //.HasPrincipalKey(l => l.Id)
            //.OnDelete(DeleteBehavior.NoAction)
            //.HasConstraintName("LISTA_Tool_TipoHerramienta_FK");

            modelBuilder.Entity<ToolFase>()
             .HasOne(p => p.tool)
             .WithMany(l => l.ToolFases)
             .HasForeignKey(p => p.toolId)
             .HasPrincipalKey(l => l.Id)
             .OnDelete(DeleteBehavior.NoAction)
             .HasConstraintName("Tool_Fase_FK");

            modelBuilder.Entity<ToolTask>()
             .HasOne(p => p.tool)
             .WithMany(l => l.ToolTareas)
             .HasForeignKey(p => p.toolId)
             .HasPrincipalKey(l => l.Id)
             .OnDelete(DeleteBehavior.NoAction)
             .HasConstraintName("Tool_Tarea_FK");

            //modelBuilder.Entity<ToolTeam>()
            // .HasOne(p => p.tool)
            // .WithMany(l => l.ToolEquipos)
            // .HasForeignKey(p => p.toolId)
            // .HasPrincipalKey(l => l.Id)
            // .OnDelete(DeleteBehavior.NoAction)
            // .HasConstraintName("Tool_Equipo_FK");

            //modelBuilder.Entity<ToolFase>()
            //.HasOne(p => p.Fases)
            //.WithMany(l => l.ListaItemFase)
            //.HasForeignKey(p => p.FasesID)
            //.HasPrincipalKey(l => l.Id)
            //.OnDelete(DeleteBehavior.NoAction)
            //.HasConstraintName("LISTA_Tool_Fase_FK");

            //modelBuilder.Entity<ToolTask>()
            //.HasOne(p => p.Tareas)
            //.WithMany(l => l.ListaItemTarea)
            //.HasForeignKey(p => p.TareasID)
            //.HasPrincipalKey(l => l.Id)
            //.OnDelete(DeleteBehavior.NoAction)
            //.HasConstraintName("LISTA_Tool_Tarea_FK");

            modelBuilder.Entity<ToolTeam>()
            .HasOne(p => p.Equipos)
            .WithMany(l => l.ListaItemEquipo)
            .HasForeignKey(p => p.EquiposID)
            .HasPrincipalKey(l => l.Id)
            .OnDelete(DeleteBehavior.NoAction)
            .HasConstraintName("LISTA_Tool_Equipo_FK");

            //Experiencias
            modelBuilder.Entity<Experience>()
            .HasOne(p => p.Usuario)
            .WithMany(l => l.AppUserExperience)
            .HasForeignKey(p => p.AppUserId)
            .HasPrincipalKey(l => l.Id)
            .OnDelete(DeleteBehavior.NoAction)
            .HasConstraintName("Usuario_Experiencia_FK");

            modelBuilder.Entity<AppUser>()
            .HasOne(p => p.ProyectoActual)
            .WithMany(l => l.AppUserProyectoActual)
            .HasForeignKey(p => p.ProyectoActualId)
            .HasPrincipalKey(l => l.Id)
            .OnDelete(DeleteBehavior.NoAction)
            .HasConstraintName("LISTA_APPUSER_ProyectoActual_FK");

            modelBuilder.Entity<AppUser>()
            .HasOne(p => p.ProyectoDestacado)
            .WithMany(l => l.AppUserProyectoDestacado)
            .HasForeignKey(p => p.ProyectoDestacadoId)
            .HasPrincipalKey(l => l.Id)
            .OnDelete(DeleteBehavior.NoAction)
            .HasConstraintName("LISTA_APPUSER_ProyectoDestacado_FK");

            //Respuesta etiqueta
            modelBuilder.Entity<RespuestaEtiqueta>()
            .HasOne(p => p.Respuesta)
            .WithMany(l => l.RespuestaEtiquetaListaRespuesta)
            .HasForeignKey(p => p.RespuestaId)
            .HasPrincipalKey(l => l.Id)
            .OnDelete(DeleteBehavior.NoAction)
            .HasConstraintName("LISTA_RESPUESTAETIQUETA_Respuesta_FK");

            modelBuilder.Entity<RespuestaEtiqueta>()
            .HasOne(p => p.Etiqueta)
            .WithMany(l => l.RespuestaEtiquetaListaEtiqueta)
            .HasForeignKey(p => p.EtiquetaId)
            .HasPrincipalKey(l => l.Id)
            .OnDelete(DeleteBehavior.NoAction)
            .HasConstraintName("LISTA_RESPUESTAETIQUETA_Etiqueta_FK");


            modelBuilder.Entity<AppUser>()
            .HasOne(p => p.AppFile)
            .WithMany(l => l.AppUserAppFile)
            .HasForeignKey(p => p.AppFileId)
            .HasPrincipalKey(l => l.Id)
            .OnDelete(DeleteBehavior.NoAction)
            .HasConstraintName("APPUSER_APPFILE_FK");

            //Perfil etiqueta
            modelBuilder.Entity<PerfilEtiqueta>()
            .HasOne(p => p.AppUser)
            .WithMany(l => l.AppUserEtiquetas)
            .HasForeignKey(p => p.AppUserId)
            .HasPrincipalKey(l => l.Id)
            .OnDelete(DeleteBehavior.NoAction)
            .HasConstraintName("APPUSER_ETIQUETAS_FK");

            modelBuilder.Entity<PerfilEtiqueta>()
            .HasOne(p => p.ListaItem)
            .WithMany(l => l.EtiquetasListaItem)
            .HasForeignKey(p => p.ListaItemId)
            .HasPrincipalKey(l => l.Id)
            .OnDelete(DeleteBehavior.NoAction)
            .HasConstraintName("LISTA_ETIQUETAS_Etiqueta_FK");

            modelBuilder.Entity<AppUser>()
            .HasOne(p => p.PreguntaConecta)
            .WithMany(l => l.AppUserPreguntaConnecta)
            .HasForeignKey(p => p.PreguntaConectaId)
            .HasPrincipalKey(l => l.Id)
            .OnDelete(DeleteBehavior.NoAction)
            .HasConstraintName("LISTA_PERFIL_PreguntaConecta_FK");

            //Contacto
            modelBuilder.Entity<Contacto>()
            .HasOne(p => p.AppUser)
            .WithMany(l => l.AppUserContactoUser)
            .HasForeignKey(p => p.UserId)
            .HasPrincipalKey(l => l.Id)
            .OnDelete(DeleteBehavior.NoAction)
            .HasConstraintName("CONTACTO_User_FK");

            modelBuilder.Entity<Contacto>()
            .HasOne(p => p.Contact)
            .WithMany(l => l.AppUserContacto)
            .HasForeignKey(p => p.ContactId)
            .HasPrincipalKey(l => l.Id)
            .OnDelete(DeleteBehavior.NoAction)
            .HasConstraintName("CONTACTO_User_CONTACTO_FK");

            modelBuilder.Entity<Contacto>()
            .HasOne(p => p.RespuestaContacto)
            .WithMany(l => l.AppUserRespuestaConnecta)
            .HasForeignKey(p => p.RespuestaContactoId)
            .HasPrincipalKey(l => l.Id)
            .HasConstraintName("LISTA_CONTACTO_RespuestaConecta_FK");

            modelBuilder.Entity<Tool>()
            .HasOne(p => p.TipoRecurso)
            .WithMany(l => l.ListaTipoRecurso)
            .HasForeignKey(p => p.TipoRecursoID)
            .HasPrincipalKey(l => l.Id)
            .OnDelete(DeleteBehavior.NoAction)
            .HasConstraintName("LISTA_Tool_TipoRecurso_FK");

            modelBuilder.Entity<Tool>()
            .HasOne(p => p.TipoHerramienta)
            .WithMany(l => l.ListaTipoHerramienta)
            .HasForeignKey(p => p.TipoHerramientaID)
            .HasPrincipalKey(l => l.Id)
            .OnDelete(DeleteBehavior.NoAction)
            .HasConstraintName("LISTA_Tool_TipoHerramienta_FK");

            modelBuilder.Entity<Contacto>()
            .Property(l => l.FechaCreacion)
            .HasDefaultValueSql("getdate()");


            //ChatBot
            modelBuilder.Entity<MensajeChatbot>()
            .HasIndex(l => l.Llave)
            .IsUnique();
        }
    }
}