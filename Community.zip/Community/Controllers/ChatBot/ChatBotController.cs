﻿using AutoWrapper.Wrappers;
using Community.Dtos.AppUsers.Models;
using Community.Dtos.ChatBot.Models;
using Community.Services.ChatBot;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Community.Controllers.ChatBot
{

    [ApiController]
    [Route("/api/community/v1/chatbot")]
    public class ChatBotController : Controller
    {
        private readonly IChatBotServices _service;

        public ChatBotController(IChatBotServices service)
        {
            _service = service;
        }


        [HttpGet("MensajeChatBot")]
        public async Task<IActionResult> GetMensajeChatBotMarco([FromQuery] string llave, string email)
        {
            if (llave == null)
            {
                return NotFound(new ApiResponse("Se debe de Ingresar una llave", "Se debe de Ingresar una llave", 404));
            }

            if (!string.IsNullOrEmpty(email))
            {
                //Se valida el correo contra la DB
                ReadProfileAppUser result = await _service.ValidarCorreo(email);

                if(result == null){
                    #region NumeroIntentos
                    switch (llave)
                    {
                        case "ENTR-01":
                            llave = "VAL-01";
                            break;
                        case "ENTR-02":
                            llave = "VAL-02";
                            break;
                        case "ENTR-03":
                            llave = "VAL-03";
                            break;
                        case "ENTR-04":
                            llave = "VAL-04";
                            break;
                        case "ENTR-05":
                            llave = "VAL-05";
                            break;
                        default:
                            break;
                    }
                    #endregion NumeroIntentos
                }
                else
                {
                    llave = "CORREO_EXISTE";
                }


            }

            List<ReadMensajeChatBot> response = await _service.GetMensajesChatBot(llave,email);

            List<ReadMensajeChatBot> lista = new List<ReadMensajeChatBot>();

            if (response.Count == 1)
            {
                string[] proximoEstado = response[0].Siguiente.Split(",".ToCharArray());
                if(proximoEstado.Length > 0)
                {
                    try
                    {
                        for (int i = 0; i < proximoEstado.Length; i++)
                        {
                            List<ReadMensajeChatBot> dataSiguiente = await _service.GetMensajesChatBot(proximoEstado[i].ToString(), email);
                            ReadMensajeChatBot element = new ReadMensajeChatBot();
                            if (dataSiguiente.Count > 0)
                            {
                                element.IDChatBot = dataSiguiente[0].IDChatBot;
                                element.HTMLTexto = dataSiguiente[0].HTMLTexto;
                                element.Llave = dataSiguiente[0].Llave;
                                element.Ubicacion = dataSiguiente[0].Ubicacion;
                                element.Tipo = dataSiguiente[0].Tipo;
                                element.Anterior = dataSiguiente[0].Anterior;
                                element.Ejecucion = dataSiguiente[0].Ejecucion;
                                element.Siguiente = dataSiguiente[0].Siguiente;
                                element.Estado = dataSiguiente[0].Estado;
                                lista.Add(element);

                                if (dataSiguiente[0].Ejecucion.ToString() == "SI")
                                {
                                    string[] siguienteEstado = dataSiguiente[0].Siguiente.Split(",".ToCharArray());
                                    for (int x = 0; x < siguienteEstado.Length; x++)
                                    {
                                        ReadMensajeChatBot segundaPosicion = new ReadMensajeChatBot();
                                        List<ReadMensajeChatBot> respSegunda = await _service.GetMensajesChatBot(siguienteEstado[x].ToString(), email);
                                        segundaPosicion.IDChatBot = respSegunda[0].IDChatBot;
                                        segundaPosicion.HTMLTexto = respSegunda[0].HTMLTexto;
                                        segundaPosicion.Llave = respSegunda[0].Llave;
                                        segundaPosicion.Ubicacion = respSegunda[0].Ubicacion;
                                        segundaPosicion.Tipo = respSegunda[0].Tipo;
                                        segundaPosicion.Anterior = respSegunda[0].Anterior;
                                        segundaPosicion.Ejecucion = respSegunda[0].Ejecucion;
                                        segundaPosicion.Siguiente = respSegunda[0].Siguiente;
                                        segundaPosicion.Estado = respSegunda[0].Estado;
                                        lista.Add(segundaPosicion);

                                        if (respSegunda[0].Ejecucion.ToString() == "SI")
                                        {
                                            string[] siguienteEstado3 = respSegunda[0].Siguiente.Split(",".ToCharArray());
                                            for (int y = 0; y < siguienteEstado3.Length; y++)
                                            {
                                                ReadMensajeChatBot terceraPosicion = new ReadMensajeChatBot();
                                                List<ReadMensajeChatBot> respTercera = await _service.GetMensajesChatBot(siguienteEstado3[y].ToString(),email);
                                                terceraPosicion.IDChatBot = respTercera[0].IDChatBot;
                                                terceraPosicion.HTMLTexto = respTercera[0].HTMLTexto;
                                                terceraPosicion.Llave = respTercera[0].Llave;
                                                terceraPosicion.Ubicacion = respTercera[0].Ubicacion;
                                                terceraPosicion.Tipo = respTercera[0].Tipo;
                                                terceraPosicion.Anterior = respTercera[0].Anterior;
                                                terceraPosicion.Ejecucion = respTercera[0].Ejecucion;
                                                terceraPosicion.Siguiente = respTercera[0].Siguiente;
                                                terceraPosicion.Estado = respTercera[0].Estado;
                                                lista.Add(terceraPosicion);
                                            }
                                        }
                                    }

                                 
                                }
                            }



                        }
                        lista.Where(r => r.Estado == 1).OrderByDescending(a => a.Ubicacion).ToList();
                        lista.AsReadOnly();
                    }
                    catch (Exception ex)
                    {
                        return NotFound(ex.Message);
                    }

                }    
                
            }


            if (lista != null)
            {
                return Ok(new ApiResponse("conversation found.", lista, 200));
            }
            else
            {
                return NotFound(new ApiResponse("conversation not found.", null, 404));
            }
        }



    }
}
