﻿using Application.Clients.Keycloak.Services.Users;
using AutoWrapper.Wrappers;
using Community.Dtos.Cocrea.Models.inputsModels.Preguntas;
using Community.Dtos.Cocrea.Models.inputsModels.Retos;
using Community.Dtos.Cocrea.Models.Retos;
using Community.Dtos.Pagination.Models;
using Community.Dtos.Pagination.Services;
using Community.Services.Cocrea;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Net.Mime;
using System.Threading;
using System.Threading.Tasks;

namespace Community.Controllers.Cocrea
{

    [ApiController]
    [Route("/api/community/v1/cocrea")]

    public class CocreaController : ControllerBase
    {

        private readonly ICocreaServices _service;
        private readonly IUriService _uriService;
        private readonly IActorService _actorService;

        public CocreaController(ICocreaServices service, IUriService uriService, IActorService actorService)
        {
            _service = service;
            _uriService = uriService;
            _actorService = actorService;
        }

        #region Preguntas

        [HttpGet("pregunta/listado")]
        public async Task<IActionResult> PreguntaList([FromQuery] Paginator paginator, CancellationToken cancellationToken)
        {

            var response = await _service.GetListaPreguntas(paginator);
            if (response != null)
            {
                return Ok(new ApiResponse("PreguntaList found.", response, 200));
            }
            else
            {
                return NotFound(new ApiResponse("PreguntaList not found.", null, 404));
            }
        }
        [HttpGet("pregunta/listado-extendido")]
        [Authorize]
        public async Task<IActionResult> PreguntaListEX([FromQuery] Paginator paginator)
        {
            var response = await _service.GetListaPreguntasEX(paginator);
            if (response != null)
            {
                return Ok(new ApiResponse("GetListaPreguntasEX found.", response, 200));
            }
            else
            {
                return NotFound(new ApiResponse("GetListaPreguntasEX not found.", null, 404));
            }
        }
        [HttpGet("pregunta/listado-extendido/{Id}")]
        [Authorize]
        public async Task<IActionResult> GetPreguntaById([FromQuery] Paginator paginator, Guid Id, bool desc= true, bool fecha=true)
        {
            var response = await _service.GetPreguntaById(paginator,Id,desc,fecha);
            if (response != null)
            {
                return Ok(new ApiResponse("GetPreguntaById found.", response, 200));
            }
            else
            {
                return NotFound(new ApiResponse("GetPreguntaById not found.", null, 404));
            }
        }
        [HttpGet("preguntaRandom")]
        public async Task<IActionResult> GetPreguntarandom()
        {
            var response = await _service.GetPreguntarandom();
            if (response != null)
            {
                return Ok(new ApiResponse("GetPreguntaById found.", response, 200));
            }
            else
            {
                return NotFound(new ApiResponse("GetPreguntaById not found.", null, 404));
            }

        }

        [HttpPost("pregunta")]
        [Consumes(MediaTypeNames.Application.Json)]
        [ProducesResponseType(StatusCodes.Status201Created)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        [Authorize]
        public IActionResult Insertpregunta(InputPreguntaModels Dta)
        {
            var response = _service.Insertpregunta(Dta);

            if (response != null)
            {
                return Ok(new ApiResponse("Insertpregunta found.", response, 200));
            }
            else
            {
                return NotFound(new ApiResponse("Insertpregunta not found.", null, 404));
            }
        }


        [HttpPost("preguntaRespuesta")]
        [Consumes(MediaTypeNames.Application.Json)]
        [ProducesResponseType(StatusCodes.Status201Created)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        [Authorize]
        public IActionResult InsertRespPregunta(inputRespuestaModels Dta)
        {
            var response = _service.InsertRespPregunta(Dta);

            if (response != null)
            {
                return Ok(new ApiResponse("InsertRespPregunta found.", response, 200));
            }
            else
            {
                return NotFound(new ApiResponse("InsertRespPregunta not found.", null, 404));
            }
        }

        [HttpDelete("preguntaRespuesta")]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        [Authorize]
        public IActionResult DeleteRespPregunta(Guid Id)
        {
            var response = _service.DeleteRespPregunta(Id);

            if (response != null)
            {
                return Ok(new ApiResponse("DeleteRespPregunta found.", response, 200));
            }
            else
            {
                return NotFound(new ApiResponse("DeleteRespPregunta not found.", null, 404));
            }

        }

        [HttpPut("preguntaRespuesta")]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        [Authorize]
        public IActionResult UpdateRespPregunta(InputUpdRespuestaModels Dta)
        {
            var response = _service.UpdateRespPregunta(Dta);

            if (response != null)
            {
                return Ok(new ApiResponse("DeleteRespPregunta found.", response, 200));
            }
            else
            {
                return NotFound(new ApiResponse("DeleteRespPregunta not found.", null, 404));
            }

        }

        [HttpGet("Comentariorespuesta/listado/{Id}")]
        public async Task<IActionResult> GetComentarioRespuesta([FromQuery] Paginator paginator, Guid Id)
        {
            var response = await _service.GetComentarioRespuesta(paginator, Id);
            if (response != null)
            {
                return Ok(new ApiResponse("Comentariorespuesta/listado found.", response, 200));
            }
            else
            {
                return NotFound(new ApiResponse("Comentariorespuesta/listado not found.", null, 404));
            }
        }
        [HttpPost("Comentariorespuesta")]
        [Consumes(MediaTypeNames.Application.Json)]
        [ProducesResponseType(StatusCodes.Status201Created)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        [Authorize]
        public IActionResult InsertComentarRespuesta(InputComRespModels Dta)
        {
            var response = _service.InsertComentarRespuesta(Dta);

            if (response != null)
            {
                return Ok(new ApiResponse("Comentariorespuesta found.", response, 200));
            }
            else
            {
                return NotFound(new ApiResponse("Comentariorespuesta not found.", null, 404));
            }
        }
        [HttpPost("RespuestaLikeDislike")]
        [Consumes(MediaTypeNames.Application.Json)]
        [ProducesResponseType(StatusCodes.Status201Created)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        [Authorize]
        public IActionResult RespuestaLikeDislike(InputLikeDislikeModels Dta)
        {
            var response = _service.RespuestaLikeDislike(Dta);

            if (response != null)
            {
                if(response.Message == null)
                {
                    response.Message = "No fue posible insertar el like o dislike";
                }
                return Ok(new ApiResponse("RespuestaLikeDislike found.", response, 200));
            }
            else
            {
                return NotFound(new ApiResponse("RespuestaLikeDislike not found.", null, 404));
            }
        }

        #endregion
        #region Retos
        #region Reto
        [HttpGet("reto/listado")]
        [Authorize]
        public async Task<IActionResult> RetoList([FromQuery] Paginator paginator)
        {
            var response = await _service.GetListaRetos(paginator);
            if (response != null)
            {
                return Ok(new ApiResponse("RetoList found.", response, 200));
            }
            else
            {
                return NotFound(new ApiResponse("RetoList not found.", null, 404));
            }
        }

        [HttpPost("reto")]
        [Consumes(MediaTypeNames.Application.Json)]
        [ProducesResponseType(StatusCodes.Status201Created)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        [Authorize]
        public IActionResult Insertreto(RetoModels Dta)
        {
            var response = _service.Insertreto(Dta);

            if (response != null)
            {
                return Ok(new ApiResponse("RetoList found.", response, 200));
            }
            else
            {
                return NotFound(new ApiResponse("RetoList not found.", null, 404));
            }
        }

        [HttpGet("reto/listado-extendido")]
        public async Task<IActionResult> RetoExList(Guid Id)
        {

            var response = await _service.GetRetoExById(Id);
            if (response != null)
            {
                return Ok(new ApiResponse("RetoExtendidoList found.", response, 200));
            }
            else
            {
                return NotFound(new ApiResponse("RetoExtendidoList not found.", null, 404));
            }
        }
        [HttpGet("reto/reto-extendido/{RetoId}")]
        public async Task<IActionResult> GetRetoExById(Guid RetoId)
        {
            var response = await _service.GetRetoExById(RetoId);
            if (response != null)
            {
                return Ok(new ApiResponse("Reto Found.", response, 200));
            }
            else
            {
                return NotFound(new ApiResponse("Reto was not found.", null, 404));
            }
        }
        [HttpPost("reto/reto-completo")]
        [Consumes(MediaTypeNames.Application.Json)]
        [ProducesResponseType(StatusCodes.Status201Created)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        [Authorize]
        public IActionResult InsertRetoCompleto(InputRetoModels Dta)
        {
            var response = _service.InsertRetoCompleto(Dta);

            if (response != null)
            {
                return Ok(new ApiResponse("RetoList found.", response, 200));
            }
            else
            {
                return NotFound(new ApiResponse("RetoList not found.", null, 404));
            }
        }
        [HttpPut("reto/update/reto-completo")]
        [Consumes(MediaTypeNames.Application.Json)]
        [ProducesResponseType(StatusCodes.Status201Created)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        [Authorize]
        public IActionResult UpdateRetoCompleto(InputUpdRetoModels Dta)
        {
            var response = _service.UpdateRetoCompleto(Dta);

            if (response != null)
            {
                return Ok(new ApiResponse("RetoList update.", response, 200));
            }
            else
            {
                return NotFound(new ApiResponse("RetoList not update.", null, 404));
            }
        }
        #endregion
        #region Participantes
        [HttpGet("participante/listado")]
        public async Task<IActionResult> ParticipanteList([FromQuery] Paginator paginator)
        {

            var response = await _service.GetListaParticipantes(paginator);
            if (response != null)
            {
                return Ok(new ApiResponse("ParticipanteList found.", response, 200));
            }
            else
            {
                return NotFound(new ApiResponse("ParticipanteList not found.", null, 404));
            }
        }

        [HttpPost("participante")]
        [Consumes(MediaTypeNames.Application.Json)]
        [ProducesResponseType(StatusCodes.Status201Created)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        public IActionResult Insertparticipante(ParticipanteModels Dta)
        {
            var response = _service.Insertparticipante(Dta);

            if (response != null)
            {
                return Ok(new ApiResponse("ParticipanteList found.", response, 200));
            }
            else
            {
                return NotFound(new ApiResponse("ParticipanteList not found.", null, 404));
            }
        }
        #endregion
        #region Temas
        [HttpGet("tema/listado")]
        public async Task<IActionResult> TemaList([FromQuery] Paginator paginator)
        {

            var response = await _service.GetListaTemas(paginator);
            if (response != null)
            {
                return Ok(new ApiResponse("TemaList found.", response, 200));
            }
            else
            {
                return NotFound(new ApiResponse("TemaList not found.", null, 404));
            }
        }

        [HttpPost("tema")]
        [Consumes(MediaTypeNames.Application.Json)]
        [ProducesResponseType(StatusCodes.Status201Created)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        public IActionResult Inserttema(TemaModels Dta)
        {
            var response = _service.Inserttema(Dta);

            if (response != null)
            {
                return Ok(new ApiResponse("TemaList found.", response, 200));
            }
            else
            {
                return NotFound(new ApiResponse("TemaList not found.", null, 404));
            }
        }
        #endregion
        #region Incentivo Retos
        [HttpGet("incentivo-reto/listado")]
        public async Task<IActionResult> IncentivoRetoList([FromQuery] Paginator paginator)
        {

            var response = await _service.GetListaIncentivoRetos(paginator);
            if (response != null)
            {
                return Ok(new ApiResponse("IncentivoRetoList found.", response, 200));
            }
            else
            {
                return NotFound(new ApiResponse("IncentivoRetoList not found.", null, 404));
            }
        }

        [HttpPost("incentivo-reto")]
        [Consumes(MediaTypeNames.Application.Json)]
        [ProducesResponseType(StatusCodes.Status201Created)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        public async Task<IActionResult> IncentivoRetoInsert(IncentivoRetoModels Dta)
        {
            var response = await _service.IncentivoRetoInsert(Dta);

            if (response.IsSuccess)
            {
                return Ok(new ApiResponse("IncentivoRetoList found.", response, 200));
            }
            else
            {
                return NotFound(new ApiResponse("IncentivoRetoList not found.", null, 404));
            }
        }
        #endregion
        #region Documento Retos
        [HttpGet("documento-reto/listado")]
        public async Task<IActionResult> DocumentoRetoList([FromQuery] Paginator paginator)
        {

            var response = await _service.GetListaDocumentoRetos(paginator);
            if (response != null)
            {
                return Ok(new ApiResponse("DocumentoRetoList found.", response, 200));
            }
            else
            {
                return NotFound(new ApiResponse("DocumentoRetoList not found.", null, 404));
            }
        }

        [HttpPost("documento-reto")]
        [Consumes(MediaTypeNames.Application.Json)]
        [ProducesResponseType(StatusCodes.Status201Created)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        public async Task<IActionResult> DocumentoRetoInsert(DocumentoRetoModels Dta)
        {
            var response = await _service.DocumentoRetoInsert(Dta);

            if (response.IsSuccess)
            {
                return Ok(new ApiResponse("DocumentoRetoList found.", response, 200));
            }
            else
            {
                return NotFound(new ApiResponse("DocumentoRetoList not found.", null, 404));
            }
        }
        #endregion
        #region Etapa Retos
        [HttpGet("etapa-reto/listado")]
        public async Task<IActionResult> EtapaRetoList([FromQuery] Paginator paginator)
        {

            var response = await _service.EtapaRetosListaGet(paginator);
            if (response != null)
            {
                return Ok(new ApiResponse("EtapaRetoList found.", response, 200));
            }
            else
            {
                return NotFound(new ApiResponse("EtapaRetoList not found.", null, 404));
            }
        }

        [HttpPost("etapa-reto")]
        [Consumes(MediaTypeNames.Application.Json)]
        [ProducesResponseType(StatusCodes.Status201Created)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        public async Task<IActionResult> EtapaRetoInsert(EtapaRetoModels Dta)
        {
            var response = await _service.EtapaRetoInsert(Dta);

            if (response.IsSuccess)
            {
                return Ok(new ApiResponse("EtapaRetoList found.", response, 200));
            }
            else
            {
                return NotFound(new ApiResponse("EtapaRetoList not found.", null, 404));
            }
        }
        #endregion
        #region Entidad Reto
        [HttpGet("entidad-reto/listado")]
        public async Task<IActionResult> EntidadRetoList([FromQuery] Paginator paginator)
        {

            var response = await _service.EntidadRetosListaGet(paginator);
            if (response != null)
            {
                return Ok(new ApiResponse("EntidadRetoList found.", response, 200));
            }
            else
            {
                return NotFound(new ApiResponse("EntidadRetoList not found.", null, 404));
            }
        }

        [HttpPost("entidad-reto")]
        [Consumes(MediaTypeNames.Application.Json)]
        [ProducesResponseType(StatusCodes.Status201Created)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        public async Task<IActionResult> EntidadRetoInsert(EntidadRetoModels Dta)
        {
            var response = await _service.EntidadRetoInsert(Dta);

            if (response.IsSuccess)
            {
                return Ok(new ApiResponse("EntidadRetoList found.", response, 200));
            }
            else
            {
                return NotFound(new ApiResponse("EntidadRetoList not found.", response.Message, 400));
            }
        }
        #endregion
        #endregion
    }

}