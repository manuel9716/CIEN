
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Net.Mime;
using System.Threading;
using System.Threading.Tasks;
using AutoMapper;
using AutoWrapper.Wrappers;
using Community.Dtos.Files.Models;
using Community.Dtos.Pagination.Models;
using Community.Dtos.Pagination.Services;
using Community.Services.Files;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace Community.Controllers.Files
{
    [ApiController]
    [Route("/api/community/v1/files")]
    public class FilesController : ControllerBase
    {

        private readonly IFilesService _service;
        private readonly IUriService _uriService;
        private readonly IMapper _mapper;

        public FilesController(IFilesService fileService, IUriService uriService)
        {
            _service = fileService;
            _uriService = uriService;
        }

        [HttpPost("multiple/updload")]
        [Authorize]
        public IActionResult MultipleUpload([Required] List<IFormFile> formFiles, CancellationToken cancellationToken)
        {
            try
            {
                List<ReadFile> result = _service.UploadMultipleFiles(formFiles);

                return Ok(new ApiResponse("Files uploaded.", result, 201));
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }

        [HttpPost("single/updload")]
        [Authorize]
        public IActionResult SingleUpload([Required] IFormFile formFile, CancellationToken cancellationToken)
        {
            try
            {
                ReadFile result = _service.UploadSingleFile(formFile);

                return Ok(new ApiResponse("File uploaded.", result, 201));
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }

        [HttpGet("multiple/download")]
        //[Authorize(Roles = "FILES_DOWNLOAD")]
        public IActionResult MultipleDownload([Required] List<ReadFile> filesToDownload)
        {

            try
            {
                var (fileType, archiveData, archiveName) = _service.DownloadFiles(filesToDownload);

                return File(archiveData, fileType, archiveName);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }

        }

        [HttpGet("download/{fileId}")]
        //[Authorize(Roles = "FILES_DOWNLOAD")]
        public IActionResult Download([Required] [FromRoute] Guid fileId)
        {
            try
            {
                var (fileType, archiveData, archiveName) = _service.DownloadFile(fileId);

                return File(archiveData, fileType, archiveName);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }

        [HttpGet("{id}")]

        public IActionResult Read(Guid id)
        {
            ReadFile response = _service.Read(id);

            if (response != null)
            {
                return Ok(new ApiResponse("File found.", response, 200));
            }
            else
            {
                return NotFound(new ApiResponse("File not found.", null, 404));
            }
        }


        [HttpGet()]
        [Consumes(MediaTypeNames.Application.Json)]
        [ProducesResponseType(StatusCodes.Status201Created)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        //[Authorize(Roles = "USERS_MENU_SEARCH")]

        public IActionResult Search([FromQuery] Paginator paginator, [FromQuery] Sorter sorter, [FromQuery] SearchFile searchRequest)
        {
            string route = Request.Path.Value;
            Paged<ReadFile> response = _service.Search(paginator, sorter, searchRequest, _uriService, route);
            return Ok(new ApiResponse("Query done!", response, 200));
        }

    }
}