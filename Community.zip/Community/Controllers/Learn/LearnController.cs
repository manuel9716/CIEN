using Application.Clients.Keycloak.Services.Users;
using AutoWrapper.Wrappers;
using Community.Dtos.AppUsers.Models;
using Community.Dtos.Learn.Models;
using Community.Dtos.ListasItem.Models;
using Community.Dtos.Pagination.Models;
using Community.Services.AppUsers;
using Community.Services.Learn;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Net.Mime;
using System.Threading;
using System.Threading.Tasks;

namespace Community.Controllers.Learn
{
    [ApiController]
    [Route("/api/community/v1/Aprende")]
    public class LearnController : Controller
    {
        private readonly IActorService _actorService;
        private readonly IAppUsersService _userService;
        private readonly ILearnService _service;

        public LearnController(IActorService actorService, IAppUsersService userService, ILearnService service)
        {
            _actorService = actorService;
            _userService = userService;
            _service = service;
        }
         [HttpGet("ofertas")]
        public async Task<IActionResult> Get([FromQuery] Paginator paginator, [FromQuery] string nombre,[FromQuery] List<Guid> tema, [FromQuery] List<Guid> tipo, [FromQuery] List<Guid> modalidad, [FromQuery] List<Guid> dirigidoA)
        {

            List<ReadOfertas> response = await _service.GetOfertas(paginator, nombre,tema,tipo,modalidad,dirigidoA);

            if (response != null)
            {
                return Ok(new ApiResponse("oferta found.", response, 200));
            }
            else
            {
                return NotFound(new ApiResponse("oferta not found.", null, 404));
            }
        }
        
        [HttpGet("oferta")]
        public async Task<IActionResult> Get(Guid Id)
        {

            ReadOfertas response = await _service.GetOferta(Id);

            if (response != null)
            {
                return Ok(new ApiResponse("oferta found.", response, 200));
            }
            else
            {
                return NotFound(new ApiResponse("oferta not found.", null, 404));
            }
        }
        [HttpPost("CrearOferta")]
        [Consumes(MediaTypeNames.Application.Json)]
        [ProducesResponseType(StatusCodes.Status201Created)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        //[Authorize(Roles = "CIEN_COMMUNITY_APPUSER_ACTUALIZAR, CIEN_COMMUNITY_SUPER_ADMINISTRADOR")]
        public async Task<IActionResult> Create([FromBody] CreateOferta createRequest, CancellationToken cancellationToken)
        {
            var countdirigidoa = 0;
            var counttema = 0;

            createRequest.AppUserId = _actorService.GetActor();

            //ReadAppUser responseuser = await _userService.Read(createRequest.AppUserId, cancellationToken);
            ReadAppUser responseuser = await _userService.Read(createRequest.AppUserId, cancellationToken);
            if (responseuser == null)
            {
                return NotFound(new ApiResponse("No existe Usuario con ese Id", responseuser, 404));
            }

            //validar si es un item de tipo aprende

            ReadListaItem resppadreidtipo = await _service.ReadListaItemPadre("TIPO APRENDE", cancellationToken);

            ReadListaItem resulttipo = await _service.ReadListaItem(createRequest.TipoId, resppadreidtipo.Id, cancellationToken);

            if(resulttipo == null)
            {
                return NotFound(new ApiResponse("el id del tipo no existe", "el id de tipo no existe", 404));
            }

            //validar si es un item de tiempo de aprende
            ReadListaItem resppadreidtiempo = await _service.ReadListaItemPadre("TIEMPO APRENDE", cancellationToken);
            ReadListaItem resulttiempo = await _service.ReadListaItem(createRequest.TiempoId, resppadreidtiempo.Id, cancellationToken);

            if (resulttiempo == null)
            {
                return NotFound(new ApiResponse("el id del tiempo no existe", "el id del tiempo no existe", 404));
            }

            //validar si es un item de modalidad aprende
            ReadListaItem resppadreidmodalidad = await _service.ReadListaItemPadre("MODALIDAD APRENDE", cancellationToken);

            ReadListaItem resultmodalidad = await _service.ReadListaItem(createRequest.ModalidadId, resppadreidmodalidad.Id, cancellationToken);

            if (resultmodalidad == null)
            {
                return NotFound(new ApiResponse("el id de la modalidad no existe", "el id de la modalidad no existe", 404));
            }


            if (createRequest.DirigidosA.Count == 0)
            {
                return NotFound(new ApiResponse("Se debe tener por lo menos un dirigido A", "Se debe tener por lo menos un dirigido A", 404));
            }
            else
            {

                //validar si es un item de dirigido a de aprende
                ReadListaItem resppadreiddirigidoa = await _service.ReadListaItemPadre("DIRIGIDO A APRENDE", cancellationToken);
                foreach (var item in createRequest.DirigidosA)
                {
                    
                    ReadListaItem resultdirigidoa = await _service.ReadListaItem(item, resppadreiddirigidoa.Id, cancellationToken);

                    if (resultdirigidoa == null)
                    {
                        countdirigidoa++;
                    }
                }

                if(countdirigidoa > 0)
                {
                    return NotFound(new ApiResponse("hay " + countdirigidoa+ " id de dirigidos que no existen", "hay " + countdirigidoa + " id de dirigidos que no existen", 404));
                }
            }


            if (createRequest.Temas.Count == 0)
            {
                return NotFound(new ApiResponse("Se debe tener por lo menos un Tema", "Se debe tener por lo menos un Tema", 404));
            }
            else
            {

                //validar si es un item de tema de aprende
                ReadListaItem resppadreidtema = await _service.ReadListaItemPadre("TEMAS APRENDE", cancellationToken);
                foreach (var item in createRequest.Temas)
                {

                    ReadListaItem resulttema = await _service.ReadListaItem(item, resppadreidtema.Id, cancellationToken);

                    if (resulttema == null)
                    {
                        counttema++;
                    }
                }

                if (counttema > 0)
                {
                    return NotFound(new ApiResponse("hay " + counttema + " id de temas que no existen", "hay " + counttema + " id de temas que no existen", 404));
                }

            }

            ReadOferta result = await _service.CreateOferta(createRequest, cancellationToken);
            return Created("/api/community/v1/Aprende/" + result.Id, new ApiResponse("Oferta Creado exitosamente", result, 201));

            
        }
        [HttpPut("ModificarOferta")]
        [Consumes(MediaTypeNames.Application.Json)]
        [ProducesResponseType(StatusCodes.Status201Created)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        //[Authorize(Roles = "CIEN_COMMUNITY_APPUSER_ACTUALIZAR, CIEN_COMMUNITY_SUPER_ADMINISTRADOR")]

        public async Task<IActionResult> UpdateOFerta([FromBody] UpdateOferta updateRequest, CancellationToken cancellationToken)
        {
            var countdirigidoa = 0;
            var counttema = 0;

            ReadOfertas response = await _service.ReadOfertaId(updateRequest.Id);

            if (response == null)
            {
                return NotFound(new ApiResponse("No existe La Oferta con ese Id", response, 404));
            }
           
            updateRequest.AppUserId = _actorService.GetActor();

            if (updateRequest.AppUserId != response.Usuario.Id)
            {
                return NotFound(new ApiResponse("No se puede modificar porque no es el mismo usuario que creo la oferta", response, 404));
            }

            //validar si es un item de tipo aprende

            ReadListaItem resppadreidtipo = await _service.ReadListaItemPadre("TIPO APRENDE", cancellationToken);

            ReadListaItem resulttipo = await _service.ReadListaItem(updateRequest.TipoId, resppadreidtipo.Id, cancellationToken);

            if (resulttipo == null)
            {
                return NotFound(new ApiResponse("el id del tipo no existe", "el id de tipo no existe", 404));
            }

            //validar si es un item de tiempo de aprende
            ReadListaItem resppadreidtiempo = await _service.ReadListaItemPadre("TIEMPO APRENDE", cancellationToken);
            ReadListaItem resulttiempo = await _service.ReadListaItem(updateRequest.TiempoId, resppadreidtiempo.Id, cancellationToken);

            if (resulttiempo == null)
            {
                return NotFound(new ApiResponse("el id del tiempo no existe", "el id del tiempo no existe", 404));
            }

            //validar si es un item de modalidad aprende
            ReadListaItem resppadreidmodalidad = await _service.ReadListaItemPadre("MODALIDAD APRENDE", cancellationToken);

            ReadListaItem resultmodalidad = await _service.ReadListaItem(updateRequest.ModalidadId, resppadreidmodalidad.Id, cancellationToken);

            if (resultmodalidad == null)
            {
                return NotFound(new ApiResponse("el id de la modalidad no existe", "el id de la modalidad no existe", 404));
            }


            if (updateRequest.DirigidosA.Count == 0)
            {
                return NotFound(new ApiResponse("Se debe tener por lo menos un dirigido A", "Se debe tener por lo menos un dirigido A", 404));
            }
            else
            {

                //validar si es un item de dirigido a de aprende
                ReadListaItem resppadreiddirigidoa = await _service.ReadListaItemPadre("DIRIGIDO A APRENDE", cancellationToken);
                foreach (var item in updateRequest.DirigidosA)
                {

                    ReadListaItem resultdirigidoa = await _service.ReadListaItem(item, resppadreiddirigidoa.Id, cancellationToken);

                    if (resultdirigidoa == null)
                    {
                        countdirigidoa++;
                    }
                }

                if (countdirigidoa > 0)
                {
                    return NotFound(new ApiResponse("hay " + countdirigidoa + " id de dirigidos que no existen", "hay " + countdirigidoa + " id de dirigidos que no existen", 404));
                }
            }


            if (updateRequest.Temas.Count == 0)
            {
                return NotFound(new ApiResponse("Se debe tener por lo menos un Tema", "Se debe tener por lo menos un Tema", 404));
            }
            else
            {

                //validar si es un item de tema de aprende
                ReadListaItem resppadreidtema = await _service.ReadListaItemPadre("TEMAS APRENDE", cancellationToken);
                foreach (var item in updateRequest.Temas)
                {

                    ReadListaItem resulttema = await _service.ReadListaItem(item, resppadreidtema.Id, cancellationToken);

                    if (resulttema == null)
                    {
                        counttema++;
                    }
                }

                if (counttema > 0)
                {
                    return NotFound(new ApiResponse("hay " + counttema + " id de temas que no existen", "hay " + counttema + " id de temas que no existen", 404));
                }

            }



            ReadOferta result = await _service.UpdateOferta(updateRequest, cancellationToken);
                
            return Created("/api/community/v1/Aprende/" + result.Id, new ApiResponse("Oferta modificada Exitosamente", result, 201));

                
        }

        [HttpPut("OcultarOferta")]
        [Consumes(MediaTypeNames.Application.Json)]
        [ProducesResponseType(StatusCodes.Status201Created)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        //[Authorize(Roles = "CIEN_COMMUNITY_APPUSER_ACTUALIZAR, CIEN_COMMUNITY_SUPER_ADMINISTRADOR")]

        public async Task<IActionResult> OcultarOferta([FromQuery] Guid id, CancellationToken cancellationToken)
        {

            ReadOfertas response = await _service.ReadOfertaId(id);

            if (response == null)
            {
                return NotFound(new ApiResponse("No existe La Oferta con ese Id", response, 404));
            }

            ReadOferta result = await _service.OcultarOferta(id, cancellationToken);
                
            return Created("/api/community/v1/Aprende/" + result.Id, new ApiResponse("Oferta Ocultada Exitosamente", result, 201));

        }


    }
}
