using System;
using System.Net.Mime;
using System.Threading;
using System.Threading.Tasks;
using Community.Dtos.ListasItem.Models;
using Community.Dtos.Pagination.Models;
using Community.Dtos.Pagination.Services;
using Community.Services.ListasItem;
using AutoWrapper.Wrappers;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace Community.Controllers.ListasItem
{
    [ApiController]
    [Route("/api/community/v1/listas/lista")]

    public class ListaItemController : ControllerBase
    {
        private readonly IListasItemService _service;
        private readonly IUriService _uriService;

        public ListaItemController(IListasItemService service, IUriService uriService)
        {
            _service = service;
            _uriService = uriService;
        }

        [HttpPost()]
        [Consumes(MediaTypeNames.Application.Json)]
        [ProducesResponseType(StatusCodes.Status201Created)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        [Authorize(Roles = "CIEN_COMMUNITY_LISTA_CREAR, CIEN_COMMUNITY_SUPER_ADMINISTRADOR")]
        public async Task<IActionResult> Create([FromBody] CreateListaItem createRequest, CancellationToken cancellationToken)
        {

            ReadListaItem result = await _service.Create(createRequest, cancellationToken);
            return Created("/api/application/v1/listas/lista/" + result.Id, new ApiResponse("ListaItem created.", result, 201));
        }

        [HttpGet("{id}")]
        [Authorize(Roles = "CIEN_COMMUNITY_LISTA_VER, CIEN_COMMUNITY_SUPER_ADMINISTRADOR")]

        public async Task<IActionResult> Read(Guid id, CancellationToken cancellationToken)
        {
            ReadListaItem response = await _service.Read(id, cancellationToken);

            if (response != null)
            {
                return Ok(new ApiResponse("ListaItem found.", response, 200));
            }
            else
            {
                return NotFound(new ApiResponse("ListaItem not found.", null, 404));
            }
        }

        [HttpPut("{id}")]
        [Consumes(MediaTypeNames.Application.Json)]
        [ProducesResponseType(StatusCodes.Status201Created)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        [Authorize(Roles = "CIEN_COMMUNITY_LISTA_ACTUALIZAR, CIEN_COMMUNITY_SUPER_ADMINISTRADOR")]

        public async Task<IActionResult> Update(Guid id, [FromBody] UpdateListaItem updateRequest, CancellationToken cancellationToken)
        {
            ReadListaItem response = await _service.Read(id, cancellationToken);

            if (response == null)
            {
                return NotFound(new ApiResponse("ListaItem found.", response, 404));
            }
            else
            {
                if (updateRequest.Id != id)
                {
                    return BadRequest(new ApiResponse("ListaItem Id and id doesn't match", response, 404));
                }

                response = await _service.Update(updateRequest, cancellationToken);
                return Ok(new ApiResponse("ListaItem updated.", response, 200));
            }
        }

        [HttpDelete("{id}")]
        [Authorize(Roles = "CIEN_COMMUNITY_LISTA_ELIMINAR, CIEN_COMMUNITY_SUPER_ADMINISTRADOR")]

        public async Task<ApiResponse> Delete(Guid id, CancellationToken cancellationToken)
        {
            await _service.Delete(id, cancellationToken);
            return new ApiResponse("ListaItem deleted.", null, 204);
        }

        [HttpGet()]
        [Consumes(MediaTypeNames.Application.Json)]
        [ProducesResponseType(StatusCodes.Status201Created)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        [Authorize(Roles = "CIEN_COMMUNITY_LISTA_BUSCAR, CIEN_COMMUNITY_SUPER_ADMINISTRADOR")]

        public async Task<IActionResult> Search([FromQuery] Paginator paginator, [FromQuery] Sorter sorter, [FromQuery] SearchListaItem searchRequest, CancellationToken cancellationToken)
        {
            string route = Request.Path.Value;

            Paged<ReadListaItem> response = await _service.Search(paginator, sorter, searchRequest, _uriService, route, cancellationToken);
            return Ok(new ApiResponse("Query done!", response, 200));
        }

    }
}
