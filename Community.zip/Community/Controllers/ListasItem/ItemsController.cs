using System;
using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;
using Community.Dtos.ListasItem.Models;
using Community.Dtos.Pagination.Services;
using Community.Services.ListasItem;
using AutoWrapper.Wrappers;
using Microsoft.AspNetCore.Mvc;

namespace Community.Controllers.ListasItem
{
    [ApiController]
    [Route("/api/community/v1/listas/items")]
    public class ItemsController : ControllerBase
    {
        private readonly IListasItemService _service;
        private readonly IUriService _uriService;

        public ItemsController(IListasItemService service, IUriService uriService)
        {
            _service = service;
            _uriService = uriService;
        }

        [HttpGet("codigo-padre/{codigoPadre}")]
        public async Task<IActionResult> Get(String codigoPadre, CancellationToken cancellationToken)
        {
            List<ReadListaItem> response = await _service.GetItemsByCodigoPadre(codigoPadre, cancellationToken);

            if (response != null)
            {
                return Ok(new ApiResponse("items found.", response, 200));
            }
            else
            {
                return NotFound(new ApiResponse("items not found.", null, 404));
            }
        }

        [HttpGet("codigo-pregunta/{codigoPregunta}")]
        public async Task<IActionResult> GetRespuestasEtiqueta(String codigoPregunta, CancellationToken cancellationToken)
        {
            List<ReadListaItemRespuestaEtiqueta> response = await _service.GetItemsByCodigoPregunta(codigoPregunta, cancellationToken);

            if (response != null)
            {
                return Ok(new ApiResponse("items found.", response, 200));
            }
            else
            {
                return NotFound(new ApiResponse("items not found.", null, 404));
            }
        }

        [HttpGet("padre-id/{id}")]
        public async Task<IActionResult> Get(Guid padreId, CancellationToken cancellationToken)
        {
            List<ReadListaItem> response = await _service.GetItemsByPadreId(padreId, cancellationToken);

            if (response != null)
            {
                return Ok(new ApiResponse("items found.", response, 200));
            }
            else
            {
                return NotFound(new ApiResponse("items not found.", null, 404));
            }
        }
        [HttpGet("by-id/{id}")]
        public async Task<IActionResult> GetById(Guid id, CancellationToken cancellationToken)
        {
            ReadListaItem response = await _service.Read(id, cancellationToken);

            if (response != null)
            {
                return Ok(new ApiResponse("ListaItem found.", response, 200));
            }
            else
            {
                return NotFound(new ApiResponse("ListaItem not found.", null, 404));
            }
        }

    }
}
