using Application.Clients.Keycloak.Services.Users;
using AutoWrapper.Wrappers;
using Community.Dtos.AppUsers.Models;
using Community.Dtos.Messages.Models;
using Community.Dtos.Pagination.Models;
using Community.Services.AppUsers;
using Community.Services.Messages;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Net.Mime;
using System.Threading;
using System.Threading.Tasks;

namespace Community.Controllers.Message
{
    [ApiController]
    [Route("/api/community/v1/Mensaje")]
    public class MessageController : ControllerBase
    {
        private readonly IMessageService _service;
        private readonly IActorService _actorService;
        private readonly IAppUsersService _userService;
        public MessageController(IMessageService service, IActorService actorService, IAppUsersService userService)
        {
            _service = service;
            _actorService = actorService;
            _userService = userService;
        }

        [HttpGet("Conversaciones")]
        public async Task<IActionResult> GetConversacion()
        {

            var AppUserId = _actorService.GetActor();
            
            List<ReadConversation> response = await _service.GetConversaciones(AppUserId);

            if (response != null)
            {
                return Ok(new ApiResponse("conversation found.", response, 200));
            }
            else
            {
                return NotFound(new ApiResponse("conversation not found.", null, 404));
            }
        }

        [HttpGet("ConversacionesPorNombre")]
        public async Task<IActionResult> GetConversacionPorNombre([FromQuery] string nombre)
        {

            if(nombre == null)
            {
                return NotFound(new ApiResponse("Se debe de Ingresar el nombre","Se debe de Ingresar el nombre", 404));
            }

            var AppUserId = _actorService.GetActor();

            List<ReadConversation> response = await _service.GetConversacionesPorNombre(AppUserId,nombre);

            if (response != null)
            {
                return Ok(new ApiResponse("conversation found.", response, 200));
            }
            else
            {
                return NotFound(new ApiResponse("conversation not found.", null, 404));
            }
        }

        [HttpGet("Mensajes")]
        public async Task<IActionResult> GetMensajes([FromQuery] Guid IdConversacion,[FromQuery] Paginator paginator, CancellationToken cancellationToken)
        {

            ReadConversationUnion responseconversation = await _service.ReadConversacionId(IdConversacion,cancellationToken);

            if (responseconversation == null)
            {
                return NotFound(new ApiResponse("No existe La conversación con ese Id", responseconversation, 404));
            }

            List<ReadMessage> response = await _service.GetMensajes(IdConversacion, paginator);

            if (response != null)
            {
                // List<ReadMessage> mensajesSinLeer = await _service.ReadMensajesSinLeer(IdConversacion);

                // var response2 = new ReadMessageFinal
                // {
                //     Mensajes = response,
                //     NroMensajesSinLeer = mensajesSinLeer.Count
                // };

                return Ok(new ApiResponse("message found.", response, 200));
            }
            else
            {
                return NotFound(new ApiResponse("message not found.", null, 404));
            }
        }

        [HttpGet("Usuarios")]
        public async Task<IActionResult> GetUsuarios([FromQuery] string nombre,CancellationToken cancellationToken)
        {
            
            List<ReadUser> response = await _service.GetUsuarios(nombre,cancellationToken);

            if (response != null)
            {
                return Ok(new ApiResponse("Usuarios found.", response, 200));
            }
            else
            {
                return NotFound(new ApiResponse("Usuarios not found.", null, 404));
            }
        }

        [HttpGet("MensajesSinLeer")]
        public async Task<IActionResult> GetMensajesSinLeer()
        {
            var AppUserId = _actorService.GetActor();

            ReadMensajesSinLeerUsuario response = await _service.ReadMensajesSinLeerUsuario(AppUserId);

            if (response != null)
            {
                return Ok(new ApiResponse("Mensajes sin leer found.", response, 200));
            }
            else
            {
                return NotFound(new ApiResponse("Mensajes sin leer not found.", null, 404));
            }
        }

        [HttpPost("CrearConversacion")]
        [Consumes(MediaTypeNames.Application.Json)]
        [ProducesResponseType(StatusCodes.Status201Created)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        //[Authorize(Roles = "CIEN_COMMUNITY_APPUSER_ACTUALIZAR, CIEN_COMMUNITY_SUPER_ADMINISTRADOR")]
        public async Task<IActionResult> CreateConversation([FromBody] CreateConversation createRequest, CancellationToken cancellationToken)
        {

            createRequest.UserSenderId = _actorService.GetActor();
        
            ReadAppUser responseUserSender = await _userService.Read(createRequest.UserSenderId, cancellationToken);
            if (responseUserSender == null)
            {
                return NotFound(new ApiResponse("No existe un Usuario Sender con ese Id", responseUserSender, 404));
            }

            ReadAppUser responseUserReceptor = await _userService.Read(createRequest.UserReceptorId, cancellationToken);
            if (responseUserReceptor == null)
            {
                return NotFound(new ApiResponse("No existe un Usuario Receptor con ese Id", responseUserReceptor, 404));
            }

            //verificar si el senderid es igual al receptorid
            if(createRequest.UserSenderId == createRequest.UserReceptorId)
            {
                return NotFound(new ApiResponse("El id del usuario receptor no puede ser igual al usuario sender", responseUserReceptor, 404));
            }

            ReadConversation responseconversation = await _service.ReadConversacionReceptor(createRequest.UserSenderId,createRequest.UserReceptorId, cancellationToken);

            if (responseconversation != null)
            {
                return NotFound(new ApiResponse("Ya existe una conversacion con ese usuario receptor", responseconversation, 404));
            }

            var tempsender = createRequest.UserSenderId;
            var tempreceptor = createRequest.UserReceptorId;

            //crear la conversacion del receptor
            createRequest.UserSenderId = tempreceptor;
            createRequest.UserReceptorId = tempsender;

            ReadConversation resultreceptor = await _service.CreateConversacion(createRequest, cancellationToken);

            //crear la conversacion del sender
            createRequest.UserSenderId = tempsender;
            createRequest.UserReceptorId = tempreceptor;

            ReadConversation resultsender = await _service.CreateConversacion(createRequest, cancellationToken);

            //crear la union de las conversaciones
            var createrequestunion = new CreateConversationUnion
            {
                IdSender = resultsender.Id,
                IdReceptor = resultreceptor.Id
            };
          
            ReadConversationUnion resultadounion = await _service.CreateConversacionUnion(createrequestunion, cancellationToken);

            resultsender.Id = resultadounion.Id;

            return Created("/api/community/v1/Mensaje/" + resultsender.Id, new ApiResponse("Conversación Creada exitosamente", resultsender, 201));

        }

        [HttpPost("CrearMensaje")]
        [Consumes(MediaTypeNames.Application.Json)]
        [ProducesResponseType(StatusCodes.Status201Created)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        //[Authorize(Roles = "CIEN_COMMUNITY_APPUSER_ACTUALIZAR, CIEN_COMMUNITY_SUPER_ADMINISTRADOR")]
        public async Task<IActionResult> CreateMensaje([FromBody] CreateMessage createRequest, CancellationToken cancellationToken)
        {

            createRequest.AppUserId = _actorService.GetActor();
            
            ReadAppUser responseUserSender = await _userService.Read(createRequest.AppUserId, cancellationToken);
            if (responseUserSender == null)
            {
                return NotFound(new ApiResponse("No existe un Usuario con ese Id", responseUserSender, 404));
            }

            ReadConversationUnion responseconversation = await _service.ReadConversacionId(createRequest.ConversacionId, cancellationToken);
            if (responseconversation == null)
            {
                return NotFound(new ApiResponse("No existe La conversación con ese Id", responseconversation, 404));
            }


            ReadMessage result = await _service.CreateMessage(createRequest, cancellationToken);
            return Created("/api/community/v1/Mensaje/" + result.Id, new ApiResponse("Mensaje Creada exitosamente", result, 201));

        }

    }
}
