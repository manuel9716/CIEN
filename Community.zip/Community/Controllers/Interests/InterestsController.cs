﻿using System;
using System.Net.Mime;
using System.Threading;
using System.Threading.Tasks;
using AutoWrapper.Wrappers;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Community.Dtos.Pagination.Models;
using Community.Dtos.Pagination.Services;
using Community.Dtos.Interests.Models;
using Community.Services.Interests;
using System.Collections.Generic;

namespace Community.Controllers.Interests
{
    [ApiController]
    [Route("/api/community/v1/interests")]
    public class InterestsController : ControllerBase
    {
        private readonly IInterestsService _service;
        private readonly IUriService _uriService;

        public InterestsController(IInterestsService service, IUriService uriService)
        {
            _service = service;
            _uriService = uriService;
        }

        [HttpGet("{user_id}")]
        public async Task<IActionResult> GetbyUserId(Guid user_id, CancellationToken cancellationToken)
        {
            List<ReadInterests> response = await _service.GetbyUserId(user_id, cancellationToken);

            if (response != null)
            {
                return Ok(new ApiResponse("interests found.", response, 200));
            }
            else
            {
                return NotFound(new ApiResponse("interests not found.", null, 404));
            }
        }

        [HttpGet("{user_id}/{interest}")]
        public async Task<IActionResult> GetInterestsbyUserId(Guid interest, CancellationToken cancellationToken)
        {
            List<ReadInterestsUserId> response = await _service.GetInterestsbyUserId(interest, cancellationToken);

            if (response != null)
            {
                return Ok(new ApiResponse("interests found.", response, 200));
            }
            else
            {
                return NotFound(new ApiResponse("interests not found.", null, 404));
            }
        }
    }
}
