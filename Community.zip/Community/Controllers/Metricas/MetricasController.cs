﻿using Application.Clients.Keycloak.Services.Users;
using AutoWrapper.Wrappers;
using Community.Dtos.Pagination.Models;
using Community.Dtos.Pagination.Services;
using Community.Services.Cocrea;
using Microsoft.AspNetCore.Mvc;
using System.Threading.Tasks;
using System.Threading;
using Community.Services.Metricas;
using Community.Dtos.Metricas.InputModels;

namespace Community.Controllers.Metricas
{

    [ApiController]
    [Route("/api/community/v1/Metricas")]

    public class MetricasController : ControllerBase
    {
        private readonly IMetricasServices _service;

        public MetricasController(IMetricasServices service)
        {
            _service = service;
        }


          [HttpPost("InsertLoginUser")]
        public IActionResult Getherramitas(InputLoginUsersModels Dta)
        {
            var response = _service.InsertLoginUser(Dta);
            if (response != null)
            {
                return Ok(new ApiResponse("PreguntaList found.", response, 200));
            }
            else
            {
                return NotFound(new ApiResponse("PreguntaList not found.", null, 404));
            }
        }
        [HttpPost("InsertVisitaPagina")]
        public IActionResult InsertVisitaModuloprueba(inputModuloPruebaModels Dta)
        {
            var response = _service.InsertVisitaModuloprueba(Dta);
            if (response != null)
            {
                return Ok(new ApiResponse("PreguntaList found.", response, 200));
            }
            else
            {
                return NotFound(new ApiResponse("PreguntaList not found.", null, 404));
            }
        }
    }
}
