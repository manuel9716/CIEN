using Application.Clients.Keycloak.Services.Users;
using AutoWrapper.Wrappers;
using Community.Dtos.AppUsers.Models;
using Community.Dtos.ListasItem.Models;
using Community.Dtos.Pagination.Models;
using Community.Dtos.Publications;
using Community.Dtos.Publications.Models;
using Community.Services.Publications;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Net.Mime;
using System.Threading;
using System.Threading.Tasks;

namespace Community.Controllers.Publication
{
    [ApiController]
    [Route("/api/community/v1/Publicacion")]
    public class PublicationController: ControllerBase
    {
        private readonly IPublicationService _service;
        private readonly IActorService _actorService;
        public PublicationController(IPublicationService service,IActorService actorService)
        {
            _service = service;
            _actorService = actorService;
        }

        [HttpGet("publicaciones")]
        public async Task<IActionResult> Get([FromQuery] Paginator paginator,CancellationToken cancellationToken)
        {
            try
            {

                var AppUserId = _actorService.GetActor();

                List<ReadPublication> response = await _service.GetPublicaciones(AppUserId, paginator);

                if (response != null)
                {
                    return Ok(new ApiResponse("publication found.", response, 200));
                }
                else
                {
                    return NotFound(new ApiResponse("publication not found.", null, 404));
                }
            }
            catch (Exception Ex)
            {
                return NotFound(new ApiResponse(Ex.Message + Ex.InnerException + Ex.StackTrace , null, 404));

            }
        }
        
        [HttpGet("publicacion")]
        public async Task<IActionResult> Get([FromQuery] Guid id)
        {
           
            List<ReadPublicationId> response = await _service.GetPublicacionId(id);

            if (response != null)
            {
                return Ok(new ApiResponse("publication found.", response, 200));
            }
            else
            {
                return NotFound(new ApiResponse("publication not found.", null, 404));
            }
        }

        [HttpGet("publicacionUsuario")]
        public async Task<IActionResult> GetPublicacion([FromQuery] Paginator paginator,CancellationToken cancellationToken)
        {

            var AppUserId = _actorService.GetActor();

            List<ReadPublication> response = await _service.GetPublicacionUser(AppUserId,paginator);

            if (response != null)
            {
                return Ok(new ApiResponse("publication found.", response, 200));
            }
            else
            {
                return NotFound(new ApiResponse("publication not found.", null, 404));
            }
        }

        [HttpGet("publicacionId")]
        public async Task<IActionResult> GetPublicacionId([FromQuery] Guid id, [FromQuery] Paginator paginator,CancellationToken cancellationToken)
        {

            ReadAppUser responseuser = await _service.ReadUser(id, cancellationToken);
            if (responseuser == null)
            {
                return NotFound(new ApiResponse("No existe Usuario con ese Id", responseuser, 404));
            }

            List<ReadPublication> response = await _service.GetPublicacionPorId(id,paginator);

            if (response != null)
            {
                return Ok(new ApiResponse("publication found.", response, 200));
            }
            else
            {
                return NotFound(new ApiResponse("publication not found.", null, 404));
            }
        }


        [HttpGet("comentarios")]
        public async Task<IActionResult> GetComentarios([FromQuery] Guid comentarioId)
        {

            List<ReadComentComent> response = await _service.GetComentarioComentario(comentarioId);

            if (response != null)
            {
                return Ok(new ApiResponse("publication found.", response, 200));
            }
            else
            {
                return NotFound(new ApiResponse("publication not found.", null, 404));
            }
        }

        [HttpGet("favoritos")]
        public async Task<IActionResult> GetFavoritos([FromQuery] Paginator paginator,CancellationToken cancellationToken)
        {

            var AppUserId = _actorService.GetActor();

            List<ReadFavorito> response = await _service.GetFavoritos(AppUserId, paginator);

            if (response != null)
            {   

                List<ReadFavorito> responsecount = await _service.GetFavorito(AppUserId);

                var response2 = new ReadFavoritoFinal()
                {
                    NroFavoritos = responsecount.Count,
                    Favoritos = response

                };
                        
                return Ok(new ApiResponse("publication found.", response2, 200));
            }
            else
            {
                return NotFound(new ApiResponse("publication not found.", null, 404));
            }
        }

        [HttpPost("CrearPublicacion")]
        [Consumes(MediaTypeNames.Application.Json)]
        [ProducesResponseType(StatusCodes.Status201Created)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        //[Authorize(Roles = "CIEN_COMMUNITY_APPUSER_ACTUALIZAR, CIEN_COMMUNITY_SUPER_ADMINISTRADOR")]
        public async Task<IActionResult> Create([FromBody] CreatePublication createRequest, CancellationToken cancellationToken)
        {

            createRequest.AppUserId = _actorService.GetActor();

            ReadAppUser responseuser = await _service.ReadUser(createRequest.AppUserId, cancellationToken);
            if (responseuser == null)
            {
                return NotFound(new ApiResponse("No existe Usuario con ese Id", responseuser, 404));
            }

            if(createRequest.CompartirId != null)
            {
                List<ReadPublication> responsecompartir = await _service.GetPublicacion(Guid.Parse(createRequest.CompartirId));

                if (responsecompartir.Count == 0)
                {
                    return NotFound(new ApiResponse("No existe el id de la publicacion de compartir", responseuser, 404));
                }

                ReadPublication respexistecompartir = await _service.ReadPublicacionCompartir(Guid.Parse(createRequest.CompartirId), createRequest.AppUserId);

                if (respexistecompartir != null)
                {
                    return NotFound(new ApiResponse("Ya ha compartido dicha publicación", responseuser, 404));
                }
            }

            ReadPublication result = await _service.Create(createRequest, cancellationToken);
            return Created("/api/community/v1/Publicacion/" + result.Id, new ApiResponse("Publicacion Creado exitosamente", result, 201));
           
        }

        [HttpPut("ModificarPublicacion")]
        [Consumes(MediaTypeNames.Application.Json)]
        [ProducesResponseType(StatusCodes.Status201Created)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        //[Authorize(Roles = "CIEN_COMMUNITY_APPUSER_ACTUALIZAR, CIEN_COMMUNITY_SUPER_ADMINISTRADOR")]

        public async Task<IActionResult> Update([FromBody] UpdatePublication updateRequest, CancellationToken cancellationToken)
        {
            // ReadPublication response = await _service.Read(updateRequest.Id, cancellationToken);

            List<ReadPublication> response = await _service.GetPublicacion(updateRequest.Id);

            if (response.Count == 0)
            {
                return NotFound(new ApiResponse("No existe La publicación con ese Id", response, 404));
            }
            else
            {

                updateRequest.AppUserId = _actorService.GetActor();

                if (updateRequest.AppUserId != response[0].Usuario.Id)
                {
                    return NotFound(new ApiResponse("No se puede modificar porque no es el mismo usuario que creo la publicación", response, 404));
                }
                else {

                    ReadPublication result = await _service.Update(updateRequest, cancellationToken);
                    result.Publicacioncomentario = response[0].Publicacioncomentario;
                    result.NroComentarios = response[0].NroComentarios;
                    result.NroFavoritos = response[0].NroFavoritos;
                    result.NroMeGusta = response[0].NroMeGusta;

                    return Created("/api/community/v1/Publicacion/" + result.Id, new ApiResponse("Publicación modificada Exitosamente", result, 201));
           
                    // response = await _service.Update(updateRequest, cancellationToken);
                    // return Ok(new ApiResponse("Publicación modificada Exitosamente", response, 200));
                }
               
            }
        }

        [HttpDelete("EliminarPublicacion")]
        [Consumes(MediaTypeNames.Application.Json)]
        [ProducesResponseType(StatusCodes.Status201Created)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        //[Authorize(Roles = "CIEN_COMMUNITY_APPUSER_ACTUALIZAR, CIEN_COMMUNITY_SUPER_ADMINISTRADOR")]
        public async Task<IActionResult> Delete([FromBody] DeletePublication deleteRequest, CancellationToken cancellationToken)
        {
            ReadPublication response = await _service.Read(deleteRequest.Id, cancellationToken);

            if (response == null)
            {
                return NotFound(new ApiResponse("No existe La publicación con ese Id", response, 404));
            }
            else
            {

                deleteRequest.AppUserId = _actorService.GetActor();

                ReadAppUser responseuser = await _service.ReadUser(deleteRequest.AppUserId, cancellationToken);
                if (responseuser == null)
                {
                    return NotFound(new ApiResponse("No existe Usuario con ese Id", response, 404));
                }


                if (deleteRequest.AppUserId != response.Usuario.Id)
                {
                    return NotFound(new ApiResponse("No se puede Eliminar porque no es el mismo usuario que creo la publicación", response, 404));
                }
                else
                {

                        response = await _service.Delete(deleteRequest, cancellationToken);
                        return Ok(new ApiResponse("Publicación Eliminada Exitosamente", response, 200));
                        
                }

            }
        }

        [HttpDelete("EliminarFavorito")]
        [Consumes(MediaTypeNames.Application.Json)]
        [ProducesResponseType(StatusCodes.Status201Created)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        //[Authorize(Roles = "CIEN_COMMUNITY_APPUSER_ACTUALIZAR, CIEN_COMMUNITY_SUPER_ADMINISTRADOR")]
        public async Task<IActionResult> DeleteFavorito([FromQuery] Guid id, CancellationToken cancellationToken)
        {
            ReadFavorito response = await _service.ReadIteracionFavorito(id, cancellationToken);

            if (response == null)
            {
                return NotFound(new ApiResponse("No existe Favorito con ese Id", response, 404));
            }
           
            await _service.DeleteIteracion(id, cancellationToken);

            var AppUserId = _actorService.GetActor();
            List<ReadFavorito> responsecount = await _service.GetFavorito(AppUserId);

            var response2 = new ReadFavoritoEliminar()
            {
                NroFavoritos = responsecount.Count,
                Favoritos = response

            };

            return Ok(new ApiResponse("Favorito Eliminado Exitosamente", response2, 200));        
              
        }

        [HttpDelete("EliminarComentario")]
        [Consumes(MediaTypeNames.Application.Json)]
        [ProducesResponseType(StatusCodes.Status201Created)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        //[Authorize(Roles = "CIEN_COMMUNITY_APPUSER_ACTUALIZAR, CIEN_COMMUNITY_SUPER_ADMINISTRADOR")]
        public async Task<IActionResult> DeleteComentario([FromQuery] Guid id, CancellationToken cancellationToken)
        {

            Guid AppUserId = _actorService.GetActor();

            ReadAppUser responseuser = await _service.ReadUser(AppUserId, cancellationToken);
            if (responseuser == null)
            {
                return NotFound(new ApiResponse("No existe Usuario con ese Id", "No existe Usuario con ese Id", 404));
            }
            ReadComment response = await _service.ReadComentario(id, cancellationToken);

            if (response == null)
            {
                return NotFound(new ApiResponse("No existe Comentario con ese Id", response, 404));
            }

            ReadComment responsecomentariouser = await _service.ReadComentarioUsuario(id,AppUserId, cancellationToken);
            if (responsecomentariouser == null)
            {
                return NotFound(new ApiResponse("No se puede eliminar el comentario porque no es de su propiedad", response, 404));
            }

            await _service.DeleteComentario(id, cancellationToken);

            return Ok(new ApiResponse("Comentario Eliminado Exitosamente", response, 200));

        }



        [HttpPost("CrearComentarioPublicacion")]
        [Consumes(MediaTypeNames.Application.Json)]
        [ProducesResponseType(StatusCodes.Status201Created)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        //[Authorize(Roles = "CIEN_COMMUNITY_LISTA_CREAR, CIEN_COMMUNITY_SUPER_ADMINISTRADOR")]
        public async Task<IActionResult> CreateComentariopublicacion([FromBody] CreateCommentPublication createRequest, CancellationToken cancellationToken)
        {
            ReadPublication response = await _service.Read(createRequest.PublicacionId, cancellationToken);

            if (response == null)
            {
                return NotFound(new ApiResponse("No existe La publicación con ese Id", response, 404));
            }
            else
            {

                createRequest.AppUserId = _actorService.GetActor();

                ReadAppUser responseuser = await _service.ReadUser(createRequest.AppUserId, cancellationToken);
                if (responseuser == null)
                {
                    return NotFound(new ApiResponse("No existe Usuario con ese Id", response, 404));
                }

                ReadComment result = await _service.CreateComentariopublicacion(createRequest, cancellationToken);
                // return Created("/api/community/v1/Publicacion/" + result.Id, new ApiResponse("Comentario de la Publicacion Creada exitosamente", result, 201));
                return Ok(new ApiResponse("Comentario de la Publicacion Creada exitosamente", result, 200));

            }

        }

        [HttpPost("CrearIteracionPublicacion")]
        [Consumes(MediaTypeNames.Application.Json)]
        [ProducesResponseType(StatusCodes.Status201Created)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        // [Authorize(Roles = "CIEN_COMMUNITY_LISTA_CREAR, CIEN_COMMUNITY_SUPER_ADMINISTRADOR")]
        public async Task<IActionResult> CrearIteracionPublicacion([FromBody] CreateIteracionPublication createRequest, CancellationToken cancellationToken)
        {

            ReadPublication responsepublication = await _service.Read(createRequest.PublicacionId, cancellationToken);

            if (responsepublication == null)
            {
                return NotFound(new ApiResponse("No existe La publicación con ese Id", responsepublication, 404));
            }

            createRequest.AppUserId = _actorService.GetActor();

            ReadAppUser responseuser = await _service.ReadUser(createRequest.AppUserId, cancellationToken);
            if (responseuser == null)
            {
                return NotFound(new ApiResponse("No existe Usuario con ese Id", responseuser, 404));
            }

            if (createRequest.TipoItem != "ITEMG" && createRequest.TipoItem != "FV")
            {
                return NotFound(new ApiResponse("El tipo de Item debe ser ó ITEMG de me gusta ó FV de favorito", 404));
            }

            //verificar el id de la lista con relacion al tipo de item
            ReadListaItem responseLIstaitem = await _service.ReadListaItemIteracion(createRequest.TipoItem, cancellationToken);
            if (responseLIstaitem == null)
            {
                return NotFound(new ApiResponse("No existe Lista con dicho tipo de Item", responseLIstaitem, 404));
            }

            //verificar si la iteracion esta creada con ese usuario para poder eliminarla, si no se crea
            ReadIteracion responseiteracion = await _service.ReadIteracionPublicacion(createRequest.PublicacionId, createRequest.AppUserId,responseLIstaitem.Id,cancellationToken);
             if (responseiteracion != null)
            {
                //se elimina la iteracion ya que se encuentra registrada 
                await _service.DeleteIteracion(responseiteracion.Id, cancellationToken);

                List<ReadPublication> result2 = await _service.ReadListaItemIteracionIdPublicacion(createRequest.PublicacionId);

                responseiteracion.NroMeGusta = result2[0].NroMeGusta;
                responseiteracion.NroFavoritos = result2[0].NroFavoritos;
                
                return Ok(new ApiResponse("Iteración de la publicacion eliminada Exitosamente", responseiteracion, 201));


            }
            else{
                //se crea la iteracion
                createRequest.ListaItemId = responseLIstaitem.Id;

                ReadIteracion result = await _service.CreateIteracionpublicacion(createRequest, cancellationToken);

                List<ReadPublication> result2 = await _service.ReadListaItemIteracionIdPublicacion(createRequest.PublicacionId);

                result.NroMeGusta = result2[0].NroMeGusta;
                result.NroFavoritos = result2[0].NroFavoritos;
            
                return Ok(new ApiResponse("Iteración de la publicacion creada Exitosamente", result, 200));
                
            }

         
        }

        [HttpPost("CrearIteracionComentario")]
        [Consumes(MediaTypeNames.Application.Json)]
        [ProducesResponseType(StatusCodes.Status201Created)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        // [Authorize(Roles = "CIEN_COMMUNITY_LISTA_CREAR, CIEN_COMMUNITY_SUPER_ADMINISTRADOR")]
        public async Task<IActionResult> CrearIteracionComentario([FromBody] CreateIteracionComment createRequest, CancellationToken cancellationToken)
        {

            ReadComment responsepublication = await _service.ReadComentario(createRequest.ComentarioId, cancellationToken);

            if (responsepublication == null)
            {
                return NotFound(new ApiResponse("No existe el comentario con ese Id", responsepublication, 404));
            }
            
            createRequest.AppUserId = _actorService.GetActor();

            ReadAppUser responseuser = await _service.ReadUser(createRequest.AppUserId, cancellationToken);
            if (responseuser == null)
            {
                return NotFound(new ApiResponse("No existe Usuario con ese Id", responseuser, 404));
            }

            if (createRequest.TipoItem != "ITEMG")
            {
                return NotFound(new ApiResponse("El tipo de Item debe ser ITEMG", 404));
            }

            //verificar el id de la lista con relacion al tipo de item
            ReadListaItem responseLIstaitem = await _service.ReadListaItemIteracion(createRequest.TipoItem, cancellationToken);
            if (responseLIstaitem == null)
            {
                return NotFound(new ApiResponse("No existe Lista con dicho tipo de Item", responseLIstaitem, 404));
            }

              //verificar si la iteracion esta creada con ese usuario para poder eliminarla, si no se crea
            ReadIteracion responseiteracion = await _service.ReadIteracionComentario(createRequest.ComentarioId, createRequest.AppUserId,responseLIstaitem.Id,cancellationToken);
            if (responseiteracion != null)
            {
                 //se elimina la iteracion ya que se encuentra registrada 
                await _service.DeleteIteracion(responseiteracion.Id, cancellationToken);

                List<ReadComment> result2 = await _service.ReadListaItemIteracionIdComentario(createRequest.ComentarioId);

                responseiteracion.NroMeGusta = result2[0].NroMeGusta;
                // responseiteracion.NroFavoritos = result2[0].NroFavoritos;
                
                return Ok(new ApiResponse("Iteración del Comentario eliminada Exitosamente", responseiteracion, 201));
            }
            else
            {
                createRequest.ListaItemId = responseLIstaitem.Id;

                ReadIteracion result = await _service.CreateIteracioncomentario(createRequest, cancellationToken);

                List<ReadComment> result2 = await _service.ReadListaItemIteracionIdComentario(createRequest.ComentarioId);

                result.NroMeGusta = result2[0].NroMeGusta;
                // result.NroFavoritos = result2[0].NroFavoritos;

                return Ok(new ApiResponse("Iteración del Comentario creada Exitosamente", result, 200));
            }


           
        }

        [HttpPost("CrearPublicacionOcultar")]
        [Consumes(MediaTypeNames.Application.Json)]
        [ProducesResponseType(StatusCodes.Status201Created)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        // [Authorize(Roles = "CIEN_COMMUNITY_LISTA_CREAR, CIEN_COMMUNITY_SUPER_ADMINISTRADOR")]
        public async Task<IActionResult> CrearPublicacionOcultar([FromBody] CreateHidePublication createRequest, CancellationToken cancellationToken)
        {

            ReadPublication responsepublication = await _service.Read(createRequest.PublicacionId, cancellationToken);

            if (responsepublication == null)
            {
                return NotFound(new ApiResponse("No existe La publicación con ese Id", responsepublication, 404));
            }

            createRequest.AppUserId = _actorService.GetActor();

            ReadAppUser responseuser = await _service.ReadUser(createRequest.AppUserId, cancellationToken);
            if (responseuser == null)
            {
                return NotFound(new ApiResponse("No existe Usuario con ese Id", responseuser, 404));
            }

            ReadListaItem responseLIstaitem = await _service.ReadListaItem(createRequest.ListaItemId, cancellationToken);
            if (responseLIstaitem == null)
            {
                return NotFound(new ApiResponse("No existe Lista con dicho tipo de Item", responseLIstaitem, 404));
            }

            ReadHidePublication result = await _service.CreatePublicacionOcultar(createRequest, cancellationToken);
            return Ok(new ApiResponse("Publicacion Ocultar creada Exitosamente", result, 200));
        }

        [HttpPost("CrearPublicacionReportar")]
        [Consumes(MediaTypeNames.Application.Json)]
        [ProducesResponseType(StatusCodes.Status201Created)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        // [Authorize(Roles = "CIEN_COMMUNITY_LISTA_CREAR, CIEN_COMMUNITY_SUPER_ADMINISTRADOR")]
        public async Task<IActionResult> CrearPublicacionReportar([FromBody] CreateReportPublications createRequest, CancellationToken cancellationToken)
        {

            ReadPublication responsepublication = await _service.Read(createRequest.PublicacionId, cancellationToken);

            if (responsepublication == null)
            {
                return NotFound(new ApiResponse("No existe La publicación con ese Id", responsepublication, 404));
            }

            createRequest.AppUserId = _actorService.GetActor();

            ReadAppUser responseuser = await _service.ReadUser(createRequest.AppUserId, cancellationToken);
            if (responseuser == null)
            {
                return NotFound(new ApiResponse("No existe Usuario con ese Id", responseuser, 404));
            }

            ReadReportPublication responsereportar = await _service.ReadReportar(createRequest.PublicacionId, createRequest.AppUserId, cancellationToken);

            if (responsereportar != null)
            {
                return NotFound(new ApiResponse("Ya existe un reporte con esa publicación", responsereportar, 404));
            }

            ReadListaItem responseLIstaitem = await _service.ReadListaItem(createRequest.ListaItemId, cancellationToken);
            if (responseLIstaitem == null)
            {
                return NotFound(new ApiResponse("No existe Lista con dicho tipo de Item", responseLIstaitem, 404));
            }

            ReadReportPublication result = await _service.CreatePublicacionReportar(createRequest, cancellationToken);
            return Ok(new ApiResponse("Publicacion Reportada Exitosamente", result, 200));
        }

    }
}