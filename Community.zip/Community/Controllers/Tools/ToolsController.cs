﻿using System;
using System.Net.Mime;
using System.Threading;
using System.Threading.Tasks;
using AutoWrapper.Wrappers;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Community.Dtos.Pagination.Models;
using Community.Dtos.Pagination.Services;
using System.Collections.Generic;
using Community.Dtos.Tools.Models;
using Community.Services.Tools;
using Application.Clients.Keycloak.Services.Users;

namespace Community.Controllers.Tools
{
    [ApiController]
    [Route("/api/community/v1/Tools")]
    public class ToolsController : ControllerBase
    {
        private readonly IToolsService _service;
        private readonly IUriService _uriService;
        private readonly IActorService _actorService;
        public ToolsController(IToolsService service, IUriService uriService, IActorService actorService)
        {
            _service = service;
            _uriService = uriService;
            _actorService = actorService;
        }
        [HttpPost()]
        public async Task<IActionResult> Create([FromBody] CreateTools createRequest, CancellationToken cancellationToken)
        {
                createRequest.AppUserId = _actorService.GetActor();
                
                ReadTools result = await _service.Create(createRequest, cancellationToken);
                
                return Created("/api/v1/projects/" + result.Id, new ApiResponse("Estás a un paso de hacer parte de la comunidad CIEN. Por favor verifica tu correo electrónico .", result, 201));
        }
        [HttpGet()]
        public async Task<IActionResult> GetbyToolsId(CancellationToken cancellationToken)
        {
            var user_id = _actorService.GetActor();
            
            ReadTools response = await _service.Read(user_id, cancellationToken);

            if (response != null)
                return Ok(new ApiResponse("Perfils found.", response, 200));
            
            return NotFound(new ApiResponse("Perfils not found.", null, 404));            
        }
        
        [HttpPut()]
        public async Task<IActionResult> Update([FromBody] UpdateTools updateRequest, CancellationToken cancellationToken)
        {
            var id = _actorService.GetActor();
            ReadTools response = await _service.Read(id, cancellationToken);

            if (response == null)
            {
                return NotFound(new ApiResponse("Herramienta updated.", response, 404));
            }
            else
            {
                if (updateRequest.Id != id)
                {
                    return BadRequest(new ApiResponse("Herramienta Id and id doesn't match", response, 404));
                }

                response = await _service.Update(updateRequest, cancellationToken);
                return Ok(new ApiResponse("Project updated.", response, 200));
            }
        }
    }
}

