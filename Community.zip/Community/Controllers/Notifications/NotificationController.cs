using System;
using System.Net.Mime;
using System.Threading;
using System.Threading.Tasks;
using AutoWrapper.Wrappers;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Community.Dtos.Pagination.Models;
using Community.Dtos.Pagination.Services;
using Community.Dtos.Notifications.Models;
using Community.Services.Notifications;
using Application.Clients.Keycloak.Services.Users;

namespace Community.Notifications.Controllers
{
    [ApiController]
    [Route("/api/community/v1/notification")]

    public class NotificationController : ControllerBase
    {

        private readonly INotificationService _service;
        private readonly IActorService _actorService;

        public NotificationController(INotificationService service, IActorService actorService)
        {
            _service = service;
            _actorService = actorService;
        }

        [HttpGet()]
        [Authorize()]

        public async Task<IActionResult> Read(CancellationToken cancellationToken)
        {
            var id = _actorService.GetActor();

            var response = await _service.ReadAll(id, cancellationToken);

            if (response != null)
            {
                return Ok(new ApiResponse("Notificacion found.", response, 200));
            }
            else
            {
                return NotFound(new ApiResponse("Notificacion no found.", null, 404));
            }
        }

        [HttpDelete("{id}")]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        [Authorize]
        public async Task<ApiResponse> Delete(Guid id, CancellationToken cancellationToken)
        {
            await _service.Delete(id, cancellationToken);
            return new ApiResponse("Notification deleted.", null, 200);
        }
        [HttpPut("silence/{id}")]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        [Authorize]
        public async Task<ApiResponse> Silence(Guid id, CancellationToken cancellationToken)
        {
            return new ApiResponse("Usuario silenciado.", null, 200);
        }

        [HttpGet("count")]
        [Authorize]
        public async Task<IActionResult> Count(CancellationToken cancellationToken)
        {
            try{
                var id = _actorService.GetActor();
                var result = await _service.Count(id, cancellationToken);
                return Ok(new ApiResponse("Notificacion found", result, 200));
            }
            catch (Exception ex)
            {
                return NotFound(ex.Message);
            }
           
        }

        [HttpPut("reset")]
        [Authorize]
        public async Task<IActionResult> Reset(CancellationToken cancellationToken)
        {
            try{
                var id = _actorService.GetActor();
                var result = await _service.Reset(id, cancellationToken);
                return Ok(new ApiResponse("Notificacion reset", result, 200));
            }
            catch (Exception ex)
            {
                return NotFound(ex.Message);
            }
           
        }

    
    }
}
