using System;
using System.Net.Mime;
using System.Threading;
using System.Threading.Tasks;
using AutoWrapper.Wrappers;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Community.Dtos.Pagination.Models;
using Community.Dtos.Pagination.Services;
using Community.Dtos.AppUsers.Models;
using Community.Services.AppUsers;
using Application.Clients.Keycloak.Services.Users;
using Community.Services.Contactos;
using Community.Dtos.Contactos.Models;

namespace Community.Contactos.Controllers
{
    [ApiController]
    [Route("/api/community/v1/contactos")]

    public class ContactoController : ControllerBase
    {

        private readonly IContactoService _service;
        private readonly IActorService _actorService;

        public ContactoController(IContactoService service, IActorService actorService)
        {
            _service = service;
            _actorService = actorService;
        }

        [HttpPost()]
        [Consumes(MediaTypeNames.Application.Json)]
        [ProducesResponseType(StatusCodes.Status201Created)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        public async Task<IActionResult> Create([FromBody] CreateContacto createRequest, CancellationToken cancellationToken)
        {
            try{
                var id = _actorService.GetActor();
                createRequest.UserId = id;
                ReadContacto result = await _service.Create(createRequest, cancellationToken);
                return Created("", new ApiResponse("Contacto creado", result, 201));
            }
            catch (Exception ex)
            {
                return NotFound(ex.Message);
            }
           
        }

        
        
    }
}
