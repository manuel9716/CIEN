using System;
using System.Net.Mime;
using System.Threading;
using System.Threading.Tasks;
using AutoWrapper.Wrappers;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Community.Dtos.Pagination.Models;
using Community.Dtos.Pagination.Services;
using Community.Dtos.AppUsers.Models;
using Community.Services.AppUsers;
using Application.Clients.Keycloak.Services.Users;

namespace Community.AppUsers.Controllers
{
    [ApiController]
    [Route("/api/community/v1/user")]

    public class AppUsersController : ControllerBase
    {

        private readonly IAppUsersService _service;
        private readonly IUriService _uriService;
        private readonly IActorService _actorService;

        public AppUsersController(IAppUsersService service, IUriService uriService, IActorService actorService)
        {
            _service = service;
            _uriService = uriService;
            _actorService = actorService;
        }

        [HttpPost()]
        [Consumes(MediaTypeNames.Application.Json)]
        [ProducesResponseType(StatusCodes.Status201Created)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        public async Task<IActionResult> Create([FromBody] CreateAppUser createRequest, CancellationToken cancellationToken)
        {
            try{
                
                ReadAppUser result = await _service.Create(createRequest, cancellationToken);
                return Created("/api/v1/projects/" + result.Id, new ApiResponse("Estás a un paso de hacer parte de la comunidad CIEN. Por favor verifica tu correo electrónico .", result, 201));
            }
            catch (Exception ex)
            {
                return NotFound(ex.Message);
            }
           
        }

        [HttpGet("CurrentUserId")]
        [Authorize]
        public IActionResult IdCurrentuser()
        {
            var response = _actorService.GetActor();
            if (response != new Guid())
            {
                return Ok(new ApiResponse("IdCurrentuser found.", response, 200));
            }
            else
            {
                return NotFound(new ApiResponse("IdCurrentuser no found.", null, 404));
            }
        }




        [HttpGet("{id}")]
        // [Authorize(Roles = "CIEN_COMMUNITY_APPUSER_VER, CIEN_COMMUNITY_SUPER_ADMINISTRADOR")]

        public async Task<IActionResult> Read(Guid id, CancellationToken cancellationToken)
        {
            ReadAppUser response = await _service.Read(id, cancellationToken);

            if (response != null)
            {
                return Ok(new ApiResponse("AppUser found.", response, 200));
            }
            else
            {
                return NotFound(new ApiResponse("AppUser no found.", null, 404));
            }
        }

        [HttpGet("readPrivacy")]
        [Authorize]
        public async Task<IActionResult> ReadPrivacy(CancellationToken cancellationToken)
        {
            try{
                var id = _actorService.GetActor();
                ReadPrivacyAppUser result = await _service.ReadPrivacy(id, cancellationToken);
                return Ok(new ApiResponse("AppUser found", result, 200));
            }
            catch (Exception ex)
            {
                return NotFound(ex.Message);
            }
           
        }

        [HttpPut("{id}")]
        [Consumes(MediaTypeNames.Application.Json)]
        [ProducesResponseType(StatusCodes.Status201Created)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        [Authorize(Roles = "CIEN_COMMUNITY_APPUSER_ACTUALIZAR, CIEN_COMMUNITY_SUPER_ADMINISTRADOR")]

        public async Task<IActionResult> Update(Guid id, [FromBody] UpdateAppUser updateRequest, CancellationToken cancellationToken)
        {
            ReadAppUser response = await _service.Read(id, cancellationToken);

            if (response == null)
            {
                return NotFound(new ApiResponse("AppUser updated.", response, 404));
            }
            else
            {
                if (updateRequest.Id != id)
                {
                    return BadRequest(new ApiResponse("AppUser Id and id doesn't match", response, 404));
                }

                response = await _service.Update(updateRequest, cancellationToken);
                return Ok(new ApiResponse("Project updated.", response, 200));
            }
        }

        [HttpPut("updatePrivacy")]
        [Consumes(MediaTypeNames.Application.Json)]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        [Authorize]
        public async Task<IActionResult> UpdatePrivacy([FromBody] UpdatePrivacyAppUser updatePrivacyRequest, CancellationToken cancellationToken)
        {
            try{   
                updatePrivacyRequest.Id = _actorService.GetActor();
                var result = await _service.UpdatePrivacy(updatePrivacyRequest, cancellationToken);
                return Ok(new ApiResponse("Privacidad actualizada con éxito", true, 200));
            }
            catch (Exception ex)
            {
                return NotFound(ex.Message);
            }
           
        }

        [HttpDelete]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        [Authorize]
        public async Task<ApiResponse> Delete(DeleteAppUser deleteRequest, CancellationToken cancellationToken)
        {
            deleteRequest.Id = _actorService.GetActor();
            await _service.Delete(deleteRequest, cancellationToken);
            return new ApiResponse("AppUser deleted.", null, 204);
        }

        [HttpGet()]
        [Consumes(MediaTypeNames.Application.Json)]
        [ProducesResponseType(StatusCodes.Status201Created)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        [Authorize(Roles = "CIEN_COMMUNITY_APPUSER_BUSCAR, CIEN_COMMUNITY_SUPER_ADMINISTRADOR")]

        public async Task<IActionResult> Search([FromQuery] Paginator paginator, [FromQuery] Sorter sorter, [FromQuery] SearchAppUser searchRequest, CancellationToken cancellationToken)
        {
            string route = Request.Path.Value;

            Paged<ReadAppUser> response = await _service.Search(paginator, sorter, searchRequest, _uriService, route, cancellationToken);
            return Ok(new ApiResponse("Query done!", response, 200));
        }

        [HttpPut("updatePassword")]
        [Consumes(MediaTypeNames.Application.Json)]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        [Authorize]
        public async Task<IActionResult> UpdatePassword([FromBody] UpdatePasswordAppUser updatePasswordRequest, CancellationToken cancellationToken)
        {
            try{
                updatePasswordRequest.Id = _actorService.GetActor();
                var result = await _service.UpdatePassword(updatePasswordRequest, cancellationToken);
                return Ok(new ApiResponse("Contraseña actualizada con éxito", result, 200));
            }
            catch (Exception ex)
            {
                return NotFound(ex.Message);
            }
           
        }

        [HttpPut("updateEmail")]
        [Consumes(MediaTypeNames.Application.Json)]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        [Authorize]
        public async Task<IActionResult> UpdateEmail([FromBody] UpdateEmailAppUser updateEmailRequest, CancellationToken cancellationToken)
        {
            try{
                updateEmailRequest.Id = _actorService.GetActor();
                var result = await _service.UpdateEmail(updateEmailRequest, cancellationToken);
                return Ok(new ApiResponse("Email actualizado con éxito", result, 200));
            }
            catch (Exception ex)
            {
                return NotFound(ex.Message);
            }
           
        }

        [HttpGet("readMetric")]
        [Authorize]
        public async Task<IActionResult> ReadMetric(CancellationToken cancellationToken)
        {
            try{
                var result = await _service.ReadMetric(cancellationToken);
                return Ok(new ApiResponse("AppUser found", result, 200));
            }
            catch (Exception ex)
            {
                return NotFound(ex.Message);
            }
           
        }

        [HttpPut("updateProfile")]
        [Consumes(MediaTypeNames.Application.Json)]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        [Authorize]
        public async Task<IActionResult> UpdateProfile([FromBody] UpdateProfileAppUser updateEmailRequest, CancellationToken cancellationToken)
        {
            try{
                updateEmailRequest.Id = _actorService.GetActor();
                var result = await _service.UpdateProfile(updateEmailRequest, cancellationToken);
                return Ok(new ApiResponse("Perfil actualizado con éxito", result, 200));
            }
            catch (Exception ex)
            {
                return NotFound(ex.Message);
            }
        }

        [HttpGet("readProfile")]
        [Authorize]
        public async Task<IActionResult> ReadProfile(CancellationToken cancellationToken)
        {
            try{
                var id = _actorService.GetActor();
                ReadProfileAppUser result = await _service.ReadProfile(id, cancellationToken);
                return Ok(new ApiResponse("Perfil found", result, 200));
            }
            catch (Exception ex)
            {
                return NotFound(ex.Message);
            }
           
        }

        [HttpGet("readProfile/{id}")]
        [Authorize]
        public async Task<IActionResult> ReadProfile(Guid id, CancellationToken cancellationToken)
        {
            try{
                ReadProfileAppUser result = await _service.ReadProfile(id, cancellationToken);
                return Ok(new ApiResponse("Perfil found", result, 200));
            }
            catch (Exception ex)
            {
                return NotFound(ex.Message);
            }
           
        }

        [HttpGet("readSugerencias")]
        [Authorize]
        public async Task<IActionResult> ReadSugerencias([FromQuery] Paginator paginator,CancellationToken cancellationToken)
        {
            try{
                var id = _actorService.GetActor();
                var result = await _service.ReadSugerencia(id, paginator, cancellationToken);
                return Ok(new ApiResponse("Sugerencias found", result, 200));
            }
            catch (Exception ex)
            {
                return NotFound(ex.Message);
            }
           
        }

        [HttpGet("readPreguntaConecta/{id}")]
        [Authorize]
        public async Task<IActionResult> ReadPreguntaConecta(Guid id, CancellationToken cancellationToken)
        {
            try{
                ReadPreguntaConectaAppUser result = await _service.ReadPreguntaConecta(id, cancellationToken);
                return Ok(new ApiResponse("Pregunta conecta found", result, 200));
            }
            catch (Exception ex)
            {
                return NotFound(ex.Message);
            }
           
        }
    }
}
