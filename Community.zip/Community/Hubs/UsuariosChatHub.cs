using Application.Clients.Keycloak.Services.Users;
using Community.Dtos.Messages.Models;
using Community.Models.Messages;
using Community.Repositories.Messages;
using Community.Services.Messages;
using Microsoft.AspNetCore.SignalR;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Community.Hubs
{
    public class UsuariosChatHub:Hub
    {
        private IMessageRepository _repository;
        private readonly IActorService _actorService;
        private readonly IMessageService _service;
        public UsuariosChatHub(IMessageRepository repository, IActorService actorService, IMessageService service)
        {
            _repository = repository;
            _actorService = actorService;
            _service = service;
        }

        public override async Task OnConnectedAsync()
        {

            await base.OnConnectedAsync();

        }

        public override async Task OnDisconnectedAsync(Exception exception)
        {
            UsuariosConectados resultado = _repository.DeleteUsuariosConectadosToken(this.Context.ConnectionId);

            await base.OnDisconnectedAsync(exception);
        }

        public async Task AdicionarUsuario(Guid appUserId)
        {

            var usuariosConectados = new UsuariosConectados
            {
                AppUserId = appUserId,
                SocketId = Context.ConnectionId

            };

            UsuariosConectados respuesta = _repository.CreateUsuariosConectados(usuariosConectados);

        }

        public async Task removerUsuario(Guid userId)
        {

            UsuariosConectados resultado = _repository.DeleteUsuariosConectados(userId);

        }
        public Task consultarNotificaciones(Guid userId)
        {

            List<ReadConversation> response = _service.GetConversacionesSocket(userId);

             return Clients.Client(Convert.ToString(this.Context.ConnectionId)).SendAsync("RespuestaConversaciones", response);

        }
         public Task consultarNotificacionesresumido(Guid userId)
        {

            List<ReadConversation> response = _service.GetConversacionesSocket(userId);
            var respuesta = new List<ReadConversationSocket>();
            foreach (var item in response)
            {
                var response2 = new ReadConversationSocket()
                {
                    Id = item.Id,
                    NroMensajesSinLeer = item.NroMensajesSinLeer
                };

                respuesta.Add(response2);


            }
           
            return Clients.Client(Convert.ToString(this.Context.ConnectionId)).SendAsync("RespuestaConversacionesresumido", respuesta);

        }
        public Task verificarConexionUsuario(Guid userReceptorId)
        {
            //verificar si existe conexion
            var conexion = true;

            UsuariosConectados conexionReceptor = _repository.ReadUsuarioConectado(userReceptorId);

            if(conexionReceptor == null)
            {
                conexion = false; 
            }

            return Clients.Client(Convert.ToString(this.Context.ConnectionId)).SendAsync("RespuestaConexionUsuario", conexion);
        }

    }
}
