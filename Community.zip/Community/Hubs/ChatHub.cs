using Application.Clients.Keycloak.Services.Users;
using Community.Dtos.AppUsers.Models;
using Community.Dtos.Messages.Models;
using Community.Models.Messages;
using Community.Repositories.Messages;
using Community.Services.AppUsers;
using Community.Services.Messages;
using Microsoft.AspNetCore.SignalR;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Community.Hubs
{
    public class ChatHub: Hub
    {
        private IMessageService _service;
        private readonly IActorService _actorService;
        private readonly IAppUsersService _userService;
        private readonly IMessageRepository _repository;

        public ChatHub(IMessageService service, IActorService actorService, IAppUsersService userService, IMessageRepository repository)
        {
            _service = service;
            _actorService = actorService;
            _userService = userService;
            _repository = repository;
        }
        public override async Task OnConnectedAsync()
        {
            await base.OnConnectedAsync();
        }

        public override async Task OnDisconnectedAsync(Exception exception)
        {
            //id = this.Context.ConnectionId;
            ConversacionesConectados resultado = _repository.DeleteConversacionesConectadosToken(this.Context.ConnectionId);

            await base.OnDisconnectedAsync(exception);
        }
        public Task EnviarMensaje(Guid appUserId, string message, Guid group,Guid userReceptorId,Guid mensajeId,string urlGif, List<ReadMessageFile> files)               // Two parameters accepted
        {

            //verificar si existe conexion de esa conversacion
            ConversacionesConectados resultconexion = _repository.ReadConversacionConectadoReceptor(group, userReceptorId);

            if(resultconexion == null)
            {
                //colocar el mensaje como no leido 
                UpdateMessage mensaje = new UpdateMessage
                {
                    Id = mensajeId,
                    Leido = false,
                };


                ReadMessage result = _service.UpdateMensajeNoLeido(mensaje);

            }

            //verificar el nombre del usuario que manda el mensajes
            ReadAppUser responseUserSender = _service.ReadUser(appUserId);
            var nombre = responseUserSender.Nombres + " " + responseUserSender.Apellidos;

            return Clients.Group(Convert.ToString(group)).SendAsync("ReceiveOne", nombre, message,appUserId,userReceptorId,urlGif,files);

        }

        public async Task AdicionarGrupo(Guid appUserId, Guid group)
        {

            //adicionar las conversaciones a la tabla conversaciones conectados
            var conversacionesConectados = new ConversacionesConectados
            {
                AppUserId = appUserId,
                ConversacionId = group,
                SocketId = Context.ConnectionId

            };

            ConversacionesConectados respuesta = _repository.CreateConversacionesConectados(conversacionesConectados);

            await Groups.AddToGroupAsync(Context.ConnectionId, Convert.ToString(group));
            
        }

        public async Task removerGrupo(Guid userId,Guid group)
        {

            ConversacionesConectados resultado = _repository.DeleteConversacionesConectados(group,userId);
            
            await Groups.RemoveFromGroupAsync(this.Context.ConnectionId, Convert.ToString(group));
        }
        public Task ModificarMensajesComoLeido(Guid ConversacionId,Guid userReceptorId)
        {
            List<Message> result = _repository.ReadMensajesReceptorSinLeer(ConversacionId, userReceptorId);

            foreach (var item in result)
            {
                UpdateMessage mensaje = new UpdateMessage
                {
                    Id = item.Id,
                    Leido = true,
                };

                ReadMessage result2 = _service.UpdateMensajeNoLeido(mensaje);

            }

            return Clients.All.SendAsync("respuestamodificacionmensajesleidos", true);
        }
    }
}
