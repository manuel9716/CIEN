using Microsoft.Extensions.DependencyInjection;
using Community.Clients.Keycloak.Services.Auth;
using Community.Clients.Keycloak.Services.Groups;
using Community.Clients.Keycloak.Services.Rol;
using Community.Clients.Keycloak.Services.Users;
using Community.Clients.Keycloak.Services.Roles;
using Application.Clients.Keycloak.Services.Users;
using Community.Clients.Keycloak.Services.Email;

namespace Community.Clients.Keycloak.Extentions
{
    public static class ClientKeycloakExtentions
    {
        public static IServiceCollection AddKeycloakExtentions(this IServiceCollection services)
        {
            services.AddScoped<IKeycloakUsersService, KeycloakUsersService>();
            services.AddScoped<IKeycloakGroupsService, KeycloakGroupsService>();
            services.AddScoped<IKeycloakRolesService, KeycloakRolesService>();
            services.AddHttpClient<ITokenService, TokenService>();
            services.AddScoped<ITokenService, TokenService>();
            services.AddScoped<IKeycloakRoleMappingService, KeycloakRoleMappingService>();
            services.AddScoped<IActorService, ActorService>();
             services.AddScoped<IEmailService, EmailService>();
            
            return services;
        }
    }
}
