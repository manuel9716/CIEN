using System;
using System.Text.Json.Serialization;

namespace Community.Clients.Keycloak.Dtos.Groups
{
    public class KeycloakGroupViewRequest
    {
        [JsonPropertyName("id")]
        public Guid Id { get; set; }
        [JsonPropertyName("name")]
        public String Name { get; set; }

    }
}
