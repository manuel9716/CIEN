using System.Text.Json.Serialization;

namespace Community.Clients.Keycloak.Dtos.Groups
{
    public class KeycloakGroupCreateRequest
    {
        [JsonPropertyName("name")]
        public string Name { get; set; }
    }
}
