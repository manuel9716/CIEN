using System;
using System.Text.Json.Serialization;

namespace Community.Clients.Keycloak.Dtos.Users
{
    public class KeycloakUsersSearchRequest
    {
        [JsonPropertyName("email")]
        public String Email { get; set; }

        [JsonPropertyName("emailVerified")]
        public Boolean? EmailVerified { get; set; }

        [JsonPropertyName("firstName")]
        public String FirstName { get; set; }

        [JsonPropertyName("lastName")]
        public String LastName { get; set; }

        [JsonPropertyName("username")]
        public String Username { get; set; }
    }
}
