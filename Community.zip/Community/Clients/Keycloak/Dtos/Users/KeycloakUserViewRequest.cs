using System;
using System.Text.Json.Serialization;

namespace Community.Clients.Keycloak.Dtos.Users
{
    public class KeycloakUserViewRequest
    {

        [JsonPropertyName("id")]
        public Guid Id { get; set; }

        [JsonPropertyName("firstName")]
        public string FirstName { get; set; }

        [JsonPropertyName("lastName")]
        public string LastName { get; set; }

        [JsonPropertyName("email")]
        public string Email { get; set; }

        [JsonPropertyName("enabled")]
        public Boolean Enabled { get; set; }

        [JsonPropertyName("username")]
        public string Username { get; set; }

    }
}
