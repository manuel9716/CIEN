using System;
using System.Text.Json.Serialization;

namespace Community.Clients.Keycloak.Dtos.Passwords
{
    public class KeycloakPasswordUpdateRequest
    {
        [JsonPropertyName("type")]
        public string Type { get; set; }

        [JsonPropertyName("value")]
        public string Value { get; set; }

        [JsonPropertyName("temporary")]
        public Boolean Temporary { get; set; }
    }
}
