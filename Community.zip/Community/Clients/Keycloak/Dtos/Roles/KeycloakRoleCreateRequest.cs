using System;
using System.Text.Json.Serialization;

namespace Community.Clients.Keycloak.Dtos.Roles
{
    public class KeycloakRoleCreateRequest
    {
        [JsonPropertyName("name")]
        public String Name { get; set; }

        [JsonPropertyName("description")]
        public String Description { get; set; }

    }
}
