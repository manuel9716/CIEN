using System.Collections.Generic;
using System.Text.Json.Serialization;

namespace Community.Clients.Keycloak.Dtos.Roles
{
    public class KeycloakRoleMappingViewRequest
    {

        [JsonPropertyName("realmMappings")]
        public List<KeycloakRoleViewRequest> RealmMappings { get; set; }
    }
}
