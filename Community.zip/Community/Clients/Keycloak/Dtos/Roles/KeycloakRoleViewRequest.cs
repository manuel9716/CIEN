using System;
using System.Text.Json.Serialization;

namespace Community.Clients.Keycloak.Dtos.Roles
{
    public class KeycloakRoleViewRequest
    {
        [JsonPropertyName("id")]
        public Guid Id { get; set; }

        [JsonPropertyName("name")]
        public String Name { get; set; }

        [JsonPropertyName("description")]
        public String Description { get; set; }
    }
}
