using Community.Clients.Keycloak.Dtos.Users;
using Community.Clients.Keycloak.Services.Users;
using Community.Repositories.Notifications;
using Community.Services.Notifications;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Net;
using System.Net.Mail;
using System.Threading;
using System.Threading.Tasks;

namespace Community.Clients.Keycloak.Services.Email
{
    public class EmailService : IEmailService
    {
        private readonly INotificationService _notificationService;
        private readonly IKeycloakUsersService _keycloakUsersService;
        public EmailService(INotificationService notificationService,IKeycloakUsersService keycloakUsersService)
        {
            _notificationService = notificationService;
            _keycloakUsersService = keycloakUsersService;
        }
        public string SendEmail(Guid id,string subject,string body)
        {

            try
            {
                KeycloakUserViewRequest user = _keycloakUsersService.ReadUser(id);
                var correo = user.Email;

                MailMessage msj = new MailMessage();
                msj.From = new MailAddress(correo, "CIEN");
                msj.To.Add(new MailAddress(correo));

                msj.Subject = subject;
                msj.Body = body;
            
                msj.IsBodyHtml = true;
                SmtpClient setp = new SmtpClient("smtp.gmail.com");
                setp.Credentials = new NetworkCredential("", "");

                setp.EnableSsl = true;
                setp.Port = 587;
                setp.Send(msj);

                return "correo enviado con exito";
            }
            catch (Exception)
            {
                return "Se presento un error al mandar el correo";
            }
           

        }
    }
}
