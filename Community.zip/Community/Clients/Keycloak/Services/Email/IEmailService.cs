using Microsoft.AspNetCore.Mvc;
using System;
using System.Threading;
using System.Threading.Tasks;

namespace Community.Clients.Keycloak.Services.Email
{
    public interface IEmailService
    {
        public string SendEmail(Guid id,string subject,string body);
    }
}