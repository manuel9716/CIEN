using System.Threading.Tasks;
using Community.Clients.Keycloak.Dtos;

namespace Community.Clients.Keycloak.Services.Auth
{
    public interface ITokenService
    {
        Token GetToken();
    }
}
