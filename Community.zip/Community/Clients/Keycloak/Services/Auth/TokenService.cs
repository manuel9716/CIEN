using System;
using System.Collections.Generic;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Text.Json;
using System.Threading.Tasks;
using RestSharp;
using Community.Clients.Keycloak.Dtos;

namespace Community.Clients.Keycloak.Services.Auth
{
    public class TokenService : ITokenService
    {
        private HttpClient _httpClient;
        private string KEYCLOAK_HOST;
        private string KEYCLOAK_REALM;
        private string KEYCLOAK_ADMIN_CLIENT_ID;
        private string KEYCLOAK_ADMIN_CLIENT_SECRET;

        public TokenService(HttpClient httpClient)
        {
            _httpClient = httpClient;
            KEYCLOAK_HOST = Environment.GetEnvironmentVariable("KEYCLOAK_HOST");
            KEYCLOAK_REALM = Environment.GetEnvironmentVariable("KEYCLOAK_REALM");
            KEYCLOAK_ADMIN_CLIENT_ID = Environment.GetEnvironmentVariable("KEYCLOAK_ADMIN_CLIENT_ID");
            KEYCLOAK_ADMIN_CLIENT_SECRET = Environment.GetEnvironmentVariable("KEYCLOAK_ADMIN_CLIENT_SECRET");
        }

        public Token GetToken()
        {
            var TOKEN_URL = KEYCLOAK_HOST + "/auth/realms/" + KEYCLOAK_REALM + "/protocol/openid-connect/token";
            Console.Error.WriteLine(" TOKEN_URL: " + TOKEN_URL);

            var client = new RestClient(TOKEN_URL);
            client.Timeout = -1;
            var request = new RestRequest(Method.POST);

            request.AddParameter("grant_type", "client_credentials");
            request.AddParameter("client_id", KEYCLOAK_ADMIN_CLIENT_ID);
            request.AddParameter("client_secret", KEYCLOAK_ADMIN_CLIENT_SECRET);

            Console.Error.WriteLine("client_id  : " + KEYCLOAK_ADMIN_CLIENT_ID);


            IRestResponse restResponse = client.Execute(request);

            Console.Error.WriteLine(" REST RESPONSE  : " + restResponse.Content.ToString());

            Token token = JsonSerializer.Deserialize<Token>(restResponse.Content);

            return token;
        }
    }
}
