using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using Community.Clients.Keycloak.Dtos.Roles;

namespace Community.Clients.Keycloak.Services.Rol
{
    public interface IKeycloakRolesService
    {
        KeycloakRoleViewRequest CreateRole(KeycloakRoleCreateRequest role);
        KeycloakRoleViewRequest ReadRole(Guid id);
        KeycloakRoleViewRequest ReadRole(String roleName);
        KeycloakRoleViewRequest UpdateRole(KeycloakRoleUpdateRequest role);
        void DeleteRole(Guid roleId);
        List<KeycloakRoleViewRequest> GetAll();
    }
}
