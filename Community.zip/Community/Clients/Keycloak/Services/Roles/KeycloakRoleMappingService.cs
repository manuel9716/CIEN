using System;
using System.Collections.Generic;
using System.Text.Json;
using Community.Clients.Keycloak.Dtos;
using Community.Clients.Keycloak.Dtos.Roles;
using Community.Clients.Keycloak.Services.Auth;
using Community.Clients.Keycloak.Services.Rol;
using RestSharp;
using RestSharp.Serializers.NewtonsoftJson;

namespace Community.Clients.Keycloak.Services.Roles
{
    public class KeycloakRoleMappingService : IKeycloakRoleMappingService
    {
        private ITokenService _tokenService;
        private string KEYCLOAK_HOST;
        private string KEYCLOAK_REALM;

        private readonly IKeycloakRolesService _rolesService;

        public KeycloakRoleMappingService(ITokenService tokenService, IKeycloakRolesService rolesService)
        {
            _tokenService = tokenService;
            _rolesService = rolesService;
            KEYCLOAK_HOST = Environment.GetEnvironmentVariable("KEYCLOAK_HOST");
            KEYCLOAK_REALM = Environment.GetEnvironmentVariable("KEYCLOAK_REALM");
        }

        public void AddRolToGroup(Guid groupId, Guid roleId)
        {
            KeycloakRoleViewRequest role = _rolesService.ReadRole(roleId);

            KeycloakRoleMappingViewRequest keycloakRoleMapping = new KeycloakRoleMappingViewRequest();

            List<KeycloakRoleViewRequest> roleList = new List<KeycloakRoleViewRequest>();
            roleList.Add(role);


            Token token = _tokenService.GetToken();

            var groupsUrl = "/auth/admin/realms/" + KEYCLOAK_REALM + "/groups/" + groupId + "/role-mappings/realm";

            var client = new RestClient(KEYCLOAK_HOST + groupsUrl);
            client.AddDefaultHeader("Authorization", "Bearer " + token.AccessToken);
            client.UseNewtonsoftJson();
            client.Timeout = -1;
            var request = new RestRequest(Method.POST);
            request.AddJsonBody(roleList);
            IRestResponse restResponse = client.Execute(request);

            var x = restResponse;

        }
        public void DeleteRolFromGroup(Guid groupId, Guid roleId)
        {
            KeycloakRoleViewRequest role = _rolesService.ReadRole(roleId);

            KeycloakRoleMappingViewRequest keycloakRoleMapping = new KeycloakRoleMappingViewRequest();

            List<KeycloakRoleViewRequest> roleList = new List<KeycloakRoleViewRequest>();
            roleList.Add(role);


            Token token = _tokenService.GetToken();

            var groupsUrl = "/auth/admin/realms/" + KEYCLOAK_REALM + "/groups/" + groupId + "/role-mappings/realm";

            var client = new RestClient(KEYCLOAK_HOST + groupsUrl);
            client.AddDefaultHeader("Authorization", "Bearer " + token.AccessToken);
            client.UseNewtonsoftJson();
            client.Timeout = -1;
            var request = new RestRequest(Method.DELETE);
            request.AddJsonBody(roleList);
            IRestResponse restResponse = client.Execute(request);

            var x = restResponse;
        }

        public List<KeycloakRoleViewRequest> GetRolesByGroup(Guid roleId)
        {
            Token token = _tokenService.GetToken();

            var rolesUrl = "/auth/admin/realms/" + KEYCLOAK_REALM + "/groups/" + roleId + "/role-mappings";

            var client = new RestClient(KEYCLOAK_HOST + rolesUrl);
            client.AddDefaultHeader("Authorization", "Bearer " + token.AccessToken);
            client.Timeout = -1;
            var request = new RestRequest(Method.GET);
            IRestResponse restResponse = client.Execute(request);

            KeycloakRoleMappingViewRequest roleMapping = JsonSerializer.Deserialize<KeycloakRoleMappingViewRequest>(restResponse.Content);

            return roleMapping.RealmMappings;
        }
    }
}
