using System;
using System.Collections.Generic;
using System.Net;
using System.Net.Http;
using System.Text.Json;
using System.Threading.Tasks;
using AutoMapper;
using RestSharp;
using Community.Clients.Keycloak.Dtos;
using Community.Clients.Keycloak.Dtos.Roles;
using Community.Clients.Keycloak.Services.Auth;
using Community.Clients.Keycloak.Services.Rol;

namespace Community.Clients.Keycloak.Services.Rol
{
    public class KeycloakRolesService : IKeycloakRolesService
    {
        private ITokenService _tokenService;
        private string KEYCLOAK_HOST;
        private string KEYCLOAK_REALM;


        public KeycloakRolesService(ITokenService tokenService)
        {
            _tokenService = tokenService;
            KEYCLOAK_HOST = Environment.GetEnvironmentVariable("KEYCLOAK_HOST");
            KEYCLOAK_REALM = Environment.GetEnvironmentVariable("KEYCLOAK_REALM");
        }

        public KeycloakRoleViewRequest CreateRole(KeycloakRoleCreateRequest role)
        {
            Token token = _tokenService.GetToken();

            var rolesUrl = "/auth/admin/realms/" + KEYCLOAK_REALM + "/roles";

            var client = new RestClient(KEYCLOAK_HOST + rolesUrl);
            client.AddDefaultHeader("Authorization", "Bearer " + token.AccessToken);
            client.Timeout = -1;
            var request = new RestRequest(Method.POST);
            request.AddJsonBody(JsonSerializer.Serialize(role));
            IRestResponse restResponse = client.Execute(request);

            if (restResponse.StatusCode == HttpStatusCode.Created)
            {
                return ReadRole(role.Name);
            }
            return null;
        }
        public KeycloakRoleViewRequest ReadRole(String roleName)
        {

            Token token = _tokenService.GetToken();

            var rolesUrl = "/auth/admin/realms/" + KEYCLOAK_REALM + "/roles/" + roleName;

            var client = new RestClient(KEYCLOAK_HOST + rolesUrl);
            client.AddDefaultHeader("Authorization", "Bearer " + token.AccessToken);
            client.Timeout = -1;
            var request = new RestRequest(Method.GET);
            IRestResponse restResponse = client.Execute(request);

            KeycloakRoleViewRequest rol = JsonSerializer.Deserialize<KeycloakRoleViewRequest>(restResponse.Content);
            return rol;
        }

        public KeycloakRoleViewRequest ReadRole(Guid id)
        {

            Token token = _tokenService.GetToken();

            var rolesUrl = "/auth/admin/realms/" + KEYCLOAK_REALM + "/roles-by-id/" + id;

            var client = new RestClient(KEYCLOAK_HOST + rolesUrl);
            client.AddDefaultHeader("Authorization", "Bearer " + token.AccessToken);
            client.Timeout = -1;
            var request = new RestRequest(Method.GET);
            IRestResponse restResponse = client.Execute(request);

            if (restResponse.StatusCode == HttpStatusCode.NotFound)
            {
                return null;
            }

            KeycloakRoleViewRequest rol = JsonSerializer.Deserialize<KeycloakRoleViewRequest>(restResponse.Content);
            return rol;
        }

        public KeycloakRoleViewRequest UpdateRole(KeycloakRoleUpdateRequest role)
        {
            Token token = _tokenService.GetToken();

            var rolesUrl = "/auth/admin/realms/" + KEYCLOAK_REALM + "/roles-by-id/" + role.Id;

            var client = new RestClient(KEYCLOAK_HOST + rolesUrl);
            client.AddDefaultHeader("Authorization", "Bearer " + token.AccessToken);
            client.Timeout = -1;
            var request = new RestRequest(Method.PUT);
            request.AddJsonBody(JsonSerializer.Serialize(role));
            IRestResponse restResponse = client.Execute(request);

            if (restResponse.IsSuccessful)
            {
                return ReadRole(role.Id);
            }
            return null;
        }
        public void DeleteRole(Guid roleId)
        {
            Token token = _tokenService.GetToken();

            var rolesUrl = "/auth/admin/realms/" + KEYCLOAK_REALM + "/roles-by-id/" + roleId;

            var client = new RestClient(KEYCLOAK_HOST + rolesUrl);
            client.AddDefaultHeader("Authorization", "Bearer " + token.AccessToken);
            client.Timeout = -1;
            var request = new RestRequest(Method.DELETE);
            IRestResponse restResponse = client.Execute(request);

        }
        public List<KeycloakRoleViewRequest> GetAll()
        {
            Token token = _tokenService.GetToken();

            var rolesUrl = "/auth/admin/realms/" + KEYCLOAK_REALM + "/roles";

            var client = new RestClient(KEYCLOAK_HOST + rolesUrl);
            client.AddDefaultHeader("Authorization", "Bearer " + token.AccessToken);
            client.Timeout = -1;
            var request = new RestRequest(Method.GET);
            IRestResponse restResponse = client.Execute(request);

            List<KeycloakRoleViewRequest> roles = JsonSerializer.Deserialize<List<KeycloakRoleViewRequest>>(restResponse.Content);

            return roles;
        }
    }
}
