using System;
using System.Collections.Generic;
using Community.Clients.Keycloak.Dtos.Roles;

namespace Community.Clients.Keycloak.Services.Roles
{
    public interface IKeycloakRoleMappingService
    {
        List<KeycloakRoleViewRequest> GetRolesByGroup(Guid roleId);
        void DeleteRolFromGroup(Guid groupId, Guid roleId);
        public void AddRolToGroup(Guid groupId, Guid roleId);
    }
}
