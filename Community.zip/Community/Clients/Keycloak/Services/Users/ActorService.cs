using System;
using System.Linq;
//using api.Models.Usuarios;
//using api.Repositories.Usuarios;
using Microsoft.AspNetCore.Http;

namespace Application.Clients.Keycloak.Services.Users
{
    public class ActorService : IActorService
    {
//        private readonly IUsuariosRepository _usuariosRepository;

        private IHttpContextAccessor _httpContextAccessor;

//        private UsuarioEntity actor = null;

//        public ActorService(IUsuariosRepository usuariosRepository, IHttpContextAccessor httpContextAccessor)
        public ActorService(IHttpContextAccessor httpContextAccessor)
        {
            //_usuariosRepository = usuariosRepository;
            _httpContextAccessor = httpContextAccessor;
        }
        public Guid GetActor()
        {
            Guid userId = new Guid();
            Guid Id= new Guid();
            foreach (var item in _httpContextAccessor.HttpContext.User.Identities)
            {
              userId = (item.Claims.Count() == 0? Id : Guid.Parse(_httpContextAccessor.HttpContext.User.FindFirst(x => x.Type.Contains("nameidentifier"))?.Value));
            }
           // Guid userId = Guid.Parse( _httpContextAccessor.HttpContext.User.FindFirst(x => x.Type.Contains("nameidentifier"))?.Value);
            
            return userId;
        }
    }
}