using System;
using System.Collections.Generic;
using Community.Clients.Keycloak.Dtos.Users;
using Community.Dtos.Pagination.Models;
using Community.Dtos.Pagination.Services;

namespace Community.Clients.Keycloak.Services.Users
{
    public interface IKeycloakUsersService
    {
        KeycloakUserViewRequest CreateUser(KeycloakUserCreateRequest user);
        KeycloakUserViewRequest ReadUser(Guid id);
        KeycloakUserViewRequest UpdateUser(KeycloakUserUpdateRequest user);
        void DeleteUser(Guid id);
        List<KeycloakUserViewRequest> Search(Paginator paginator, Sorter sorter, KeycloakUsersSearchRequest searchRequest, IUriService uriService, string route);
        int Count(KeycloakUsersSearchRequest searchRequest);
        void AddRolToUser(Guid usuarioId, Guid groupId);
        void RemoveRolToUser(Guid usuarioId, Guid groupId);
        KeycloakUserViewRequest RegisterUser(KeycloakUserCreateRequest user);
        bool UpdatePassword(Guid id, KeycloakPasswordUpdateRequest password);

    }
}
