using System;
using System.Collections.Generic;
using System.Text.Json;
using RestSharp;
using Community.Clients.Keycloak.Dtos;
using Community.Clients.Keycloak.Dtos.Users;
using Community.Clients.Keycloak.Services.Auth;
using Community.Dtos.Pagination.Models;
using Community.Dtos.Pagination.Services;
using System.Net;
using System.Linq;
using AutoMapper;
using System.Threading.Tasks;

namespace Community.Clients.Keycloak.Services.Users
{
    public class KeycloakUsersService : IKeycloakUsersService
    {
        private ITokenService _tokenService;

        private readonly IMapper _mapper;
        private string KEYCLOAK_HOST;
        private string KEYCLOAK_REALM;


        public KeycloakUsersService(ITokenService tokenService, IMapper mapper)
        {
            _tokenService = tokenService;
            _mapper = mapper;
            KEYCLOAK_HOST = Environment.GetEnvironmentVariable("KEYCLOAK_HOST");
            KEYCLOAK_REALM = Environment.GetEnvironmentVariable("KEYCLOAK_REALM");
        }

        public KeycloakUserViewRequest CreateUser(KeycloakUserCreateRequest user)
        {
            Token token = _tokenService.GetToken();

            var usersUrl = "/auth/admin/realms/" + KEYCLOAK_REALM + "/users";

            var client = new RestClient(KEYCLOAK_HOST + usersUrl);
            client.AddDefaultHeader("Authorization", "Bearer " + token.AccessToken);
            client.Timeout = -1;
            var request = new RestRequest(Method.POST);
            request.AddJsonBody(JsonSerializer.Serialize(user));
            IRestResponse restResponse = client.Execute(request);

            KeycloakUserViewRequest userCreated = _mapper.Map<KeycloakUserCreateRequest, KeycloakUserViewRequest>(user);

            if (restResponse.Headers.Any(t => t.Name == "Location"))
            {
                string location =
                    restResponse.Headers.FirstOrDefault(t => t.Name == "Location").Value.ToString();
                userCreated.Id = new Guid(location.Replace(KEYCLOAK_HOST + usersUrl + "/", String.Empty));
                return userCreated;
            }
            return null;
        }
        public KeycloakUserViewRequest ReadUser(Guid id)
        {
            Token token = _tokenService.GetToken();

            var usersUrl = "/auth/admin/realms/" + KEYCLOAK_REALM + "/users/" + id;

            var client = new RestClient(KEYCLOAK_HOST + usersUrl);
            client.AddDefaultHeader("Authorization", "Bearer " + token.AccessToken);
            client.Timeout = -1;
            var request = new RestRequest(Method.GET);
            IRestResponse restResponse = client.Execute(request);

            if (restResponse.StatusCode == HttpStatusCode.NotFound)
            {
                return null;
            }

            KeycloakUserViewRequest user = JsonSerializer.Deserialize<KeycloakUserViewRequest>(restResponse.Content);
            return user;
        }
        public KeycloakUserViewRequest UpdateUser(KeycloakUserUpdateRequest user)
        {
            Token token = _tokenService.GetToken();

            var usersUrl = "/auth/admin/realms/" + KEYCLOAK_REALM + "/users/" + user.Id;

            var client = new RestClient(KEYCLOAK_HOST + usersUrl);
            client.AddDefaultHeader("Authorization", "Bearer " + token.AccessToken);
            client.Timeout = -1;
            var request = new RestRequest(Method.PUT);
            request.AddJsonBody(JsonSerializer.Serialize(user));
            IRestResponse restResponse = client.Execute(request);

            KeycloakUserViewRequest userUpdated = _mapper.Map<KeycloakUserUpdateRequest, KeycloakUserViewRequest>(user);

            if(!restResponse.IsSuccessful)
                throw new Exception(restResponse.Content);

            if (restResponse.Headers.Any(t => t.Name == "Location"))
            {
                return userUpdated;
            }
            return null;
        }

        public void DeleteUser(Guid id)
        {
            Token token = _tokenService.GetToken();

            var usersUrl = "/auth/admin/realms/" + KEYCLOAK_REALM + "/users/" + id;

            var client = new RestClient(KEYCLOAK_HOST + usersUrl);
            client.AddDefaultHeader("Authorization", "Bearer " + token.AccessToken);
            client.Timeout = -1;
            var request = new RestRequest(Method.DELETE);
            IRestResponse restResponse = client.Execute(request);

            if(!restResponse.IsSuccessful)
                throw new Exception(restResponse.Content);

        }

        public List<KeycloakUserViewRequest> Search(Paginator paginator, Sorter sorter, KeycloakUsersSearchRequest searchRequest, IUriService uriService, string route)
        {
            Token token = _tokenService.GetToken();

            var usersUrl = "/auth/admin/realms/" + KEYCLOAK_REALM + "/users";

            var client = new RestClient(KEYCLOAK_HOST + usersUrl);
            client.AddDefaultHeader("Authorization", "Bearer " + token.AccessToken);
            client.Timeout = -1;
            var request = new RestRequest(Method.GET);

            if (!string.IsNullOrEmpty(searchRequest.Email))
            {
                request.AddQueryParameter("email", searchRequest.Email);
            }
            if (searchRequest.EmailVerified != null)
            {
                request.AddQueryParameter("emailVerified", searchRequest.EmailVerified.ToString());
            }
            if (!string.IsNullOrEmpty(searchRequest.FirstName))
            {
                request.AddQueryParameter("firstName", searchRequest.FirstName);
            }
            if (!string.IsNullOrEmpty(searchRequest.LastName))
            {
                request.AddQueryParameter("lastName", searchRequest.LastName);
            }
            if (!string.IsNullOrEmpty(searchRequest.Username))
            {
                request.AddQueryParameter("username", searchRequest.Username);
            }

            var index = paginator.PageNumber;

            if (index > 1)
            {
                index = (index - 1) * paginator.PageSize;
            }

            int offset = index - 1;
            request.AddQueryParameter("first", offset.ToString());
            request.AddQueryParameter("max", paginator.PageSize.ToString());

            IRestResponse restResponse = client.Execute(request);

            List<KeycloakUserViewRequest> users = JsonSerializer.Deserialize<List<KeycloakUserViewRequest>>(restResponse.Content);

            return users;
        }

        public int Count(KeycloakUsersSearchRequest searchRequest)
        {
            Token token = _tokenService.GetToken();

            var rolesUrl = "/auth/admin/realms/" + KEYCLOAK_REALM + "/users/count";

            var client = new RestClient(KEYCLOAK_HOST + rolesUrl);
            client.AddDefaultHeader("Authorization", "Bearer " + token.AccessToken);
            client.Timeout = -1;
            var request = new RestRequest(Method.GET);

            if (!string.IsNullOrEmpty(searchRequest.Email))
            {
                request.AddQueryParameter("email", searchRequest.Email);
            }
            if (searchRequest.EmailVerified != null)
            {
                request.AddQueryParameter("emailVerified", searchRequest.EmailVerified.ToString());
            }
            if (!string.IsNullOrEmpty(searchRequest.FirstName))
            {
                request.AddQueryParameter("firstName", searchRequest.FirstName);
            }
            if (!string.IsNullOrEmpty(searchRequest.LastName))
            {
                request.AddQueryParameter("lastName", searchRequest.LastName);
            }
            if (!string.IsNullOrEmpty(searchRequest.Username))
            {
                request.AddQueryParameter("username", searchRequest.Username);
            }

            IRestResponse restResponse = client.Execute(request);

            var count = JsonSerializer.Deserialize<int>(restResponse.Content);

            return count;
        }

        public void AddRolToUser(Guid usuarioId, Guid groupId)
        {
            Token token = _tokenService.GetToken();

            var usersUrl = "/auth/admin/realms/" + KEYCLOAK_REALM + "/users/" + usuarioId + "/groups/" + groupId;

            var client = new RestClient(KEYCLOAK_HOST + usersUrl);
            client.AddDefaultHeader("Authorization", "Bearer " + token.AccessToken);
            client.Timeout = -1;
            var request = new RestRequest(Method.PUT);
            IRestResponse restResponse = client.Execute(request);
        }

        public void RemoveRolToUser(Guid usuarioId, Guid groupId)
        {
            Token token = _tokenService.GetToken();

            var usersUrl = "/auth/admin/realms/" + KEYCLOAK_REALM + "/users/" + usuarioId + "/groups/" + groupId;

            var client = new RestClient(KEYCLOAK_HOST + usersUrl);
            client.AddDefaultHeader("Authorization", "Bearer " + token.AccessToken);
            client.Timeout = -1;
            var request = new RestRequest(Method.DELETE);
            IRestResponse restResponse = client.Execute(request);

        }

        public KeycloakUserViewRequest RegisterUser(KeycloakUserCreateRequest user)
        {
            try
            {
                Token token = _tokenService.GetToken();

                //1. Crear usuario KEYCLOAK
                var usersUrl = "/auth/admin/realms/" + KEYCLOAK_REALM + "/users";
                var client = new RestClient(KEYCLOAK_HOST + usersUrl);
                client.AddDefaultHeader("Authorization", "Bearer " + token.AccessToken);
                client.Timeout = -1;
                var request = new RestRequest(Method.POST);
                request.AddJsonBody(JsonSerializer.Serialize(user));
                IRestResponse restResponse = client.Execute(request);

                KeycloakUserViewRequest userCreated = _mapper.Map<KeycloakUserCreateRequest, KeycloakUserViewRequest>(user);

                if (restResponse.Headers.Any(t => t.Name == "Location"))
                {
                    string location =
                        restResponse.Headers.FirstOrDefault(t => t.Name == "Location").Value.ToString();
                    userCreated.Id = new Guid(location.Replace(KEYCLOAK_HOST + usersUrl + "/", String.Empty));
                }
                
                if(!restResponse.IsSuccessful)
                    throw new Exception(restResponse.Content);
                    
                    //2. Enviar email
                var sendValidationMailUrl = usersUrl + '/' + userCreated.Id + "/send-verify-email";
                client = new RestClient(KEYCLOAK_HOST + sendValidationMailUrl);
                    client.AddDefaultHeader("Authorization", "Bearer " + token.AccessToken);
                client.Timeout = -1;
                request = new RestRequest(Method.PUT);
                restResponse = client.Execute(request);

                 if(!restResponse.IsSuccessful)
                    throw new Exception(restResponse.Content);
          
                //3. Set password
                var resetPasswordUrl = usersUrl + '/' + userCreated.Id + "/reset-password";
                client = new RestClient(KEYCLOAK_HOST + resetPasswordUrl);
                client.AddDefaultHeader("Authorization", "Bearer " + token.AccessToken);
                client.Timeout = -1;
                KeycloakPasswordUpdateRequest password = new KeycloakPasswordUpdateRequest();
                password.Type = "password";
                password.Value = user.Password;
                password.Temporary = false;
                request = new RestRequest(Method.PUT);
                request.AddJsonBody(JsonSerializer.Serialize(password));
                restResponse = client.Execute(request);

                 if(!restResponse.IsSuccessful)
                    throw new Exception(restResponse.Content);
                 
                return userCreated;
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
          
        }

        public bool UpdatePassword(Guid id, KeycloakPasswordUpdateRequest password)
        {
            Token token = _tokenService.GetToken();

            var usersUrl = "/auth/admin/realms/" + KEYCLOAK_REALM + "/users";

            var resetPasswordUrl = usersUrl + '/' + id + "/reset-password";
            var client = new RestClient(KEYCLOAK_HOST + resetPasswordUrl);
            client.AddDefaultHeader("Authorization", "Bearer " + token.AccessToken);
            client.Timeout = -1;
      
            var request = new RestRequest(Method.PUT);
            request.AddJsonBody(JsonSerializer.Serialize(password));
            IRestResponse restResponse = client.Execute(request);

            if(!restResponse.IsSuccessful)
                throw new Exception(restResponse.Content);

            return true;
        }

    }
}
