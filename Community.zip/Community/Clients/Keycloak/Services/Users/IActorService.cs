//using api.Models.Usuarios;
using System;
using Microsoft.AspNetCore.Http;

namespace Application.Clients.Keycloak.Services.Users
{
    public interface IActorService
    {
         public Guid GetActor ();
    }
}