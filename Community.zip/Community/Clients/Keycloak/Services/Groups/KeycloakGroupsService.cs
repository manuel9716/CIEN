using System;
using System.Collections.Generic;
using System.Text.Json;
using System.Threading.Tasks;
using RestSharp;
using Community.Clients.Keycloak.Dtos;
using Community.Clients.Keycloak.Dtos.Groups;
using Community.Clients.Keycloak.Services.Auth;
using RestSharp.Serializers.NewtonsoftJson;
using System.Linq;

namespace Community.Clients.Keycloak.Services.Groups
{
    public class KeycloakGroupsService : IKeycloakGroupsService
    {
        private ITokenService _tokenService;
        private string KEYCLOAK_HOST;
        private string KEYCLOAK_REALM;
        private string KEYCLOAK_ADMIN_CLIENT_ID;


        public KeycloakGroupsService(ITokenService tokenService)
        {
            _tokenService = tokenService;
            KEYCLOAK_HOST = Environment.GetEnvironmentVariable("KEYCLOAK_HOST");
            KEYCLOAK_REALM = Environment.GetEnvironmentVariable("KEYCLOAK_REALM");
            KEYCLOAK_ADMIN_CLIENT_ID = Environment.GetEnvironmentVariable("KEYCLOAK_ADMIN_CLIENT_ID");
        }

        public KeycloakGroupViewRequest CreateGroup(KeycloakGroupCreateRequest group)
        {
            Token token = _tokenService.GetToken();

            var groupsUrl = "/auth/admin/realms/" + KEYCLOAK_REALM + "/groups";

            var client = new RestClient(KEYCLOAK_HOST + groupsUrl);
            client.AddDefaultHeader("Authorization", "Bearer " + token.AccessToken);
            client.UseNewtonsoftJson();
            client.Timeout = -1;
            var request = new RestRequest(Method.POST);
            request.AddJsonBody(group);
            IRestResponse restResponse = client.Execute(request);

            if (restResponse.Headers.Any(t => t.Name == "Location"))
            {
                string location =
                    restResponse.Headers.FirstOrDefault(t => t.Name == "Location").Value.ToString();
                KeycloakGroupViewRequest groupCreated = new KeycloakGroupViewRequest();

                groupCreated.Id = new Guid(location.Replace(KEYCLOAK_HOST + groupsUrl + "/", String.Empty));
                groupCreated.Name = group.Name;
                return groupCreated;
            }

            return null;
        }

        public KeycloakGroupViewRequest ReadGroup(Guid id)
        {
            Token token = _tokenService.GetToken();

            var groupsUrl = "/auth/admin/realms/" + KEYCLOAK_REALM + "/groups/" + id;

            var client = new RestClient(KEYCLOAK_HOST + groupsUrl);
            client.AddDefaultHeader("Authorization", "Bearer " + token.AccessToken);
            client.UseNewtonsoftJson();
            client.Timeout = -1;
            var request = new RestRequest(Method.GET);
            IRestResponse restResponse = client.Execute(request);

            KeycloakGroupViewRequest group = JsonSerializer.Deserialize<KeycloakGroupViewRequest>(restResponse.Content);
            return group;

        }
        public void DeleteGroup(Guid groupId)
        {
            Token token = _tokenService.GetToken();

            var groupsUrl = "/auth/admin/realms/" + KEYCLOAK_REALM + "/groups/" + groupId;

            var client = new RestClient(KEYCLOAK_HOST + groupsUrl);
            client.AddDefaultHeader("Authorization", "Bearer " + token.AccessToken);
            client.UseNewtonsoftJson();
            client.Timeout = -1;
            var request = new RestRequest(Method.DELETE);
            IRestResponse restResponse = client.Execute(request);
        }
        public KeycloakGroupViewRequest UpdateGroup(KeycloakGroupUpdateRequest group)
        {
            Token token = _tokenService.GetToken();

            var groupsUrl = "/auth/admin/realms/" + KEYCLOAK_REALM + "/groups/" + group.Id;

            var client = new RestClient(KEYCLOAK_HOST + groupsUrl);
            client.AddDefaultHeader("Authorization", "Bearer " + token.AccessToken);
            client.UseNewtonsoftJson();
            client.Timeout = -1;
            var request = new RestRequest(Method.PUT);
            request.AddJsonBody(group);
            IRestResponse restResponse = client.Execute(request);

            if (restResponse.Headers.Any(t => t.Name == "Location"))
            {
                string location =
                    restResponse.Headers.FirstOrDefault(t => t.Name == "Location").Value.ToString();
                KeycloakGroupViewRequest groupCreated = new KeycloakGroupViewRequest();

                groupCreated.Id = new Guid(location.Replace(KEYCLOAK_HOST + groupsUrl + "/", String.Empty));
                groupCreated.Name = group.Name;
                return groupCreated;
            }

            return null;
        }

        public List<KeycloakGroupViewRequest> GetAll()
        {
            Token token = _tokenService.GetToken();

            var groupsUrl = "/auth/admin/realms/" + KEYCLOAK_REALM + "/groups";

            var client = new RestClient(KEYCLOAK_HOST + groupsUrl);
            client.AddDefaultHeader("Authorization", "Bearer " + token.AccessToken);
            client.Timeout = -1;
            var request = new RestRequest(Method.GET);
            IRestResponse restResponse = client.Execute(request);

            List<KeycloakGroupViewRequest> groups = JsonSerializer.Deserialize<List<KeycloakGroupViewRequest>>(restResponse.Content);

            return groups;
        }

        public List<KeycloakGroupViewRequest> GetByUserId(Guid userId)
        {
            Token token = _tokenService.GetToken();

            var groupsUrl = "/auth/admin/realms/" + KEYCLOAK_REALM + "/users/" + userId + "/groups";

            var client = new RestClient(KEYCLOAK_HOST + groupsUrl);
            client.AddDefaultHeader("Authorization", "Bearer " + token.AccessToken);
            client.Timeout = -1;
            var request = new RestRequest(Method.GET);
            IRestResponse restResponse = client.Execute(request);

            List<KeycloakGroupViewRequest> groups = JsonSerializer.Deserialize<List<KeycloakGroupViewRequest>>(restResponse.Content);

            return groups;
        }
    }
}
