using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using Community.Clients.Keycloak.Dtos.Groups;

namespace Community.Clients.Keycloak.Services.Groups
{
    public interface IKeycloakGroupsService
    {
        KeycloakGroupViewRequest CreateGroup(KeycloakGroupCreateRequest group);
        KeycloakGroupViewRequest ReadGroup(Guid id);
        KeycloakGroupViewRequest UpdateGroup(KeycloakGroupUpdateRequest group);
        void DeleteGroup(Guid groupId);
        List<KeycloakGroupViewRequest> GetAll();

        List<KeycloakGroupViewRequest> GetByUserId (Guid userId);
    }
}
