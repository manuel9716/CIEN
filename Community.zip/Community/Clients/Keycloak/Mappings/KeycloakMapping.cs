using Community.Clients.Keycloak.Dtos.Users;
using AutoMapper;

namespace Community.Clients.Keycloak.Mappings
{
    public class KeycloakMapping : Profile
    {
        public KeycloakMapping (){
            CreateMap<KeycloakUserUpdateRequest, KeycloakUserViewRequest> ().ReverseMap();
            CreateMap<KeycloakUserCreateRequest, KeycloakUserViewRequest>() ;
        }
    }
}
