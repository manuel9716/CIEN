﻿using Community.Dtos.AppUsers.Models;
using Community.Dtos.ChatBot.Models;
using Community.Dtos.Cocrea.Models.Preguntas;
using Community.Dtos.Pagination.Models;
using System;
using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;

namespace Community.Services.ChatBot
{
    public interface IChatBotServices
    {
        Task<List<ReadMensajeChatBot>> GetMensajesChatBot(string llave, string email);

        Task<ReadProfileAppUser> ValidarCorreo(string email);

    }
}
