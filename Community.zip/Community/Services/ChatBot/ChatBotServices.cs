﻿using AutoMapper;
using Community.Dtos.AppUsers.Models;
using Community.Dtos.ChatBot.Models;
using Community.Dtos.ListasItem.Models;
using Community.Dtos.Pagination.Models;
using Community.Models;
using Community.Models.ChatBot;
using Community.Repositories.ChatBot;
using System;
using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;


namespace Community.Services.ChatBot
{
    public class ChatBotServices : IChatBotServices
    {
        private IChatBotRepository _repository;
        private IMapper _mapper;

        public ChatBotServices(IChatBotRepository repository, IMapper mapper)
        {
            _repository = repository;
            _mapper = mapper;
        }

        public async Task<List<ReadMensajeChatBot>> GetMensajesChatBot(string llave, string email)
        {
            List<MensajeChatbot> entities = await _repository.GetMensajesChatBot(llave,email);
            var dtos = _mapper.Map<List<MensajeChatbot>, List<ReadMensajeChatBot>>(entities);
            return dtos;
        }



        public async Task<ReadProfileAppUser> ValidarCorreo(string email)
        {
            AppUser entity = await _repository.Read(email);
            var dto = _mapper.Map<AppUser, ReadProfileAppUser>(entity);
            return dto;
        }
    }
}
