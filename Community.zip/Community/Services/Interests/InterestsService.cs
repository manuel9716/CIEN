﻿using AutoMapper;
using System;
using System.Threading;
using System.Threading.Tasks;
using Community.Dtos.Interests.Models;
using Community.Repositories.Interests;
using Community.Models.interests;
using Community.Clients.Keycloak.Services.Users;
using System.Collections.Generic;

namespace Community.Services.Interests
{
    public class InterestsService : IInterestsService
    {
        private readonly IInterestsRepository _repository;
        private readonly IKeycloakUsersService _keycloakService;
        private readonly IMapper _mapper;

        public InterestsService(IInterestsRepository repository, IKeycloakUsersService keycloakService, IMapper mapper)
        {
            _repository = repository;
            _keycloakService = keycloakService;
            _mapper = mapper;
        }

        public async Task<ReadInterests> Read(Guid id, CancellationToken cancellationToken)
        {
            Interest entity = await _repository.Read(id, cancellationToken);
            var dto = _mapper.Map<Interest, ReadInterests>(entity);
            return dto;
        }

        public async Task<List<ReadInterests>> GetbyUserId(Guid AppUserId, CancellationToken cancellationToken)
        {
            List<Interest> entities = await _repository.GetbyUserId(AppUserId, cancellationToken);
            var dtos = _mapper.Map<List<Interest>, List<ReadInterests>>(entities);
            return dtos;
        }

        public async Task<List<ReadInterestsUserId>> GetInterestsbyUserId(Guid Id ,CancellationToken cancellationToken)
        {
            List<Interest> entities = await _repository.GetInterestsbyUserId(Id, cancellationToken);
            var dtos = _mapper.Map<List<Interest>, List<ReadInterestsUserId>>(entities);
            return dtos;
        }
    }
}
