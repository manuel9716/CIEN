﻿using System;
using System.Threading;
using System.Threading.Tasks;
using Community.Dtos.Pagination.Models;
using Community.Dtos.Pagination.Services;
using Community.Dtos.AppUsers.Models;
using Community.Models.interests;
using Community.Dtos.Interests.Models;
using System.Collections.Generic;

namespace Community.Services.Interests
{
    public interface IInterestsService
    {
        Task<ReadInterests> Read(Guid id, CancellationToken cancellationToken);
        Task<List<ReadInterests>> GetbyUserId(Guid AppUserId, CancellationToken cancellationToken);
        Task<List<ReadInterestsUserId>> GetInterestsbyUserId(Guid Id, CancellationToken cancellationToken);
    }
}
