﻿using Application.Clients.Keycloak.Services.Users;
using AutoMapper;
using Community.Clients.Keycloak.Services.Users;
using Community.Dtos.Cocrea.Models;
using Community.Dtos.Cocrea.Models.Preguntas;
using Community.Dtos.Metricas.InputModels;
using Community.Dtos.Metricas.Models.Herramientas;
using Community.Dtos.Pagination.Models;
using Community.Repositories.Cocrea;
using Community.Repositories.Metricas;
using System.Threading.Tasks;

namespace Community.Services.Metricas
{
    public class MetricasServices  : IMetricasServices
    {
        private readonly IMetricasRepository _repository;
        private readonly IKeycloakUsersService _keycloakService;
        private readonly IMapper _mapper;
        private readonly IActorService _actorService;
        public MetricasServices(IMetricasRepository repository, IKeycloakUsersService keycloakService, IMapper mapper, IActorService actorService)
        {
            _repository = repository;
            _keycloakService = keycloakService;
            _mapper = mapper;
            _actorService = actorService;
        }

        public ResponseModels InsertLoginUser(InputLoginUsersModels Dta)
        {
            var GetResponse =  _repository.InsertLoginUser(Dta);
            return GetResponse;
        }

        public ResponseModels InsertVisitaModuloprueba(inputModuloPruebaModels Dta) {
            var GetResponse = _repository.InsertVisitaModuloprueba(Dta);
            return GetResponse;
        }
    }
}
