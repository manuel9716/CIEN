﻿using Community.Dtos.Cocrea.Models;
using Community.Dtos.Metricas.InputModels;
using Community.Dtos.Metricas.Models.Herramientas;
using System.Threading.Tasks;

namespace Community.Services.Metricas
{
    public interface IMetricasServices
    {
        ResponseModels InsertLoginUser(InputLoginUsersModels Dta);
        ResponseModels InsertVisitaModuloprueba(inputModuloPruebaModels Dta);

    }
}
