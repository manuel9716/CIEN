using AutoMapper;
using System;
using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;
using Community.Dtos.AppUsers.Models;
using Community.Clients.Keycloak.Services.Users;
using Community.Clients.Keycloak.Dtos.Users;
using Community.Dtos.Pagination.Models;
using Community.Dtos.Pagination.Services;
using Community.Dtos.Pagination.Helpers;
using Community.Repositories.AppUsers;
using Community.Models.project;
using Community.Models.interests;
using Community.Dtos.ListasItem.Models;
using Community.Repositories.Contactos;
using Community.Dtos.Contactos.Models;
using Community.Models.contactos;


namespace Community.Services.Contactos
{
    public class ContactoService : IContactoService
    {
        private readonly IContactoRepository _repository;
        private readonly IMapper _mapper;
        public ContactoService(IContactoRepository repository, IKeycloakUsersService keycloakService, IMapper mapper)
        {
            _repository = repository;
            _mapper = mapper;
        }
        public async Task<ReadContacto> Create(CreateContacto createRequest, CancellationToken cancellationToken)
        {
            Contacto entity = _mapper.Map<CreateContacto, Contacto>(createRequest);
            entity = await _repository.Create(entity, cancellationToken);
            ReadContacto dto = _mapper.Map<Contacto, ReadContacto>(entity);
            return dto;
        }
    }
}
