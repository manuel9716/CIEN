using System;
using System.Threading;
using System.Threading.Tasks;
using Community.Dtos.Pagination.Models;
using Community.Dtos.Pagination.Services;
using Community.Dtos.AppUsers.Models;
using System.Collections.Generic;
using Community.Dtos.Contactos.Models;

namespace Community.Services.Contactos
{
    public interface IContactoService
    {
        Task<ReadContacto> Create(CreateContacto createRequest, CancellationToken cancellationToken);

        
    }
}
