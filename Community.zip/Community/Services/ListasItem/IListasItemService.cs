using System;
using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;
using Community.Dtos.ListasItem.Models;
using Community.Dtos.Pagination.Models;
using Community.Dtos.Pagination.Services;

namespace Community.Services.ListasItem
{
    public interface IListasItemService
    {
        Task<ReadListaItem> Create(CreateListaItem createRequest, CancellationToken cancellationToken);
        Task<ReadListaItem> Read(Guid id, CancellationToken cancellationToken);
        Task<ReadListaItem> Update(UpdateListaItem updateRequest, CancellationToken cancellationToken);
        Task Delete(Guid id, CancellationToken cancellationToken);
        Task<Paged<ReadListaItem>> Search(Paginator paginator, Sorter sorter, SearchListaItem searchRequest, IUriService uriService, string route, CancellationToken cancellationToken);
        Task<List<ReadListaItem>> GetItemsByCodigoPadre(string codigoPadre, CancellationToken cancellationToken);
        Task<List<ReadListaItemRespuestaEtiqueta>> GetItemsByCodigoPregunta(string codigoPregunta, CancellationToken cancellationToken);
        Task<List<ReadListaItem>> GetItemsByPadreId(Guid padreId, CancellationToken cancellationToken);
    }
}
