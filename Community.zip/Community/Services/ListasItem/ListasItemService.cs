using System;
using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;
using Community.Dtos.ListasItem.Models;
using Community.Dtos.Pagination.Helpers;
using Community.Dtos.Pagination.Models;
using Community.Dtos.Pagination.Services;
using Community.Models;
using Community.Repositories.ListasItem;
using AutoMapper;

namespace Community.Services.ListasItem
{
    public class ListasItemService : IListasItemService
    {
        private readonly IListasItemRepository _repository;
        private readonly IMapper _mapper;

        public ListasItemService(IListasItemRepository repository, IMapper mapper)
        {
            _repository = repository;
            _mapper = mapper;
        }

        public async Task<ReadListaItem> Create(CreateListaItem createRequest, CancellationToken cancellationToken)
        {
            ListaItem entity = _mapper.Map<CreateListaItem, ListaItem>(createRequest);
            entity = await _repository.Create(entity, cancellationToken);
            ReadListaItem dto = _mapper.Map<ListaItem, ReadListaItem>(entity);
            return dto;
        }
        public async Task<ReadListaItem> Read(Guid id, CancellationToken cancellationToken)
        {
            ListaItem entity = await _repository.Read(id, cancellationToken);
            var dto = _mapper.Map<ListaItem, ReadListaItem>(entity);
            return dto;
        }
        public async Task<ReadListaItem> Update(UpdateListaItem updateRequest, CancellationToken cancellationToken)
        {
            ListaItem entity = await _repository.Read(updateRequest.Id, cancellationToken);
            entity = _mapper.Map<UpdateListaItem, ListaItem>(updateRequest, entity);
            entity = await _repository.Update(entity, cancellationToken);
            ReadListaItem dto = _mapper.Map<ListaItem, ReadListaItem>(entity);
            return dto;
        }

        public async Task Delete(Guid id, CancellationToken cancellationToken)
        {
            await _repository.Delete(id, cancellationToken);
        }


        public async Task<Paged<ReadListaItem>> Search(Paginator paginator, Sorter sorter, SearchListaItem searchRequest, IUriService uriService, string route, CancellationToken cancellationToken)
        {
            List<ListaItem> entities = await _repository.Search(paginator, sorter, searchRequest, cancellationToken);
            var dtos = _mapper.Map<List<ListaItem>, List<ReadListaItem>>(entities);
            int totalRecords = await _repository.TotalCount(searchRequest, cancellationToken);
            var page = PaginationHelper.CreatePagedReponse<ReadListaItem>(dtos, paginator, totalRecords, uriService, route);

            return page;
        }

        public async Task<List<ReadListaItem>> GetItemsByCodigoPadre(string codigoPadre, CancellationToken cancellationToken)
        {
            List<ListaItem> entities = await _repository.GetItemsByCodigoPadre(codigoPadre);
            var dtos = _mapper.Map<List<ListaItem>, List<ReadListaItem>>(entities);
            return dtos;
        }

        public async Task<List<ReadListaItemRespuestaEtiqueta>> GetItemsByCodigoPregunta(string codigoPregunta, CancellationToken cancellationToken)
        {
            List<ListaItem> entities = await _repository.GetItemsByCodigoPadre(codigoPregunta);
            var dtos = _mapper.Map<List<ListaItem>, List<ReadListaItemRespuestaEtiqueta>>(entities);
            foreach(var dto in dtos){ 
                var entity = await _repository.ReadEtiquetaByRespuesta(dto.Id, cancellationToken);
                var etiquetaDto = _mapper.Map<ListaItem, ReadListaItem>(entity.Etiqueta);
                dto.Etiqueta = etiquetaDto;
            }

            return dtos;
        }

        public async Task<List<ReadListaItem>> GetItemsByPadreId(Guid padreId, CancellationToken cancellationToken)
        {
            List<ListaItem> entities = await _repository.GetItemsByPadreId(padreId);
            var dtos = _mapper.Map<List<ListaItem>, List<ReadListaItem>>(entities);
            return dtos;
        }
    }
}
