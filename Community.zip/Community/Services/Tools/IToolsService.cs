﻿using Community.Dtos.Tools.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace Community.Services.Tools
{
    public interface IToolsService
    {
        Task<ReadTools> Create(CreateTools createRequest, CancellationToken cancellationToken);
        Task<ReadTools> Read(Guid id, CancellationToken cancellationToken);
        Task<ReadTools> Update(UpdateTools updateRequest, CancellationToken cancellationToken);
    }
}
