﻿using AutoMapper;
using System;
using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;
using Community.Dtos.Tools.Models;
using Community.Models;
using Community.Clients.Keycloak.Services.Users;
using Community.Clients.Keycloak.Dtos.Users;
using Community.Dtos.Pagination.Models;
using Community.Dtos.Pagination.Services;
using Community.Dtos.Pagination.Helpers;
using Community.Repositories.Tools;
using Community.Models.tool;
using Application.Clients.Keycloak.Services.Users;
using Community.Repositories.Fases;
using Community.Services.Tareas;
using Community.Services.Equipos;

namespace Community.Services.Tools
{
    public class ToolsService :IToolsService
    {
        private readonly IToolsRepository _repository;
        private readonly IKeycloakUsersService _keycloakService;
        private readonly IActorService _actorService;
        private readonly IFasesRepository _fasesService;
        private readonly ITareasService _tareasService;
        private readonly IEquiposService _equiposService;
        private readonly IMapper _mapper;

        public ToolsService(IToolsRepository repository, 
                            IKeycloakUsersService keycloakService,
                            IActorService actorService,
                            IFasesRepository fasesService,
                            ITareasService tareasService,
                            IEquiposService equiposService,
                            IMapper mapper)
        {
            _repository = repository;
            _keycloakService = keycloakService;
            _actorService = actorService;
            _fasesService = fasesService;
            _tareasService = tareasService;
            _equiposService = equiposService;
            _mapper = mapper;
        }
        public async Task<ReadTools> Create(CreateTools createRequest, CancellationToken cancellationToken)
        {
            Tool entity = _mapper.Map<CreateTools, Tool>(createRequest);
            entity.FechaCreacion = DateTime.Now;
            entity = await _repository.Create(entity, cancellationToken);
            ReadTools dto = _mapper.Map<Tool, ReadTools>(entity);
            return dto;
        }
        public async Task<ReadTools> Read(Guid id, CancellationToken cancellationToken)
        {
            Tool entity = await _repository.Read(id, cancellationToken);
            var dto = _mapper.Map<Tool, ReadTools>(entity);
            return dto;
        }
        public async Task<ReadTools> Update(UpdateTools updateRequest, CancellationToken cancellationToken)
        {
            Tool entity = await _repository.Read(updateRequest.Id, cancellationToken);
            entity = _mapper.Map<UpdateTools, Tool>(updateRequest, entity);
            entity = await _repository.Update(entity, cancellationToken);
            ReadTools dto = _mapper.Map<Tool, ReadTools>(entity);
            return dto;
        }
    }
}
