﻿using Application.Clients.Keycloak.Services.Users;
using AutoMapper;
using Community.Clients.Keycloak.Services.Users;
using Community.Dtos.Tools.Models;
using Community.Models.tool;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using Community.Repositories.Equipos;

namespace Community.Services.Equipos
{
    public class EquiposService : IEquiposService
    {
        private readonly IEquiposRepository _repository;
        private readonly IKeycloakUsersService _keycloakService;
        private readonly IActorService _actorService;
        private readonly IMapper _mapper;

        public EquiposService(IEquiposRepository repository,
                            IKeycloakUsersService keycloakService,
                            IActorService actorService,
                            IMapper mapper)
        {
            _repository = repository;
            _keycloakService = keycloakService;
            _actorService = actorService;
            _mapper = mapper;
        }

        public async Task<ReadToolsEquipos> CreateEquipo(CreateToolsTeams createRequest, CancellationToken cancellationToken)
        {
            ToolTeam entity = _mapper.Map<CreateToolsTeams, ToolTeam>(createRequest);
            entity = await _repository.CreateEquipo(entity, cancellationToken);
            ReadToolsEquipos dto = _mapper.Map<ToolTeam, ReadToolsEquipos>(entity);
            return dto;
        }
    }
}
