﻿using Community.Dtos.Tools.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace Community.Services.Equipos
{
    public interface IEquiposService
    {
        Task<ReadToolsEquipos> CreateEquipo(CreateToolsTeams createRequest, CancellationToken cancellationToken);
    }
}
