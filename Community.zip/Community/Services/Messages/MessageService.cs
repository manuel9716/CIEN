using AutoMapper;
using Community.Dtos.AppUsers.Models;
using Community.Dtos.Messages.Models;
using Community.Dtos.Pagination.Models;
using Community.Models;
using Community.Models.Messages;
using Community.Repositories.Messages;
using System;
using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;

namespace Community.Services.Messages
{
    public class MessageService : IMessageService
    {
        private IMessageRepository _repository;
        private IMapper _mapper;

        public MessageService(IMessageRepository repository, IMapper mapper)
        {
            _repository = repository;
            _mapper = mapper;
        }

        public async Task<List<ReadConversation>> GetConversaciones(Guid AppUserId)
        {
            List<Conversation> entities = await _repository.GetConversaciones(AppUserId);
            var dtos = _mapper.Map<List<Conversation>, List<ReadConversation>>(entities);

            foreach (var item in dtos)
            {
                ConversationUnion idconversacionunion = await _repository.ReadConversacionUnionId(item.Id);

                List<Message> mensajessinleer = await _repository.ReadMensajesSinLeer(idconversacionunion.Id,AppUserId);

                item.Id = idconversacionunion.Id;
                item.NroMensajesSinLeer = mensajessinleer.Count;

                Message ultimoMensaje = await _repository.ReadUltimoMensaje(item.Id);

                if(ultimoMensaje != null)
                {
                    item.ultimoMensaje = ultimoMensaje.Mensaje;
                }
                
            }
            
            return dtos;

        }
        public List<ReadConversation> GetConversacionesSocket(Guid AppUserId)
        {
            List<Conversation> entities = _repository.GetConversacionesSocket(AppUserId);
            var dtos = _mapper.Map<List<Conversation>, List<ReadConversation>>(entities);

            foreach (var item in dtos)
            {

                ConversationUnion idconversacionunion = _repository.ReadConversacionUnionIdSocket(item.Id);

                List<Message> mensajessinleer = _repository.ReadMensajesSinLeerSocket(idconversacionunion.Id, AppUserId);

                item.Id = idconversacionunion.Id;
                item.NroMensajesSinLeer = mensajessinleer.Count;

                Message ultimoMensaje = _repository.ReadUltimoMensajeSocket(item.Id);

                if(ultimoMensaje != null)
                {
                    item.ultimoMensaje = ultimoMensaje.Mensaje;
                }

            }

            return dtos;
        }
        public async Task<List<ReadConversation>> GetConversacionesPorNombre(Guid AppUserId, string nombre)
        {
            List<Conversation> entities = await _repository.GetConversacionesPorNombre(AppUserId,nombre);
            var dtos = _mapper.Map<List<Conversation>, List<ReadConversation>>(entities);
            return dtos;
        }

        public async Task<List<ReadMessage>> GetMensajes(Guid IdConversacion, Paginator paginator)
        {
            List<Message> entities = await _repository.GetMensajes(IdConversacion, paginator);
            var dtos = _mapper.Map<List<Message>, List<ReadMessage>>(entities);

            foreach (var item in dtos)
            {
                var files = await _repository.ReadMensajeFile(item.Id);
                item.Files = new List<ReadMessageFile>();
                foreach (var file in files)
                {

                    var resultadoFile = await _repository.ReadFileId(file.AppFileId);

                    var entityfile = new ReadMessageFile()
                    {
                        Id = file.AppFileId,
                        Path = "api/community/v1/files/download/" + file.AppFileId.ToString(),
                        FileName = resultadoFile.Name,
                        ContentType = resultadoFile.ContentType

                    };

                    item.Files.Add(entityfile);

                }
            }

            return dtos;
        }
        public async Task<List<ReadMessage>> ReadMensajesSinLeer(Guid IdConversacion,Guid AppUserId)
        {
            List<Message> entities = await _repository.ReadMensajesSinLeer(IdConversacion,AppUserId);
            var dtos = _mapper.Map<List<Message>, List<ReadMessage>>(entities);
            return dtos;
        }
        public async Task<ReadMensajesSinLeerUsuario> ReadMensajesSinLeerUsuario(Guid AppUserId)
        {

           var nromensajessinleer = 0;

           List<Conversation> entities = await _repository.GetConversaciones(AppUserId);
            var dtos = _mapper.Map<List<Conversation>, List<ReadConversation>>(entities);

            foreach (var item in dtos)
            {
                ConversationUnion idconversacionunion = await _repository.ReadConversacionUnionId(item.Id);

                List<Message> mensajessinleer = await _repository.ReadMensajesSinLeer(idconversacionunion.Id,AppUserId);

                nromensajessinleer = nromensajessinleer + mensajessinleer.Count;
                
            }

            var result = new ReadMensajesSinLeerUsuario()
            {
                NroMensajesSinLeer = nromensajessinleer
            };
            
            return result;

        }
        public async Task<List<ReadUser>> GetUsuarios(string nombre,CancellationToken cancellationToken)
        {
            List<AppUser> entities = await _repository.GetUsuarios(nombre,cancellationToken);
            var dtos = _mapper.Map<List<AppUser>, List<ReadUser>>(entities);
            return dtos;
        }

        public async Task<ReadConversationUnion> ReadConversacionId(Guid IdConversacion,CancellationToken cancellationToken)
        {
            ConversationUnion entity = await _repository.ReadConversacionId(IdConversacion, cancellationToken);
            var dtos = _mapper.Map<ConversationUnion, ReadConversationUnion>(entity);
            return dtos;
        }
        public async Task<ReadConversation> ReadConversacionReceptor(Guid UserSenderId, Guid UserReceptorId, CancellationToken cancellationToken)
        {
            Conversation entity = await _repository.ReadConversacionReceptor(UserSenderId, UserReceptorId, cancellationToken);
            var dtos = _mapper.Map<Conversation, ReadConversation>(entity);
            return dtos;
        }
        public ReadAppUser ReadUser(Guid id)
        {
            AppUser entity = _repository.ReadUser(id);
            var dto = _mapper.Map<AppUser, ReadAppUser>(entity);
            return dto;
        }
        public ReadMessage UpdateMensajeNoLeido(UpdateMessage updateRequest)
        {
            Message entity = _repository.ReadMensajeId(updateRequest.Id);
            entity = _mapper.Map<UpdateMessage, Message>(updateRequest, entity);
            entity = _repository.UpdateMensajeNoLeido(entity);
            ReadMessage dto = _mapper.Map<Message, ReadMessage>(entity);
            return dto;
        }
        public async Task<ReadConversation> CreateConversacion(CreateConversation createRequest, CancellationToken cancellationToken)
        {
            Conversation entity = _mapper.Map<CreateConversation, Conversation>(createRequest);
            entity = await _repository.CreateConversacion(entity, cancellationToken);
            ReadConversation dto = _mapper.Map<Conversation, ReadConversation>(entity);
            return dto;
        }
        public async Task<ReadConversationUnion> CreateConversacionUnion(CreateConversationUnion createRequest, CancellationToken cancellationToken)
        {
            ConversationUnion entity = _mapper.Map<CreateConversationUnion, ConversationUnion>(createRequest);
            entity = await _repository.CreateConversacionUnion(entity, cancellationToken);
            ReadConversationUnion dto = _mapper.Map<ConversationUnion, ReadConversationUnion>(entity);
            return dto;
        }
        public async Task<ReadMessage> CreateMessage(CreateMessage createRequest, CancellationToken cancellationToken)
        {
            Message entity = _mapper.Map<CreateMessage, Message>(createRequest);
            entity = await _repository.CreateMensaje(entity, cancellationToken);
            ReadMessage dto = _mapper.Map<Message, ReadMessage>(entity);

             //Guardar archivos de los mensajes
            if (createRequest.Files != null)
            {
                if (createRequest.Files.Count > 0)
                {

                    dto.Files = new List<ReadMessageFile>();
                    foreach (var file in createRequest.Files)
                    {
                        var messageFile = new Message_file()
                        {
                            MensajeId = dto.Id,
                            AppFileId = file
                        };

                        var messageFileEntity = await _repository.CreateMensajesFile(messageFile, cancellationToken);

                        var resultadoFile = await _repository.ReadFileId(messageFileEntity.AppFileId);

                        var entityfile = new ReadMessageFile()
                        {
                            Id = messageFileEntity.AppFileId,
                            Path = "api/community/v1/files/download/" + messageFileEntity.AppFileId.ToString(),
                            FileName = resultadoFile.Name,
                            ContentType = resultadoFile.ContentType

                        };

                        dto.Files.Add(entityfile);

                    }

                }
            }
            
            return dto;
        }

     
    }
}
