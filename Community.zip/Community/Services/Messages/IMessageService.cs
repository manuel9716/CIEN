using Community.Dtos.AppUsers.Models;
using Community.Dtos.Messages.Models;
using Community.Dtos.Pagination.Models;
using System;
using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;

namespace Community.Services.Messages
{
    public interface IMessageService
    {
        Task<List<ReadConversation>> GetConversaciones(Guid AppUserId);
        List<ReadConversation> GetConversacionesSocket(Guid AppUserId);
        Task<List<ReadConversation>> GetConversacionesPorNombre(Guid AppUserId, string nombre);
        Task<List<ReadMessage>> GetMensajes(Guid IdConversacion, Paginator paginator);
        Task<List<ReadMessage>> ReadMensajesSinLeer(Guid IdConversacion,Guid AppUserId);
        Task<ReadMensajesSinLeerUsuario> ReadMensajesSinLeerUsuario(Guid AppUserId);
        Task<List<ReadUser>> GetUsuarios(string nombre,CancellationToken cancellationToken);
        Task<ReadConversationUnion> ReadConversacionId(Guid IdConversacion,CancellationToken cancellationToken);
        Task<ReadConversation> ReadConversacionReceptor(Guid UserSenderId, Guid UserReceptorId, CancellationToken cancellationToken);
        ReadAppUser ReadUser(Guid id);
        ReadMessage UpdateMensajeNoLeido(UpdateMessage updateRequest);
        Task<ReadConversation> CreateConversacion(CreateConversation createRequest, CancellationToken cancellationToken);
        Task<ReadConversationUnion> CreateConversacionUnion(CreateConversationUnion createRequest, CancellationToken cancellationToken);
        Task<ReadMessage> CreateMessage(CreateMessage createRequest, CancellationToken cancellationToken);
    }
}

