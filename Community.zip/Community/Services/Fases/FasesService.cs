﻿using Application.Clients.Keycloak.Services.Users;
using AutoMapper;
using Community.Clients.Keycloak.Services.Users;
using Community.Dtos.Tools.Models;
using Community.Models.tool;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using Community.Repositories.Fases;

namespace Community.Services.Fases
{
    public class FasesService :IFasesService
    {
        private readonly IFasesRepository _repository;
        private readonly IKeycloakUsersService _keycloakService;
        private readonly IActorService _actorService;
        private readonly IMapper _mapper;

        public FasesService(IFasesRepository repository,
                            IKeycloakUsersService keycloakService,
                            IActorService actorService,
                            IMapper mapper)
        {
            _repository = repository;
            _keycloakService = keycloakService;
            _actorService = actorService;
            _mapper = mapper;
        }
        public async Task<ReadToolsFases> CreateFase(CreateToolsFases createRequest, CancellationToken cancellationToken)
        {
            ToolFase entity = _mapper.Map<CreateToolsFases, ToolFase>(createRequest);
            entity = await _repository.CreateFase(entity, cancellationToken);
            ReadToolsFases dto = _mapper.Map<ToolFase, ReadToolsFases>(entity);
            return dto;
        }
    }
}
