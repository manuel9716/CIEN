using System;
using System.Threading;
using System.Threading.Tasks;
using Community.Dtos.Pagination.Models;
using Community.Dtos.Pagination.Services;
using Community.Dtos.AppUsers.Models;
using Community.Dtos.Notifications.Models;
using System.Collections.Generic;

namespace Community.Services.Notifications
{
    public interface INotificationService
    {
        Task<ReadNotification> Create(CreateNotification createRequest, CancellationToken cancellationToken);
        Task<ReadNotification> Read(Guid id, CancellationToken cancellationToken);
        Task<List<ReadNotification>> ReadAll(Guid useId, CancellationToken cancellationToken);

        Task<ReadNotification> Update(CreateNotification updateRequest, CancellationToken cancellationToken);

        Task Delete(Guid id, CancellationToken cancellationToken);
        Task<long> Count(Guid id, CancellationToken cancellationToken);
        Task<bool> Reset(Guid id, CancellationToken cancellationToken);



    }
}
