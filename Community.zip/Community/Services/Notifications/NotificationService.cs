using AutoMapper;
using System;
using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;
using Community.Dtos.AppUsers.Models;
using Community.Models;
using Community.Clients.Keycloak.Services.Users;
using Community.Clients.Keycloak.Dtos.Users;
using Community.Dtos.Pagination.Models;
using Community.Dtos.Pagination.Services;
using Community.Dtos.Pagination.Helpers;
using Community.Repositories.AppUsers;
using Community.Repositories.Notifications;
using Community.Services.Notifications;
using Community.Dtos.Notifications.Models;
using Community.Models.notification;
using Application.Clients.Keycloak.Services.Users;
using Community.Repositories.Publications;

namespace Community.Services.Notifications
{
    public class NotificationService : INotificationService
    {
        private readonly INotificationRepository _repository;
        private readonly IActorService _actorService;
        private readonly IPublicationRepository _publicationRepository;

        private readonly IMapper _mapper;
        public NotificationService(INotificationRepository repository, 
                                   IActorService actorService,
                                   IPublicationRepository publicationRepository,
                                   IMapper mapper)
        {
            _repository = repository;
            _actorService = actorService;
            _publicationRepository = publicationRepository;
            _mapper = mapper;
        }

        public async Task<ReadNotification> Create(CreateNotification createRequest, CancellationToken cancellationToken)
        {
            //Usuario origen
            var userOrigenId = _actorService.GetActor();
            createRequest.UserOrigenId = userOrigenId;

            //Usuario destino
            if (createRequest.PublicacionId != null){
                var publication = await _publicationRepository.Read((Guid)createRequest.PublicacionId, cancellationToken);
                createRequest.UserId = (Guid)publication.AppUserId;
            }

            createRequest.IteracionId = null;

            var entity = _mapper.Map<CreateNotification, Notification>(createRequest);
            entity =  _repository.Create(entity, cancellationToken);
            var dto = _mapper.Map<Notification, ReadNotification>(entity);

            return dto;
        }

        public async Task Delete(Guid id, CancellationToken cancellationToken)
        {
            await _repository.Delete(id, cancellationToken);
        }

        public Task<ReadNotification> Read(Guid id, CancellationToken cancellationToken)
        {
            throw new NotImplementedException();
        }

        public async Task<List<ReadNotification>> ReadAll(Guid useId, CancellationToken cancellationToken)
        {
            var entities = await _repository.ReadAll(useId,cancellationToken);
            //var dto = _mapper.Map<List<Notification>, List<ReadNotification>>(entity);
            var dtos = new List<ReadNotification>();
            foreach(var entity in entities){
                var dto = new ReadNotification();
                dto.Id = entity.Id;
                dto.UserId = entity.UserId;
                dto.UserOrigenId = entity.UserOrigenId;
                dto.descripcion = entity.descripcion;
                dto.activa = entity.activa;
                dto.FechaCreacion = entity.FechaCreacion;
                
                var userOrigen = _mapper.Map<AppUser, ReadAppUser>(entity.UserOrigen);
                dto.UserOrigen = userOrigen;

                dtos.Add(dto);
            }
            return dtos;
        }

        public Task<ReadNotification> Update(CreateNotification updateRequest, CancellationToken cancellationToken)
        {
            throw new NotImplementedException();
        }

        public async Task<long> Count(Guid id, CancellationToken cancellationToken)
        {
            return await _repository.TotalCount(id, cancellationToken);
        }

         public async Task<bool> Reset(Guid id, CancellationToken cancellationToken)
        {
            var notificaciones =  await _repository.ReadAllActivas(id, cancellationToken);

            foreach(var notificacion in notificaciones){
                notificacion.activa = false;
                await _repository.Update(notificacion, cancellationToken);
            }

            return true;
        }
    }
}
