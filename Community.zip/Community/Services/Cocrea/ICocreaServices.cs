﻿using Community.Dtos.Cocrea.Models;
using Community.Dtos.Cocrea.Models.inputsModels.Preguntas;
using Community.Dtos.Cocrea.Models.inputsModels.Retos;
using Community.Dtos.Cocrea.Models.Preguntas;
using Community.Dtos.Cocrea.Models.Retos;
using Community.Dtos.Pagination.Models;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Community.Services.Cocrea
{
    public interface ICocreaServices
    {
        Task<CocreaModels> GetListaPreguntas(Paginator paginator);
        Task<CocreaModels> GetListaPreguntasEX(Paginator paginator);
        Task<PreguntaModels> GetPreguntaById(Paginator paginator, Guid Id,bool desc, bool fecha);
        Task<CocreaModels> GetPreguntarandom();
        ResponseModels Insertpregunta(InputPreguntaModels Dta);
        ResponseModels InsertRespPregunta(inputRespuestaModels Dta);
        ResponseModels DeleteRespPregunta(Guid Id);
        ResponseModels UpdateRespPregunta(InputUpdRespuestaModels Dta);
        Task<CocreaComentModels> GetComentarioRespuesta(Paginator paginator, Guid Id);
        ResponseModels InsertComentarRespuesta(InputComRespModels Dta);
        ResponseModels RespuestaLikeDislike(InputLikeDislikeModels Dta);
        Task<RetoAdminModels> GetListaRetos(Paginator paginator);
        ResponseModels Insertreto(RetoModels Dta);
        Task<ParticipanteAdminModels> GetListaParticipantes(Paginator paginator);
        ResponseModels Insertparticipante(ParticipanteModels Dta);
        Task<TemaAdminModels> GetListaTemas(Paginator paginator);
        ResponseModels Inserttema(TemaModels Dta);
        Task<IncentivoRetoAdminModels> GetListaIncentivoRetos(Paginator paginator);
        Task<ResponseModels> IncentivoRetoInsert(IncentivoRetoModels Dta);
        Task<DocumentoRetoAdminModels> GetListaDocumentoRetos(Paginator paginator);
        Task<ResponseModels> DocumentoRetoInsert(DocumentoRetoModels Dta);
        Task<EtapaRetoAdminModels> EtapaRetosListaGet(Paginator paginator);
        Task<ResponseModels> EtapaRetoInsert(EtapaRetoModels Dta);
        Task<EntidadRetoAdminModels> EntidadRetosListaGet(Paginator paginator);
        Task<ResponseModels> EntidadRetoInsert(EntidadRetoModels Dta);
        Task<RetoExtendedModels> GetRetoExById(Guid Id);
        ResponseModels InsertRetoCompleto(InputRetoModels Dta);
        ResponseModels UpdateRetoCompleto(InputUpdRetoModels Dta);

    }
}
