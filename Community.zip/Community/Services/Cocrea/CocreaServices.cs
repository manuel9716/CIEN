﻿using AutoMapper;
using System;
using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;
using Community.Dtos.AppUsers.Models;
using Community.Models;
using Community.Clients.Keycloak.Services.Users;
using Community.Clients.Keycloak.Dtos.Users;
using Community.Dtos.Pagination.Models;
using Community.Dtos.Pagination.Services;
using Community.Dtos.Pagination.Helpers;
using Community.Repositories.AppUsers;
using Community.Models.project;
using Community.Models.interests;
using Community.Dtos.ListasItem.Models;
using Community.Repositories.Cocrea;
using Application.Clients.Keycloak.Services.Users;
using Community.Dtos.Cocrea.Models.Retos;
using Community.Dtos.Cocrea.Models.Preguntas;
using Community.Dtos.Cocrea.Models.inputsModels.Preguntas;
using Community.Dtos.Cocrea.Models;
using Community.Dtos.Cocrea.Models.inputsModels.Retos;
using Community.Models.Cocrea;
using System.Security.Cryptography;

namespace Community.Services.Cocrea
{
    public class CocreaServices : ICocreaServices
    {
        private readonly ICocreaRepository _repository;
        private readonly IKeycloakUsersService _keycloakService;
        private readonly IMapper _mapper;
        private readonly IActorService _actorService;
        public CocreaServices(ICocreaRepository repository, IKeycloakUsersService keycloakService, IMapper mapper, IActorService actorService)
        {
            _repository = repository;
            _keycloakService = keycloakService;
            _mapper = mapper;
            _actorService = actorService;
        }
        #region preguntas

        public async Task<CocreaModels> GetListaPreguntas(Paginator paginator)
        {
            var GetResponse = await _repository.GetListaPreguntas(paginator);
            return GetResponse;
        }

        public async Task<CocreaModels> GetListaPreguntasEX(Paginator paginator)
        {
            var actorId = _actorService.GetActor();
            var GetResponse = await _repository.GetListaPreguntasEX(paginator, actorId);
            return GetResponse;
        }
        public async Task<PreguntaModels> GetPreguntaById(Paginator paginator,Guid Id, bool desc, bool fecha)
        {
            var actorId = _actorService.GetActor();
            var GetResponse = await _repository.GetPreguntaById(paginator,Id, actorId,desc,fecha);
            return GetResponse;
        }
         public async Task<CocreaModels> GetPreguntarandom()
        {
            var GetResponse = await _repository.GetPreguntarandom();
            return GetResponse;
        }
         public ResponseModels Insertpregunta(InputPreguntaModels Dta)
        {
            var actorId = _actorService.GetActor();
            var GetResponse =  _repository.Insertpregunta(Dta, actorId);
            return GetResponse;

        }
       public  ResponseModels InsertRespPregunta(inputRespuestaModels Dta)
        {
            var actorId = _actorService.GetActor();
            var GetResponse = _repository.InsertRespPregunta(Dta, actorId);
            return GetResponse;
        }

        public ResponseModels DeleteRespPregunta(Guid Id)
        {
            var actorId = _actorService.GetActor();
            var GetResponse = _repository.DeleteRespPregunta(Id, actorId);
            return GetResponse;
        }
        public  ResponseModels UpdateRespPregunta(InputUpdRespuestaModels Dta)
        {
            var actorId = _actorService.GetActor();
            var GetResponse = _repository.UpdateRespPregunta(Dta, actorId);
            return GetResponse;
        }
        public async Task<CocreaComentModels> GetComentarioRespuesta(Paginator paginator, Guid Id)
        {
            var GetResponse = await _repository.GetComentarioRespuesta(paginator, Id);
            return GetResponse;
        }
        public ResponseModels InsertComentarRespuesta(InputComRespModels Dta)
        {
            var actorId = _actorService.GetActor();
            var GetResponse = _repository.InsertComentarRespuesta(Dta, actorId);
            return GetResponse;

        }


        public ResponseModels RespuestaLikeDislike(InputLikeDislikeModels Dta)
        {
            var actorId = _actorService.GetActor();
            var GetResponse = _repository.RespuestaLikeDislike(Dta,actorId);
            return GetResponse;

        }



        #endregion
        #region Retos
        #region Reto
        public async Task<RetoAdminModels> GetListaRetos(Paginator paginator)
        {
            var listretos = await _repository.GetListaRetos(paginator);
            return listretos;
        }
        public ResponseModels Insertreto(RetoModels Dta)
        {
            var actorId = _actorService.GetActor();
            Dta.Autor = actorId;
            var Getreto = _repository.Insertreto(Dta);
            return Getreto;
        }
        public async Task<RetoExtendedModels> GetRetoExById(Guid Id)
        {
            var reto = await _repository.GetRetoExById(Id);
            return reto;
        }
        public ResponseModels InsertRetoCompleto(InputRetoModels Dta)
        {
            var actorId = _actorService.GetActor();
            var GetResponse = _repository.InsertRetoCompleto(Dta, actorId);
            return GetResponse;
        }
        public ResponseModels UpdateRetoCompleto(InputUpdRetoModels Dta)
        {
            var actorId = _actorService.GetActor();
            var GetResponse = _repository.UpdateRetoCompleto(Dta, actorId);
            return GetResponse;
        }
        #endregion
        #region Participante
        public async Task<ParticipanteAdminModels> GetListaParticipantes(Paginator paginator)
        {
            var listparticipantes = await _repository.GetListaParticipantes(paginator);
            return listparticipantes;
        }
        public ResponseModels Insertparticipante(ParticipanteModels Dta)
        {
            var Getparticipante = _repository.Insertparticipante(Dta);
            return Getparticipante;
        }
        #endregion
        #region Tema
        public async Task<TemaAdminModels> GetListaTemas(Paginator paginator)
        {
            var listtemas = await _repository.GetListaTemas(paginator);
            return listtemas;
        }
        public ResponseModels Inserttema(TemaModels Dta)
        {
            var Gettema = _repository.Inserttema(Dta);
            return Gettema;
        }
        #endregion
        #region IncentivoReto
        public async Task<IncentivoRetoAdminModels> GetListaIncentivoRetos(Paginator paginator)
        {
            var IncentivoRetoGet = await _repository.GetListaIncentivoRetos(paginator);
            return IncentivoRetoGet;
        }
        public async Task<ResponseModels> IncentivoRetoInsert(IncentivoRetoModels Dta)
        {
            var IncentivoRetoInsert = await _repository.IncentivoRetoInsert(Dta);
            return IncentivoRetoInsert;

        }
        #endregion
        #region DocumentoReto
        public async Task<DocumentoRetoAdminModels> GetListaDocumentoRetos(Paginator paginator)
        {
            var DocumentoRetoGet = await _repository.GetListaDocumentoRetos(paginator);
            return DocumentoRetoGet;
        }
        public async Task<ResponseModels> DocumentoRetoInsert(DocumentoRetoModels Dta)
        {
            var DocumentoRetoInsert = await _repository.DocumentoRetoInsert(Dta);
            return DocumentoRetoInsert;

        }
        #endregion
        #region EtapaReto
        public async Task<EtapaRetoAdminModels> EtapaRetosListaGet(Paginator paginator)
        {
            var EtapaRetoGet = await _repository.EtapaRetosListaGet(paginator);
            return EtapaRetoGet;
        }
        public async Task<ResponseModels> EtapaRetoInsert(EtapaRetoModels Dta)
        {
            var EtapaRetoInsert = await _repository.EtapaRetoInsert(Dta);
            return EtapaRetoInsert;

        }
        #endregion
        #region EntidadReto
        public async Task<EntidadRetoAdminModels> EntidadRetosListaGet(Paginator paginator)
        {
            var EntidadRetoGet = await _repository.EntidadRetosListaGet(paginator);
            return EntidadRetoGet;
        }
        public async Task<ResponseModels> EntidadRetoInsert(EntidadRetoModels Dta)
        {
            var EntidadRetoInsert = await _repository.EntidadRetoInsert(Dta);
            return EntidadRetoInsert;

        }
        #endregion

        #endregion

    }

}
