using System;
using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;
using Community.Dtos.Files.Models;
using Community.Dtos.Pagination.Models;
using Community.Dtos.Pagination.Services;
using Microsoft.AspNetCore.Http;

namespace Community.Services.Files
{
    public interface IFilesService
    {
        List<ReadFile> Create(List<CreateFile> createRequest);
        ReadFile CreateSingle(CreateFile createRequest);
        ReadFile Read(Guid id);
        ReadFile Update(UpdateFile updateRequest);
        void Delete(Guid id);
        Paged<ReadFile> Search(Paginator paginator, Sorter sorter, SearchFile searchRequest, IUriService uriService, string route);
        List<ReadFile> UploadMultipleFiles(List<IFormFile> files);
        ReadFile UploadSingleFile(IFormFile file);

        (string fileType, byte[] archiveData, string archiveName) DownloadFiles(List<ReadFile> filesToDownload);
        (string fileType, byte[] archiveData, string archiveName) DownloadFile(Guid fileId);
        string SizeConverter(long bytes);
    }
}