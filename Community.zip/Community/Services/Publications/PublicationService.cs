using Application.Clients.Keycloak.Services.Users;
using AutoMapper;
using Community.Dtos.AppUsers.Models;
using Community.Dtos.ListasItem.Models;
using Community.Dtos.Notifications.Models;
using Community.Dtos.Pagination.Models;
using Community.Dtos.Publications;
using Community.Dtos.Publications.Models;
using Community.Models;
using Community.Models.publication;
using Community.Repositories.Publications;
using Community.Services.Notifications;
using Community.Dtos.Notifications.Enum;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using Community.Models.notification;

namespace Community.Services.Publications
{
    public class PublicationService : IPublicationService
    {
        private readonly IPublicationRepository _repository;
        private readonly INotificationService _notification;
        private readonly IActorService _actorService;
        private readonly IMapper _mapper;

        public PublicationService(IPublicationRepository repository, 
                                  INotificationService notification,
                                  IActorService actorService,
                                  IMapper mapper)
        {
            _repository = repository;
            _notification = notification;
            _actorService = actorService;
            _mapper = mapper;
        }

        public async Task<List<ReadPublication>> GetPublicaciones(Guid AppUserId,Paginator paginator)
        {

            List<Publication> entities = await _repository.GetPublicaciones(AppUserId, paginator);
            var dtos = _mapper.Map<List<Publication>, List<ReadPublication>>(entities);

            //para ingresar nro de me gusta y nro de hijos en los comentarios de la publicacion
            foreach (var item in dtos)
            {

                if(item.CompartirId != null)
                {

                    var publicacioncompartida = await _repository.GetPublicacionCompartir(Guid.Parse(item.CompartirId));

                    var dtocompartir = _mapper.Map<Publication, ReadPublication>(publicacioncompartida);

                    item.PublicacionCompartida = dtocompartir;

                    var filescompartir = await _repository.ReadPublicacionFile(dtocompartir.Id);
                    dtocompartir.Files = new List<ReadPublicationFile>();
                    foreach (var file in filescompartir)
                    {

                        var resultadoFile = await _repository.ReadFileId(file.AppFileId);

                        var entityfile = new ReadPublicationFile()
                        {
                            Id = file.AppFileId,
                            Path = "api/community/v1/files/download/" + file.AppFileId.ToString(),
                            FileName = resultadoFile.Name,
                            ContentType = resultadoFile.ContentType

                        };

                        dtocompartir.Files.Add(entityfile);

                    }


                }

                var files = await _repository.ReadPublicacionFile(item.Id);
                item.Files = new List<ReadPublicationFile>();
                foreach(var file in files){

                    var resultadoFile = await _repository.ReadFileId(file.AppFileId);

                    var entityfile = new ReadPublicationFile()
                    {
                        Id = file.AppFileId,
                        Path = "api/community/v1/files/download/" + file.AppFileId.ToString(),
                        FileName = resultadoFile.Name,
                        ContentType = resultadoFile.ContentType

                    };

                    item.Files.Add(entityfile);


                }

                foreach (var item2 in item.Publicacioncomentario)
                {

                    List<Iteracion> nromegusta = await _repository.ReadIteracionComentarios(item2.Id);
                    item2.NroMeGusta = nromegusta.Count;

                    List<Comment> nrohijos = await _repository.GetComentarioComentario(item2.Id);

                    if (nrohijos.Count == 0)
                    {
                        item2.TieneComentarios = false;
                    }
                    else
                    {
                        item2.TieneComentarios = true;
                    }
                        
                }

                item.NroMeGusta = (int)entities.Find(y => y.Id == item.Id)?.Publicacioniteracion.Count(z => z.ListaItem.Codigo == "ITEMG");
                item.NroFavoritos = (int)entities.Find(y => y.Id == item.Id)?.Publicacioniteracion.Count(z => z.ListaItem.Codigo == "FV");
                // item.NroComentarios = (int)entities.Find(y => y.Id == item.Id).Publicacioncomentario.Count();

                List<Comment> nrocomentarios = await _repository.ReadComentariosPublicacion(item.Id);
                item.NroComentarios = nrocomentarios.Count();

            }

            // dtos.ForEach(x => x.NroMeGusta = (int)entities.Find(y => y.Id == x.Id)?.Publicacioniteracion.Count(z => z.ListaItem.Codigo == "ITEMG"));
            // dtos.ForEach(x => x.NroFavoritos = (int)entities.Find(y => y.Id == x.Id)?.Publicacioniteracion.Count(z => z.ListaItem.Codigo == "FV"));
            // dtos.ForEach(x => x.NroComentarios = (int)entities.Find(y => y.Id == x.Id)?.Publicacioncomentario.Count());
            
            return dtos;
        }

        public async Task<List<ReadPublication>> GetPublicacion(Guid id)
        {
            List<Publication> entities = await _repository.GetPublicacion(id);
            var dtos = _mapper.Map<List<Publication>, List<ReadPublication>>(entities);
            dtos.ForEach(x => x.NroMeGusta = (int)entities.Find(y => y.Id == x.Id)?.Publicacioniteracion.Count(z => z.ListaItem.Codigo == "ITEMG"));
            dtos.ForEach(x => x.NroFavoritos = (int)entities.Find(y => y.Id == x.Id)?.Publicacioniteracion.Count(z => z.ListaItem.Codigo == "FV"));
            dtos.ForEach(x => x.NroComentarios = (int)entities.Find(y => y.Id == x.Id)?.Publicacioncomentario.Count());
            
            return dtos;
        }
        public async Task<List<ReadPublicationId>> GetPublicacionId(Guid id)
        {
            List<Publication> entities = await _repository.GetPublicacionId(id);
            var dtos = _mapper.Map<List<Publication>, List<ReadPublicationId>>(entities);

            foreach (var item in dtos)
            {
                var files = await _repository.ReadPublicacionFile(item.Id);
                item.Files = new List<ReadPublicationFile>();
                foreach (var file in files)
                {

                    var resultadoFile = await _repository.ReadFileId(file.AppFileId);

                    var entityfile = new ReadPublicationFile()
                    {
                        Id = file.AppFileId,
                        Path = "api/community/v1/files/download/" + file.AppFileId.ToString(),
                        FileName = resultadoFile.Name,
                        ContentType = resultadoFile.ContentType

                    };

                    item.Files.Add(entityfile);

                }

                foreach (var item2 in item.Publicacioncomentario)
                {

                    List<Iteracion> nromegusta = await _repository.ReadIteracionComentarios(item2.Id);
                    item2.NroMeGusta = nromegusta.Count;

                    List<ReadComentComent> comentario = await GetComentarioComentario(item2.Id);

                    item2.Comentariocomentario = new List<ReadComentComent>();

                    foreach (var item3 in comentario)
                    {

                        var entitycomentario = new ReadComentComent()
                        {
                            Id = item3.Id,
                            Descripcion = item3.Descripcion,
                            FechaCreacion = item3.FechaCreacion,
                            FechaActualizacion = item3.FechaActualizacion,
                            Usuario = item3.Usuario,
                            NroMeGusta = item3.NroMeGusta,
                            NroComentarios = item3.NroComentarios,
                            PublicacionId = item3.PublicacionId,
                            Comments = item3.Comments

                        };
                        
                        item2.Comentariocomentario.Add(entitycomentario);

                    }

                }

                item.NroMeGusta = (int)entities.Find(y => y.Id == item.Id)?.Publicacioniteracion.Count(z => z.ListaItem.Codigo == "ITEMG");
                item.NroFavoritos = (int)entities.Find(y => y.Id == item.Id)?.Publicacioniteracion.Count(z => z.ListaItem.Codigo == "FV");
              

                List<Comment> nrocomentarios = await _repository.ReadComentariosPublicacion(item.Id);
                item.NroComentarios = nrocomentarios.Count();

            }

            return dtos;
        }

        public async Task<List<ReadPublication>> GetPublicacionUser(Guid AppUserId,Paginator paginator)
        {
            List<Publication> entities = await _repository.GetPublicacionUser(AppUserId, paginator);
            var dtos = _mapper.Map<List<Publication>, List<ReadPublication>>(entities);
            dtos.ForEach(x => x.NroMeGusta = (int)entities.Find(y => y.Id == x.Id)?.Publicacioniteracion.Count(z => z.ListaItem.Codigo == "ITEMG"));
            dtos.ForEach(x => x.NroFavoritos = (int)entities.Find(y => y.Id == x.Id)?.Publicacioniteracion.Count(z => z.ListaItem.Codigo == "FV"));
            dtos.ForEach(x => x.NroComentarios = (int)entities.Find(y => y.Id == x.Id)?.Publicacioncomentario.Count());            
            
            return dtos;
        }
        public async Task<List<ReadPublication>> GetPublicacionPorId(Guid AppUserId, Paginator paginator)
        {
            List<Publication> entities = await _repository.GetPublicacionUser(AppUserId, paginator);
            var dtos = _mapper.Map<List<Publication>, List<ReadPublication>>(entities);
            dtos.ForEach(x => x.NroMeGusta = (int)entities.Find(y => y.Id == x.Id)?.Publicacioniteracion.Count(z => z.ListaItem.Codigo == "ITEMG"));
            dtos.ForEach(x => x.NroFavoritos = (int)entities.Find(y => y.Id == x.Id)?.Publicacioniteracion.Count(z => z.ListaItem.Codigo == "FV"));
            dtos.ForEach(x => x.NroComentarios = (int)entities.Find(y => y.Id == x.Id)?.Publicacioncomentario.Count());            
            
            return dtos;
        }

        public async Task<List<ReadComentComent>> GetComentarioComentario(Guid id)
        {
             List<Comment> entities = await _repository.GetComentarioComentario(id);


             var readComentComent = new List<ReadComentComent>();
             
             foreach (var item in entities)
             {

                 var coments = _mapper.Map<Comment, ReadComentComent>(item);

                 var comentarios = await _repository.ReadIteracionComentarios(item.Id);

                 coments.NroMeGusta = comentarios.Count();
                 
                //  coments.NroMeGusta = (int)item.Publicacion.Publicacioniteracion.Count(z => z.ListaItem.Codigo == "ITEMG" && z.ComentarioId == item.Id);
                 
                 coments.Comments = await GetComentarioComentario(item.Id);

                 readComentComent.Add(coments);
             }

            //   readComentComent.ForEach(x => x.NroMeGusta = (int)entities.Find(y => y.Id == x.Id)?.Publicacion.Publicacioniteracion.Count(z => z.ListaItem.Codigo == "ITEMG"));
           
                     
            return readComentComent;

        }
        public async Task<List<ReadFavorito>> GetFavoritos(Guid AppUserId,Paginator paginator)
        {
             List<Iteracion> entities = await _repository.GetFavoritos(AppUserId,paginator);
             var dtos = _mapper.Map<List<Iteracion>, List<ReadFavorito>>(entities); 
            return dtos;
        }
        public async Task<List<ReadFavorito>> GetFavorito(Guid AppUserId)
        {
             List<Iteracion> entities = await _repository.GetFavorito(AppUserId);
             var dtos = _mapper.Map<List<Iteracion>, List<ReadFavorito>>(entities); 
            return dtos;
        }

        public async Task<ReadPublication> Create(CreatePublication createRequest, CancellationToken cancellationToken)
        {
            //1.Crear publicacion
            Publication entity = _mapper.Map<CreatePublication, Publication>(createRequest);
            entity = await _repository.Create(entity, cancellationToken);
            ReadPublication dto = _mapper.Map<Publication, ReadPublication>(entity);

             if (createRequest.CompartirId != null)
            {

                var publicacioncompartida = await _repository.GetPublicacionCompartir(Guid.Parse(createRequest.CompartirId));

                var dtocompartir = _mapper.Map<Publication, ReadPublication>(publicacioncompartida);

                dto.PublicacionCompartida = dtocompartir;
                
                var filescompartir = await _repository.ReadPublicacionFile(dtocompartir.Id);
                dtocompartir.Files = new List<ReadPublicationFile>();
                foreach (var file in filescompartir)
                {

                    var resultadoFile = await _repository.ReadFileId(file.AppFileId);

                    var entityfile = new ReadPublicationFile()
                    {
                        Id = file.AppFileId,
                        Path = "api/community/v1/files/download/" + file.AppFileId.ToString(),
                        FileName = resultadoFile.Name,
                        ContentType = resultadoFile.ContentType

                    };

                    dtocompartir.Files.Add(entityfile);

                }


            }

            //2. Guardar archivos
            if(createRequest.Files != null){ 
                if(createRequest.Files.Count > 0){ 

                     dto.Files = new List<ReadPublicationFile>();
                    foreach(var file in createRequest.Files){
                        var publicationFile = new Publication_file(){ 
                            PublicacionId = dto.Id,
                            AppFileId = file
                        };
                        var publicationFileEntity = await _repository.CreatePublicacionFile(publicationFile, cancellationToken);

                        var resultadoFile = await _repository.ReadFileId(publicationFileEntity.AppFileId);

                        var entityfile = new ReadPublicationFile()
                        {
                            Id = publicationFileEntity.AppFileId,
                            Path = "api/community/v1/files/download/" + publicationFileEntity.AppFileId.ToString(),
                            FileName = resultadoFile.Name,
                            ContentType = resultadoFile.ContentType

                        };

                        dto.Files.Add(entityfile);

                    }

                } 
            }

            return dto;
        }

        public async Task<ReadComment> CreateComentariopublicacion(CreateCommentPublication createRequest, CancellationToken cancellationToken)
        {
            Comment entity = _mapper.Map<CreateCommentPublication, Comment>(createRequest);
            entity = await _repository.CreateComentariopublicacion(entity, cancellationToken);
            ReadComment dto = _mapper.Map<Comment, ReadComment>(entity);

            List<Comment> nrocomentarios = await _repository.ReadComentariosPublicacion(dto.PublicacionId);
            dto.NroComentarios = nrocomentarios.Count();

            //***Crear notification
            var createNotification = new CreateNotification(){
                PublicacionId =  createRequest.PublicacionId,
                descripcion = TextoNotificacion.COMENTARIO.GetString()
            };
            var notificacion =  await _notification.Create(createNotification, cancellationToken);
            //**Fin notificación

            return dto;
        }
        public async Task<ReadIteracion> CreateIteracionpublicacion(CreateIteracionPublication createRequest, CancellationToken cancellationToken)
        {
            Iteracion entity = _mapper.Map<CreateIteracionPublication, Iteracion>(createRequest);
            entity = await _repository.CreateIteracionpublicacion(entity, cancellationToken);
            ReadIteracion dto = _mapper.Map<Iteracion, ReadIteracion>(entity);

            //***Crear notification
            var createNotification = new CreateNotification(){
                PublicacionId =  createRequest.PublicacionId,
                descripcion = TextoNotificacion.PUBLICACIONMEGUSTA.GetString()
            };
            var notificacion =  await _notification.Create(createNotification, cancellationToken);
            //**Fin notificación

            return dto;
        }
         public async Task<ReadIteracion> CreateIteracioncomentario(CreateIteracionComment createRequest, CancellationToken cancellationToken)
        {
            Iteracion entity = _mapper.Map<CreateIteracionComment, Iteracion>(createRequest);
            entity = await _repository.CreateIteracionComentario(entity, cancellationToken);
            ReadIteracion dto = _mapper.Map<Iteracion, ReadIteracion>(entity);

            var comentario = await _repository.ReadComentario((Guid)entity.ComentarioId, cancellationToken);
            //***Crear notification
            var createNotification = new CreateNotification(){
                PublicacionId =  comentario.PublicacionId,
                descripcion = TextoNotificacion.COMENTARIOMEGUSTA.GetString()
            };
            
            var notificacion =  await _notification.Create(createNotification, cancellationToken);
            //**Fin notificación
            return dto;
        }
        public async Task<ReadHidePublication> CreatePublicacionOcultar(CreateHidePublication createRequest, CancellationToken cancellationToken)
        {
            Publication_hide entity = _mapper.Map<CreateHidePublication, Publication_hide>(createRequest);
            entity = await _repository.CreatePublicacionOcultar(entity, cancellationToken);
            ReadHidePublication dto = _mapper.Map<Publication_hide, ReadHidePublication>(entity);
            return dto;
        }
          public async Task<ReadReportPublication> CreatePublicacionReportar(CreateReportPublications createRequest, CancellationToken cancellationToken)
        {
            Publication_report entity = _mapper.Map<CreateReportPublications, Publication_report>(createRequest);
            entity = await _repository.CreatePublicacionReportar(entity, cancellationToken);
            ReadReportPublication dto = _mapper.Map<Publication_report, ReadReportPublication>(entity);

            //***Crear notification
            var createNotification = new CreateNotification(){
                PublicacionId =  entity.PublicacionId,
                descripcion = TextoNotificacion.PUBLICACIONREPORTADA.GetString()
            };
            
            var notificacion =  await _notification.Create(createNotification, cancellationToken);
            //**Fin notificación

            return dto;
        }

        public async Task<ReadPublication> Delete(DeletePublication deleteRequest, CancellationToken cancellationToken)
        {
            Publication entity = await _repository.Read(deleteRequest.Id, cancellationToken);
            entity = _mapper.Map<DeletePublication, Publication>(deleteRequest, entity);
            entity = await _repository.Delete(entity, cancellationToken);
            ReadPublication dto = _mapper.Map<Publication, ReadPublication>(entity);
            return dto;
        }

       
        public async Task<ReadPublication> Read(Guid id, CancellationToken cancellationToken)
        {
            Publication entity = await _repository.Read(id, cancellationToken);
            var dto = _mapper.Map<Publication, ReadPublication>(entity);
            return dto;
        }
        public async Task<ReadPublication> ReadPublicacionCompartir(Guid idCompartir, Guid AppUserId)
        {
            Publication entity = await _repository.ReadPublicacionCompartir(idCompartir, AppUserId);
            var dto = _mapper.Map<Publication, ReadPublication>(entity);
            return dto;
        }
        public async Task<ReadComment> ReadComentario(Guid id, CancellationToken cancellationToken)
        {

            Comment entity = await _repository.ReadComentario(id, cancellationToken);
            var dto = _mapper.Map<Comment, ReadComment>(entity);
            return dto;
        }
        public async Task<ReadComment> ReadComentarioUsuario(Guid id, Guid AppUserId, CancellationToken cancellationToken)
        {
            Comment entity = await _repository.ReadComentarioUsuario(id,AppUserId, cancellationToken);
            var dto = _mapper.Map<Comment, ReadComment>(entity);
            return dto;
        }
        public async Task<ReadReportPublication> ReadReportar(Guid idPublicacion, Guid IdUser, CancellationToken cancellationToken)
        {
            Publication_report entity = await _repository.ReadReportar(idPublicacion,IdUser, cancellationToken);
            var dto = _mapper.Map<Publication_report, ReadReportPublication>(entity);
            return dto;
        }

        public async Task<ReadListaItem> ReadListaItemIteracion(string TipoItem, CancellationToken cancellationToken)
        {
            ListaItem entity = await _repository.ReadListaItemIteracion(TipoItem, cancellationToken);
            var dto = _mapper.Map<ListaItem, ReadListaItem>(entity);
            return dto;
        }
        public async Task<List<ReadPublication>> ReadListaItemIteracionIdPublicacion(Guid IdPublicacion)
        {
            List<Publication> entities = await _repository.ReadListaItemIteracionIdPublicacion(IdPublicacion);
            var dtos = _mapper.Map<List<Publication>, List<ReadPublication>>(entities);
            dtos.ForEach(x => x.NroMeGusta = (int)entities.Find(y => y.Id == x.Id)?.Publicacioniteracion.Count(z => z.ListaItem.Codigo == "ITEMG"));
            dtos.ForEach(x => x.NroFavoritos = (int)entities.Find(y => y.Id == x.Id)?.Publicacioniteracion.Count(z => z.ListaItem.Codigo == "FV"));
            
            return dtos;
        }
        public async Task<List<ReadComment>> ReadListaItemIteracionIdComentario(Guid IdComentario)
        {
            List<Comment> entities = await _repository.ReadListaItemIteracionIdComentario(IdComentario);
            var dtos = _mapper.Map<List<Comment>, List<ReadComment>>(entities);
            dtos.ForEach(x => x.NroMeGusta = (int)entities.Find(y => y.Id == x.Id)?.Comentarioiteracion.Count(z => z.ListaItem.Codigo == "ITEMG"));
            // dtos.ForEach(x => x.NroFavoritos = (int)entities.Find(y => y.Id == x.Id)?.Comentarioiteracion.Count(z => z.ListaItem.Codigo == "FV"));
            
            return dtos;
        }


         public async Task<ReadListaItem> ReadListaItem(Guid id, CancellationToken cancellationToken)
        {
            ListaItem entity = await _repository.ReadListaItem(id, cancellationToken);
            var dto = _mapper.Map<ListaItem, ReadListaItem>(entity);
            return dto;
        }

        public async Task<ReadAppUser> ReadUser(Guid id, CancellationToken cancellationToken)
        {
            AppUser entity = await _repository.ReadUser(id, cancellationToken);
            var dto = _mapper.Map<AppUser, ReadAppUser>(entity);
            return dto;
        }
        public async Task<ReadIteracion> ReadIteracionPublicacion(Guid idpublicacion, Guid AppUserId, Guid ListaItemId, CancellationToken cancellationToken)
        {
            Iteracion entity = await _repository.ReadIteracionPublicacion(idpublicacion,AppUserId,ListaItemId,cancellationToken);
            var dto = _mapper.Map<Iteracion, ReadIteracion>(entity);
            return dto;
        }
        public async Task<ReadIteracion> ReadIteracionComentario(Guid idcomentario, Guid AppUserId, Guid ListaItemId, CancellationToken cancellationToken)
        {
            Iteracion entity = await _repository.ReadIteracionComentario(idcomentario,AppUserId,ListaItemId,cancellationToken);
            var dto = _mapper.Map<Iteracion, ReadIteracion>(entity);
            return dto;
        }
        public async Task<ReadFavorito> ReadIteracionFavorito(Guid id, CancellationToken cancellationToken)
        {
           Iteracion entity = await _repository.ReadIteracionFavorito(id, cancellationToken);
           var dto = _mapper.Map<Iteracion, ReadFavorito>(entity);
           return dto;
        }

        public async Task<ReadPublication> Update(UpdatePublication updateRequest, CancellationToken cancellationToken)
        {
            Publication entity = await _repository.Read(updateRequest.Id, cancellationToken);
            entity = _mapper.Map<UpdatePublication, Publication>(updateRequest, entity);
            entity = await _repository.Update(entity, cancellationToken);
            ReadPublication dto = _mapper.Map<Publication, ReadPublication>(entity);

            await _repository.DeletePublicacionFile(entity.Id, cancellationToken);

            //Guardar archivos
            if (updateRequest.Files != null)
            {

                if (updateRequest.Files.Count > 0)
                {

                    dto.Files = new List<ReadPublicationFile>();
                    foreach (var file in updateRequest.Files)
                    {
                        var ofertaFile = new Publication_file()
                        {
                            PublicacionId = dto.Id,
                            AppFileId = file
                        };

                        var ofertaFileEntity = await _repository.CreatePublicacionFile(ofertaFile, cancellationToken);


                        //dto.Files.Add("api/community/v1/files/download/" + ofertaFileEntity.AppFileId.ToString());

                        var resultadoFile = await _repository.ReadFileId(ofertaFileEntity.AppFileId);

                        var entityfile = new ReadPublicationFile()
                        {
                            Id = ofertaFileEntity.AppFileId,
                            Path = "api/community/v1/files/download/" + ofertaFileEntity.AppFileId.ToString(),
                            FileName = resultadoFile.Name,
                            ContentType = resultadoFile.ContentType

                        };

                        dto.Files.Add(entityfile);

                    }

                }
            }

            return dto;
        }

        public async Task DeleteIteracion(Guid id, CancellationToken cancellationToken)
        {
            await _repository.DeleteIteracion(id, cancellationToken);
        }
        public async Task DeleteComentario(Guid id, CancellationToken cancellationToken)
        {
            await _repository.DeleteComentario(id, cancellationToken);
        }

       
    }
}