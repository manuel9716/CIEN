using Community.Dtos.AppUsers.Models;
using Community.Dtos.ListasItem.Models;
using Community.Dtos.Notifications.Models;
using Community.Dtos.Pagination.Models;
using Community.Dtos.Publications;
using Community.Dtos.Publications.Models;
using System;
using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;

namespace Community.Services.Publications
{
    public interface IPublicationService
    {
        Task<List<ReadPublication>> GetPublicaciones(Guid AppUserId,Paginator paginator);
        Task<List<ReadPublication>> GetPublicacion(Guid id);
        Task<List<ReadPublicationId>> GetPublicacionId(Guid id);
        Task<List<ReadPublication>> GetPublicacionUser(Guid AppUserId,Paginator paginator);
        Task<List<ReadPublication>> GetPublicacionPorId(Guid AppUserId,Paginator paginator);
        Task<List<ReadComentComent>> GetComentarioComentario(Guid id);
        Task<List<ReadFavorito>> GetFavoritos(Guid AppUserId,Paginator paginator);       
        Task<List<ReadFavorito>> GetFavorito(Guid AppUserId);  
        Task<ReadPublication> Create(CreatePublication createRequest, CancellationToken cancellationToken);
        Task<ReadComment> CreateComentariopublicacion(CreateCommentPublication createRequest, CancellationToken cancellationToken);
        Task<ReadIteracion> CreateIteracionpublicacion(CreateIteracionPublication createRequest, CancellationToken cancellationToken);
        Task<ReadIteracion> CreateIteracioncomentario(CreateIteracionComment createRequest, CancellationToken cancellationToken);
        Task<ReadHidePublication> CreatePublicacionOcultar(CreateHidePublication createRequest, CancellationToken cancellationToken);
        Task<ReadReportPublication> CreatePublicacionReportar(CreateReportPublications createRequest, CancellationToken cancellationToken);
        Task<ReadPublication> Read(Guid id, CancellationToken cancellationToken);
        Task<ReadPublication> ReadPublicacionCompartir(Guid idCompartir, Guid AppUserId);
        Task<ReadComment> ReadComentario(Guid id, CancellationToken cancellationToken);
        Task<ReadComment> ReadComentarioUsuario(Guid id, Guid AppUserId, CancellationToken cancellationToken);
        Task<ReadReportPublication> ReadReportar(Guid idPublicacion, Guid IdUser, CancellationToken cancellationToken);
        Task<ReadAppUser> ReadUser(Guid id, CancellationToken cancellationToken);
        Task<ReadListaItem> ReadListaItem(Guid id, CancellationToken cancellationToken);
        Task<ReadListaItem> ReadListaItemIteracion(string TipoItem, CancellationToken cancellationToken);
        Task<List<ReadPublication>> ReadListaItemIteracionIdPublicacion(Guid IdPublicacion);
        Task<List<ReadComment>> ReadListaItemIteracionIdComentario(Guid IdComentario);
        Task<ReadIteracion> ReadIteracionPublicacion(Guid idpublicacion, Guid AppUserId, Guid ListaItemId, CancellationToken cancellationToken);
        Task<ReadIteracion> ReadIteracionComentario(Guid idcomentario, Guid AppUserId, Guid ListaItemId, CancellationToken cancellationToken);
        Task<ReadFavorito> ReadIteracionFavorito(Guid id,CancellationToken cancellationToken);
        Task<ReadPublication> Update(UpdatePublication updateRequest, CancellationToken cancellationToken);
        Task<ReadPublication> Delete(DeletePublication updateRequest, CancellationToken cancellationToken);
        Task DeleteIteracion(Guid id, CancellationToken cancellationToken);
        Task DeleteComentario(Guid id, CancellationToken cancellationToken);
       
    }
}