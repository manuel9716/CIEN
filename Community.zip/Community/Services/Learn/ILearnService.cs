using Community.Dtos.Learn.Models;
using Community.Dtos.ListasItem.Models;
using Community.Dtos.Pagination.Models;
using System;
using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;

namespace Community.Services.Learn
{
    public interface ILearnService
    {
        Task<List<ReadOfertas>> GetOfertas(Paginator paginator, string nombre,List<Guid> tema, List<Guid> tipo, List<Guid> modalidad, List<Guid> dirigidoA);
        Task<ReadOfertas> GetOferta(Guid Id);
        Task<ReadOfertas> ReadOfertaId(Guid Id);
        Task<ReadListaItem> ReadListaItem(Guid id, Guid idPadre, CancellationToken cancellationToken);
        Task<ReadListaItem> ReadListaItemPadre(string codigo, CancellationToken cancellationToken);
        Task<ReadOferta> CreateOferta(CreateOferta createRequest, CancellationToken cancellationToken);
        Task<ReadOferta> UpdateOferta(UpdateOferta updateRequest, CancellationToken cancellationToken);
        Task<ReadOferta> OcultarOferta(Guid idOferta, CancellationToken cancellationToken);
    }
}
