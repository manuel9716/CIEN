using AutoMapper;
using Community.Dtos.Learn.Models;
using Community.Dtos.ListasItem.Models;
using Community.Dtos.Pagination.Models;
using Community.Models;
using Community.Models.Learn;
using Community.Repositories.Learn;
using System;
using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;

namespace Community.Services.Learn
{

    public class LearnService : ILearnService
    {
        private readonly IMapper _mapper;
        private readonly ILearnRepository _repository;
        public LearnService(IMapper mapper, ILearnRepository repository)
        {
            _mapper = mapper;
            _repository = repository;
        }
        public async Task<List<ReadOfertas>> GetOfertas(Paginator paginator, string nombre,List<Guid> tema, List<Guid> tipo, List<Guid> modalidad, List<Guid> dirigidoA)
        {
            List<Oferta> entities = await _repository.GetOfertas(paginator, nombre,tema,tipo,modalidad,dirigidoA);
            var dtos = _mapper.Map<List<Oferta>, List<ReadOfertas>>(entities);

            foreach (var item in dtos)
            {
                foreach (var item2 in item.OfertaDirigidoA)
                {

                    ListaItem resultdirigido = await _repository.ReadListaItemId(item2.DirigidoAId);

                    item2.Nombre = resultdirigido.Nombre;
                }

                foreach (var item2 in item.OfertaTema)
                {

                    ListaItem resulttema = await _repository.ReadListaItemId(item2.TemaId);

                    item2.Nombre = resulttema.Nombre;
                }

                ListaItem resulttipo = await _repository.ReadListaItemId(item.TipoId);
                item.NombreTipo = resulttipo.Nombre;

                ListaItem resulttiempo = await _repository.ReadListaItemId(item.TiempoId);
                item.Tiempo = resulttiempo.Nombre;

                ListaItem resultmodalidad = await _repository.ReadListaItemId(item.ModalidadId);
                item.NombreModalidad = resultmodalidad.Nombre;

            }


            return dtos;

        }
         public async Task<ReadOfertas> GetOferta(Guid Id)
        {
            Oferta entity = await _repository.GetOferta(Id);
            var dto = _mapper.Map<Oferta, ReadOfertas>(entity);

            if(dto != null)
            {

                foreach (var item2 in dto.OfertaDirigidoA)
                {

                    ListaItem resultdirigido = await _repository.ReadListaItemId(item2.DirigidoAId);

                    item2.Nombre = resultdirigido.Nombre;
                }

                foreach (var item2 in dto.OfertaTema)
                {

                    ListaItem resulttema = await _repository.ReadListaItemId(item2.TemaId);

                    item2.Nombre = resulttema.Nombre;
                }

                ListaItem resulttipo = await _repository.ReadListaItemId(dto.TipoId);
                dto.NombreTipo = resulttipo.Nombre;

                ListaItem resulttiempo = await _repository.ReadListaItemId(dto.TiempoId);
                dto.Tiempo = resulttiempo.Nombre;

                ListaItem resultmodalidad = await _repository.ReadListaItemId(dto.ModalidadId);
                dto.NombreModalidad = resultmodalidad.Nombre;
            }
            return dto;
        }
        public async Task<ReadOfertas> ReadOfertaId(Guid Id)
        {
            Oferta entity = await _repository.GetOferta(Id);
            var dto = _mapper.Map<Oferta, ReadOfertas>(entity);
            return dto;
        }
        public async Task<ReadListaItem> ReadListaItem(Guid id, Guid idPadre, CancellationToken cancellationToken)
        {
            ListaItem entity = await _repository.ReadListaItem(id, idPadre, cancellationToken);
            var dto = _mapper.Map<ListaItem, ReadListaItem>(entity);
            return dto;
        }
        public async Task<ReadListaItem> ReadListaItemPadre(string codigo, CancellationToken cancellationToken)
        {
            ListaItem entity = await _repository.ReadListaItemPadre(codigo, cancellationToken);
            var dto = _mapper.Map<ListaItem, ReadListaItem>(entity);
            return dto;
        }
        public async Task<ReadOferta> CreateOferta(CreateOferta createRequest, CancellationToken cancellationToken)
        {
            //Crear oferta
            Oferta entity = _mapper.Map<CreateOferta, Oferta>(createRequest);
            entity = await _repository.CreateOferta(entity, cancellationToken);
            ReadOferta dto = _mapper.Map<Oferta, ReadOferta>(entity);

            //Guardar archivos
            if (createRequest.Files != null)
            {
                if (createRequest.Files.Count > 0)
                {

                    dto.Files = new List<string>();
                    foreach (var file in createRequest.Files)
                    {
                        var ofertaFile = new Oferta_file()
                        {
                            OfertaId = dto.Id,
                            AppFileId = file
                        };
                        var ofertaFileEntity = await _repository.CreateOfertaFile(ofertaFile, cancellationToken);
                        dto.Files.Add("api/community/v1/files/download/" + ofertaFileEntity.AppFileId.ToString());
                    }

                }
            }

            //Guardar dirigidos A
            if (createRequest.DirigidosA != null)
            {
                if (createRequest.DirigidosA.Count > 0)
                {

                    dto.DirigidosA = new List<Guid>();
                    foreach (var file in createRequest.DirigidosA)
                    {
                        var ofertadirigidoa = new Oferta_DIrigido_A()
                        {
                            OfertaId = dto.Id,
                            DirigidoAId = file
                        };

                        var ofertadirigidoaEntity = await _repository.CreateOfertaDirigidoA(ofertadirigidoa, cancellationToken);
                        dto.DirigidosA.Add(ofertadirigidoaEntity.Id);
                    }

                }
            }

            //Guardar modulos
            if (createRequest.Modulos != null)
            {
                if (createRequest.Modulos.Count > 0)
                {

                    dto.Modulos = new List<string>();
                    foreach (var file in createRequest.Modulos)
                    {
                        var ofertamodulo = new Oferta_modulo()
                        {
                            OfertaId = dto.Id,
                            Descripcion = file
                        };

                        var ofertamoduloEntity = await _repository.CreateOfertaModulo(ofertamodulo, cancellationToken);
                        dto.Modulos.Add(ofertamoduloEntity.Descripcion);
                    }

                }
            }

            //Guardar temas
            if (createRequest.Temas != null)
            {
                if (createRequest.Temas.Count > 0)
                {

                    dto.Temas = new List<Guid>();
                    foreach (var file in createRequest.Temas)
                    {
                        var ofertatema = new Oferta_tema()
                        {
                            OfertaId = dto.Id,
                            TemaId = file
                        };

                        var ofertamoduloEntity = await _repository.CreateOfertaTema(ofertatema, cancellationToken);
                        dto.Temas.Add(ofertamoduloEntity.Id);
                    }

                }
            }

            return dto;
        }
         public async Task<ReadOferta> UpdateOferta(UpdateOferta updateRequest, CancellationToken cancellationToken)
        {
            Oferta entity = await _repository.GetOferta(updateRequest.Id);
            entity = _mapper.Map<UpdateOferta, Oferta>(updateRequest, entity);
            entity = await _repository.UpdaterOferta(entity, cancellationToken);
            ReadOferta dto = _mapper.Map<Oferta, ReadOferta>(entity);

            _repository.DeleteOfertaFiles(entity.Id);

            //Guardar archivos
            if (updateRequest.Files != null)
            {
               

                if (updateRequest.Files.Count > 0)
                {

                    dto.Files = new List<string>();
                    foreach (var file in updateRequest.Files)
                    {
                        var ofertaFile = new Oferta_file()
                        {
                            OfertaId = dto.Id,
                            AppFileId = file
                        };
                        var ofertaFileEntity = await _repository.CreateOfertaFile(ofertaFile, cancellationToken);
                        dto.Files.Add("api/community/v1/files/download/" + ofertaFileEntity.AppFileId.ToString());
                    }

                }
            }

            //Guardar dirigidos A
            if (updateRequest.DirigidosA != null)
            {
                if (updateRequest.DirigidosA.Count > 0)
                {

                    foreach (var item in entity.OfertaDirigidoA)
                    {

                        Oferta_DIrigido_A resp = await _repository.ReadOfertaDirigidoA(item.Id);

                        _repository.DeleteOfertaDirigidoA(resp);

                    }

                    dto.DirigidosA = new List<Guid>();
                    foreach (var file in updateRequest.DirigidosA)
                    {
                        var ofertadirigidoa = new Oferta_DIrigido_A()
                        {
                            OfertaId = dto.Id,
                            DirigidoAId = file
                        };

                        var ofertadirigidoaEntity = await _repository.CreateOfertaDirigidoA(ofertadirigidoa, cancellationToken);
                        dto.DirigidosA.Add(ofertadirigidoaEntity.Id);
                    }

                }
            }

            //Guardar modulos
            if (updateRequest.Modulos != null)
            {
                if (updateRequest.Modulos.Count > 0)
                {

                    foreach (var item in entity.OfertaModulo)
                    {

                        Oferta_modulo resp = await _repository.ReadOfertaModulo(item.Id);

                        _repository.DeleteOfertaModulo(resp);

                    }

                    dto.Modulos = new List<string>();
                    foreach (var file in updateRequest.Modulos)
                    {
                        var ofertamodulo = new Oferta_modulo()
                        {
                            OfertaId = dto.Id,
                            Descripcion = file
                        };

                        var ofertamoduloEntity = await _repository.CreateOfertaModulo(ofertamodulo, cancellationToken);
                        dto.Modulos.Add(ofertamoduloEntity.Descripcion);
                    }

                }
            }

            //Guardar temas
            if (updateRequest.Temas != null)
            {
                if (updateRequest.Temas.Count > 0)
                {

                    foreach (var item in entity.OfertaTema)
                    {

                        Oferta_tema resp = await _repository.ReadOfertaTema(item.Id);

                        _repository.DeleteOfertaTema(resp);

                    }


                    dto.Temas = new List<Guid>();
                    foreach (var file in updateRequest.Temas)
                    {
                        var ofertatema = new Oferta_tema()
                        {
                            OfertaId = dto.Id,
                            TemaId = file
                        };

                        var ofertamoduloEntity = await _repository.CreateOfertaTema(ofertatema, cancellationToken);
                        dto.Temas.Add(ofertamoduloEntity.Id);
                    }

                }
            }

            return dto;
        }

        public async Task<ReadOferta> OcultarOferta(Guid idOferta, CancellationToken cancellationToken)
        {
            Oferta entity = await _repository.GetOferta(idOferta);
            entity = await _repository.OcultarOferta(entity, cancellationToken);
            ReadOferta dto = _mapper.Map<Oferta, ReadOferta>(entity);

            return dto;

        }
    }
}
