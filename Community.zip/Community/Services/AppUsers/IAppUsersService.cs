using System;
using System.Threading;
using System.Threading.Tasks;
using Community.Dtos.Pagination.Models;
using Community.Dtos.Pagination.Services;
using Community.Dtos.AppUsers.Models;
using System.Collections.Generic;

namespace Community.Services.AppUsers
{
    public interface IAppUsersService
    {
        Task<ReadAppUser> Create(CreateAppUser createRequest, CancellationToken cancellationToken);
        Task<ReadAppUser> Read(Guid id, CancellationToken cancellationToken);
        Task<ReadPrivacyAppUser> ReadPrivacy(Guid id, CancellationToken cancellationToken);
        Task<ReadAppUser> Update(UpdateAppUser updateRequest, CancellationToken cancellationToken);
        Task<bool> UpdatePrivacy(UpdatePrivacyAppUser updatePrivacyRequest, CancellationToken cancellationToken);
        Task<bool> UpdatePassword(UpdatePasswordAppUser updatePasswordRequest, CancellationToken cancellationToken);
        Task<bool> UpdateEmail(UpdateEmailAppUser updateEmailRequest, CancellationToken cancellationToken);
        Task Delete(DeleteAppUser deleteRequest, CancellationToken cancellationToken);
        Task<Paged<ReadAppUser>> Search(Paginator paginator, Sorter sorter, SearchAppUser searchRequest, IUriService uriService, string route, CancellationToken cancellationToken);
        Task<ReadMetricAppUser> ReadMetric(CancellationToken cancellationToken);
        Task<bool> UpdateProfile(UpdateProfileAppUser updateRequest, CancellationToken cancellationToken);
        Task<ReadProfileAppUser> ReadProfile(Guid id, CancellationToken cancellationToken);
        Task<List<ReadProfileAppUser>> ReadSugerencia(Guid id, Paginator paginator, CancellationToken cancellationToken);
        Task<ReadPreguntaConectaAppUser> ReadPreguntaConecta(Guid id, CancellationToken cancellationToken);


    }
}
