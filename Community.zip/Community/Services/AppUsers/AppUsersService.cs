using AutoMapper;
using System;
using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;
using Community.Dtos.AppUsers.Models;
using Community.Models;
using Community.Clients.Keycloak.Services.Users;
using Community.Clients.Keycloak.Dtos.Users;
using Community.Dtos.Pagination.Models;
using Community.Dtos.Pagination.Services;
using Community.Dtos.Pagination.Helpers;
using Community.Repositories.AppUsers;
using Community.Models.project;
using Community.Models.interests;
using Community.Dtos.ListasItem.Models;

namespace Community.Services.AppUsers
{
    public class AppUsersService : IAppUsersService
    {
        private readonly IAppUsersRepository _repository;
        private readonly IKeycloakUsersService _keycloakService;
        private readonly IMapper _mapper;
        public AppUsersService(IAppUsersRepository repository, IKeycloakUsersService keycloakService, IMapper mapper)
        {
            _repository = repository;
            _keycloakService = keycloakService;
            _mapper = mapper;
        }
        public async Task<ReadAppUser> Create(CreateAppUser createRequest, CancellationToken cancellationToken)
        {
            //1. User keycloakUser
            var keycloakUserCreateRequest = new KeycloakUserCreateRequest(){
                Password = createRequest.Password,
                FirstName = createRequest.Nombres,
                LastName = createRequest.Apellidos,
                Email = createRequest.Email,
                Enabled = true,
                Username = createRequest.Email
            };
            var keycloakUserViewRequest = _keycloakService.RegisterUser(keycloakUserCreateRequest);
            
            //2. App user
            AppUser entity = _mapper.Map<CreateAppUser, AppUser>(createRequest);
            entity.Id = keycloakUserViewRequest.Id;
            entity = await _repository.Create(entity, cancellationToken);
            ReadAppUser dto = _mapper.Map<AppUser, ReadAppUser>(entity);
            return dto;
        }
        public async Task<ReadAppUser> Read(Guid id, CancellationToken cancellationToken)
        {
            AppUser entity = await _repository.Read(id, cancellationToken);
            var dto = _mapper.Map<AppUser, ReadAppUser>(entity);
            return dto;
        }

        public async Task<ReadPrivacyAppUser> ReadPrivacy(Guid id, CancellationToken cancellationToken)
        {
            AppUser entity = await _repository.Read(id, cancellationToken);
            var dto = _mapper.Map<AppUser, ReadPrivacyAppUser>(entity);
            return dto;
        }

        public async Task<ReadAppUser> Update(UpdateAppUser updateRequest, CancellationToken cancellationToken)
        {
            AppUser entity = await _repository.Read(updateRequest.Id, cancellationToken);
            entity = _mapper.Map<UpdateAppUser, AppUser>(updateRequest, entity);
            entity = await _repository.Update(entity, cancellationToken);
            ReadAppUser dto = _mapper.Map<AppUser, ReadAppUser>(entity);
            return dto;
        }

        public async Task<bool> UpdatePrivacy(UpdatePrivacyAppUser updatePrivacyRequest, CancellationToken cancellationToken)
        {
            AppUser entity = await _repository.Read(updatePrivacyRequest.Id, cancellationToken);
            entity.Notificar = updatePrivacyRequest.Notificar;
            entity.MostrarCorreo = updatePrivacyRequest.MostrarCorreo;
            entity.MostrarRedes = updatePrivacyRequest.MostrarRedes;
            entity.MostrarTelefono = updatePrivacyRequest.MostrarTelefono;
            entity = await _repository.Update(entity, cancellationToken);
            return true;
        }

        public async Task<bool> UpdatePassword(UpdatePasswordAppUser updatePasswordRequest, CancellationToken cancellationToken)
        {

            if(updatePasswordRequest.Password != updatePasswordRequest.PasswordConfirmed)
                throw new Exception("Las contraseñas no coinciden");

            var keycloakPasswordUpdateRequest = new KeycloakPasswordUpdateRequest();
            keycloakPasswordUpdateRequest.Type= "password";
            keycloakPasswordUpdateRequest.Value=updatePasswordRequest.Password;
            keycloakPasswordUpdateRequest.Temporary = false;
            var keycloakUbpdatePassword = _keycloakService.UpdatePassword(updatePasswordRequest.Id, keycloakPasswordUpdateRequest);
            
            return keycloakUbpdatePassword;
        }

        public async Task<bool> UpdateEmail(UpdateEmailAppUser updateEmailRequest, CancellationToken cancellationToken)
        {

            if(updateEmailRequest.Email != updateEmailRequest.EmailConfirmed)
                throw new Exception("Dirección de correo no coinciden");

            var keycloakUserView = _keycloakService.ReadUser(updateEmailRequest.Id);
            
            var keycloakUserUpdateRequest = _mapper.Map<KeycloakUserViewRequest, KeycloakUserUpdateRequest>(keycloakUserView);

            keycloakUserUpdateRequest.Email = updateEmailRequest.Email;
            keycloakUserUpdateRequest.Username = updateEmailRequest.Email;
            var update = _keycloakService.UpdateUser(keycloakUserUpdateRequest);

            return true;
        }

        public async Task<bool> UpdateProfile(UpdateProfileAppUser updateRequest, CancellationToken cancellationToken)
        {
            AppUser entity = await _repository.Read(updateRequest.Id, cancellationToken);

            //Imagen perfil
            if(updateRequest.AppFileId != Guid.Parse("00000000-0000-0000-0000-000000000000")) {
                entity.AppFileId = updateRequest.AppFileId;
            }

            //Pregunta conecta
            if(updateRequest.PreguntaConectaId != Guid.Parse("00000000-0000-0000-0000-000000000000")) 
                entity.PreguntaConectaId = updateRequest.PreguntaConectaId;

            //Contacto
            entity.CelularContacto = updateRequest.CelularContacto;
            //entity.EmailContacto = updateRequest.EmailContacto;

            //Redes
            entity.Linkedin = updateRequest.Linkedin;
            entity.Twitter = updateRequest.Twitter;

            //Donde estas
            if(updateRequest.PaisResidenciaId != Guid.Parse("00000000-0000-0000-0000-000000000000")) 
                entity.PaisResidenciaId = updateRequest.PaisResidenciaId;

            if(updateRequest.DepartamentoResidenciaId != Guid.Parse("00000000-0000-0000-0000-000000000000")) 
                entity.DepartamentoResidenciaId = updateRequest.DepartamentoResidenciaId;
            
            if(updateRequest.MunicipioResidenciaId != Guid.Parse("00000000-0000-0000-0000-000000000000")) 
                entity.MunicipioResidenciaId = updateRequest.MunicipioResidenciaId;

            //Etiquetas
            if(updateRequest.Etiquetas.Count > 0) {

                await _repository.DeletePerfilEtiqueta(updateRequest.Id, cancellationToken);
                foreach(var etiqueta in updateRequest.Etiquetas){
                    var perfil_etiqueta = new PerfilEtiqueta();
                    perfil_etiqueta.AppUserId = updateRequest.Id;
                    perfil_etiqueta.ListaItemId = etiqueta;
                    var entityPerfilEtiqueta = await _repository.CreatePerfilEtiqueta(perfil_etiqueta, cancellationToken);
                }
            }

            //Donde trabajas
            if(updateRequest.OrganizacionId != Guid.Parse("00000000-0000-0000-0000-000000000000")) 
                entity.OrganizacionId = updateRequest.OrganizacionId;

            if(updateRequest.AreaDireccionEquipoId != Guid.Parse("00000000-0000-0000-0000-000000000000")) 
                entity.AreaDireccionEquipoId = updateRequest.AreaDireccionEquipoId;
            
            if(updateRequest.SectorId != Guid.Parse("00000000-0000-0000-0000-000000000000")) 
                entity.SectorId = updateRequest.SectorId;

            if(updateRequest.OrdenId != Guid.Parse("00000000-0000-0000-0000-000000000000")) 
                entity.OrdenId = updateRequest.OrdenId;
            
            //Que haces
            if(updateRequest.ProfesionId != Guid.Parse("00000000-0000-0000-0000-000000000000")) 
                entity.ProfesionId = updateRequest.ProfesionId;

            if(updateRequest.CargoActualId != Guid.Parse("00000000-0000-0000-0000-000000000000")) 
                entity.CargoActualId = updateRequest.CargoActualId;

            if(updateRequest.NivelId != Guid.Parse("00000000-0000-0000-0000-000000000000")) 
                entity.NivelId = updateRequest.NivelId;

             //Etiquetas
            if(updateRequest.Temas.Count > 0) {

                await _repository.DeletePerfilTema(updateRequest.Id, cancellationToken);
                foreach(var tema in updateRequest.Temas){
                    var perfil_tema = new Interest();
                    perfil_tema.AppUserId = updateRequest.Id;
                    perfil_tema.ListaItemId = tema;
                    var entityPerfilEtiqueta = await _repository.CreatePerfilTema(perfil_tema, cancellationToken);
                }
            }

            //Proyecto actual
             if(updateRequest.ProyectoActual != null) {
                var entityProjectActual =  _mapper.Map<ProjectAppUser, Project>(updateRequest.ProyectoActual);

                if(updateRequest.ProyectoActual.Id != Guid.Parse("00000000-0000-0000-0000-000000000000")) {
                    var enityDB = await _repository.ReadProject(entityProjectActual.Id, cancellationToken);
                    enityDB.Nombre = entityProjectActual.Nombre;
                    enityDB.Descripcion = entityProjectActual.Descripcion;
                    enityDB.Finalizacion = entityProjectActual.Finalizacion;
                    enityDB.Etiquetas = entityProjectActual.Etiquetas;
                    
                }else{
                    entityProjectActual = await _repository.CreateProject(entityProjectActual, cancellationToken);
                    entity.ProyectoActualId = entityProjectActual.Id;
                }
            }

            //Proyecto desctacado
             if(updateRequest.ProyectoDestacatdo != null) {
                var entityProjectDestacado =  _mapper.Map<ProjectAppUser, Project>(updateRequest.ProyectoDestacatdo);

                if(updateRequest.ProyectoDestacatdo.Id != Guid.Parse("00000000-0000-0000-0000-000000000000")) {
                    var enityDBDestacado = await _repository.ReadProject(entityProjectDestacado.Id, cancellationToken);
                    enityDBDestacado.Nombre = entityProjectDestacado.Nombre;
                    enityDBDestacado.Descripcion = entityProjectDestacado.Descripcion;
                    enityDBDestacado.Finalizacion = entityProjectDestacado.Finalizacion;
                    enityDBDestacado.Etiquetas = entityProjectDestacado.Etiquetas;
                    
                }else{
                    entityProjectDestacado = await _repository.CreateProject(entityProjectDestacado, cancellationToken);
                    entity.ProyectoDestacadoId = entityProjectDestacado.Id;
                }
            }

            //Proyecto destacado
            
            entity = await _repository.Update(entity, cancellationToken);
            return true;
        }

        public async Task Delete(DeleteAppUser deleteRequest, CancellationToken cancellationToken)
        {
            AppUser entity = await _repository.Read(deleteRequest.Id, cancellationToken);
            entity.FechaEliminacion = DateTime.Now;
            entity.MotivoEliminacionId = deleteRequest.MotivoId;
            await _repository.Update(entity, cancellationToken);
            _keycloakService.DeleteUser(deleteRequest.Id);
        }


        public async Task<Paged<ReadAppUser>> Search(Paginator paginator, Sorter sorter, SearchAppUser searchRequest, IUriService uriService, string route, CancellationToken cancellationToken)
        {
            List<AppUser> entities = await _repository.Search(paginator, sorter, searchRequest, cancellationToken);
            var dtos = _mapper.Map<List<AppUser>, List<ReadAppUser>>(entities);
            int totalRecords = await _repository.TotalCount(searchRequest, cancellationToken);
            var page = PaginationHelper.CreatePagedReponse<ReadAppUser>(dtos, paginator, totalRecords, uriService, route);

            return page;
        }

        public async Task<ReadMetricAppUser> ReadMetric(CancellationToken cancellationToken)
        {
            var dto = new ReadMetricAppUser();
            var searchAppUser = new SearchAppUser();
            dto.UsuariosRegistrados = await _repository.TotalCount(searchAppUser, cancellationToken);

            dto.UusariosRegionales  = await _repository.TotalCountPais("CO", cancellationToken);
            dto.UsuariosInternacionales  = dto.UsuariosRegistrados-dto.UusariosRegionales;

            return dto;
        }

        public async Task<ReadProfileAppUser> ReadProfile(Guid id, CancellationToken cancellationToken)
        {
            AppUser entity = await _repository.Read(id, cancellationToken);
            var dto = _mapper.Map<AppUser, ReadProfileAppUser>(entity);

            //Path imagen perfil
            if(dto != null && dto.AppFile != null){
                 dto.AppFile.Path = "api/community/v1/files/download/" + dto.AppFile.Id.ToString();
            }
            
            //Consultar perfil etiqueta
            var perfilEtiquetas = await _repository.ReadPerfilEtiqueta(id);
            var perfilEtiquetaDto = new List<ReadListaItem>();
            if(perfilEtiquetas.Count > 0){
                foreach(var perfilEtiqueta in perfilEtiquetas){
                    var dtoEtiqueta =  _mapper.Map<ListaItem, ReadListaItem>(perfilEtiqueta.ListaItem);
                    perfilEtiquetaDto.Add(dtoEtiqueta);
                }
            }
            if (dto != null) {
                dto.Etiquetas = perfilEtiquetaDto;
            }

            //Consultar temas
            var perfilTemas = await _repository.ReadPerfilTema(id);
            var perfilTemaDto = new List<ReadListaItem>();
            if(perfilTemas.Count > 0){
                foreach(var perfilTema in perfilTemas){
                    var dtoTema =  _mapper.Map<ListaItem, ReadListaItem>(perfilTema.ListaItem);
                    perfilTemaDto.Add(dtoTema);
                }
            }
            if (dto != null) {
                dto.Temas = perfilTemaDto;
            }

            return dto;
        }

        public async Task<List<ReadProfileAppUser>> ReadSugerencia(Guid id, Paginator paginator, CancellationToken cancellationToken)
        {
            var result = new List<ReadProfileAppUser>();
            var temas = new List<Guid>();

            //Consultar temas
            var intereses = await _repository.ReadPerfilTema(id);
            if(intereses.Count > 0){
                foreach(var interes in intereses){
                    temas.Add((Guid)interes.ListaItemId);
                }
            }

            var listaUsers = await _repository.GetSugerencias(id, temas, paginator);

            foreach(var user in listaUsers){
                 AppUser entity = await _repository.Read((Guid)user, cancellationToken);
                var dto = _mapper.Map<AppUser, ReadProfileAppUser>(entity);


                //Path imagen perfil
                if(dto.AppFile != null){
                    dto.AppFile.Path = "api/community/v1/files/download/" + dto.AppFile.Id.ToString();
                }

                //Consultar temas
                var perfilTemas = await _repository.ReadPerfilTema(id);
                var perfilTemaDto = new List<ReadListaItem>();
                if(perfilTemas.Count > 0){
                    foreach(var perfilTema in perfilTemas){
                        var dtoTema =  _mapper.Map<ListaItem, ReadListaItem>(perfilTema.ListaItem);
                        perfilTemaDto.Add(dtoTema);
                    }
                }
                dto.Temas = perfilTemaDto;


                result.Add(dto);

            }
           

            return result;
        }

        public async Task<ReadPreguntaConectaAppUser> ReadPreguntaConecta(Guid id, CancellationToken cancellationToken)
        {
            AppUser entity = await _repository.Read(id, cancellationToken);
            var dto = _mapper.Map<AppUser, ReadPreguntaConectaAppUser>(entity);

            return dto;
        }


    }
}
