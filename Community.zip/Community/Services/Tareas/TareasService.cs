﻿using Application.Clients.Keycloak.Services.Users;
using AutoMapper;
using Community.Clients.Keycloak.Services.Users;
using Community.Dtos.Tools.Models;
using Community.Models.tool;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using Community.Repositories.Tareas;

namespace Community.Services.Tareas
{
    public class TareasService : ITareasService
    {
        private readonly ITareasRepository _repository;
        private readonly IKeycloakUsersService _keycloakService;
        private readonly IActorService _actorService;
        private readonly IMapper _mapper;

        public TareasService(ITareasRepository repository,
                            IKeycloakUsersService keycloakService,
                            IActorService actorService,
                            IMapper mapper)
        {
            _repository = repository;
            _keycloakService = keycloakService;
            _actorService = actorService;
            _mapper = mapper;
        }

        public async Task<ReadToolsTasks> CreateTarea(CreateToolsTasks createRequest, CancellationToken cancellationToken)
        {
            ToolTask entity = _mapper.Map<CreateToolsTasks, ToolTask>(createRequest);
            entity = await _repository.CreateTarea(entity, cancellationToken);
            ReadToolsTasks dto = _mapper.Map<ToolTask, ReadToolsTasks>(entity);
            return dto;
        }
    }
}
