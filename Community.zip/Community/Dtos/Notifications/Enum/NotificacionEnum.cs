using AutoMapper;
using Community.Dtos.Notifications.Models;
using Community.Models.notification;

namespace Community.Dtos.Notifications.Enum
{
     public enum TextoNotificacion
    {
        PUBLICACIONMEGUSTA,
        COMENTARIOMEGUSTA,
        PUBLICACIONREPORTADA,
        COMENTARIO
    }

    public static class TextoNotificacionExtensions
    {
        public static string GetString(this TextoNotificacion t)
        {
            switch (t)
            {
                case TextoNotificacion.PUBLICACIONMEGUSTA:
                    return "ha indicado que le gusta tu publicación";
                case TextoNotificacion.COMENTARIO:
                    return "ha comentado tu publicación";
                case TextoNotificacion.COMENTARIOMEGUSTA:
                    return "ha indicado que le gusta tu comentario";
                case TextoNotificacion.PUBLICACIONREPORTADA:
                    return "Tu publicación ha sido reportada por infringir las normas de CIEN";
                default:
                    return "NO VALUE GIVEN";
            }
        }
    }
}
