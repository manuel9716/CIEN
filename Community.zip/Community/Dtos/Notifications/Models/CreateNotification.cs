using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Community.Models.publication;
namespace Community.Dtos.Notifications.Models
{
    public class CreateNotification
    {
        public Guid UserId { get; set; }
        public Guid UserOrigenId { get; set; }
        public string descripcion { get; set; }
        public string enlace { get; set; }
        public Guid? PublicacionId { get; set; }
        public Guid? IteracionId { get; set; }
        public bool activa { get; set; }

    }
}