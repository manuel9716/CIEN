using AutoMapper;
using Community.Dtos.Notifications.Models;
using Community.Models.notification;

namespace Community.Dtos.Notifications.Mappings
{
    public class NotificationMapping : Profile
    {
        public NotificationMapping()
        {
            CreateMap<CreateNotification, Notification>().ReverseMap();
            CreateMap<ReadNotification, Notification>().ReverseMap();

        }
    }
}
