using AutoMapper;
using Community.Dtos.AppUsers.Models;
using Community.Models;

namespace Community.Dtos.AppUsers.Mappings
{
    public class UpdatePrivacyAppUserMapping : Profile
    {
        public UpdatePrivacyAppUserMapping()
        {
            CreateMap<UpdatePrivacyAppUser, AppUser>();
        }
    }
}
