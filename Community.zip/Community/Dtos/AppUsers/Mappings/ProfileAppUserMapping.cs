using AutoMapper;
using Community.Dtos.AppUsers.Models;
using Community.Models;
using Community.Models.project;

namespace Community.Dtos.AppUsers.Mappings
{
    public class ProfileAppUserMapping : Profile
    {
        public ProfileAppUserMapping()
        {
            CreateMap<ProjectAppUser, Project>().ReverseMap();
            CreateMap<UpdateProfileAppUser, AppUser>().ReverseMap();
            CreateMap<ReadProfileAppUser, AppUser>().ReverseMap();
             CreateMap<ReadPreguntaConectaAppUser, AppUser>().ReverseMap();
            

        }
    }
}
