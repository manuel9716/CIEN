using AutoMapper;
using Community.Dtos.AppUsers.Models;
using Community.Models;

namespace Community.Dtos.AppUsers.Mappings
{
    public class ReadPrivacyAppUserMapping : Profile
    {
        public ReadPrivacyAppUserMapping()
        {
            CreateMap<AppUser, ReadPrivacyAppUser>();
        }
    }
}
