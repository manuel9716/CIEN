using AutoMapper;
using Community.Dtos.AppUsers.Models;
using Community.Models;

namespace Community.Dtos.AppUsers.Mappings
{
    public class UpdateAppUserMapping : Profile
    {
        public UpdateAppUserMapping()
        {
            CreateMap<UpdateAppUser, AppUser>();
        }
    }
}
