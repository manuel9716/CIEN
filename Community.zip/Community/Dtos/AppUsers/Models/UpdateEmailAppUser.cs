using System;
namespace Community.Dtos.AppUsers.Models
{
    public class UpdateEmailAppUser
    {
        public Guid Id { get; set; }
        public String Email { get; set; }
        public String EmailConfirmed { get; set; }

    }
}
