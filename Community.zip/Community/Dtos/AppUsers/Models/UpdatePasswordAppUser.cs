using System;
namespace Community.Dtos.AppUsers.Models
{
    public class UpdatePasswordAppUser
    {
        public Guid Id { get; set; }
        public String PasswordOld { get; set; }
        public String Password{ get; set; }
        public String PasswordConfirmed{ get; set; }

    }
}
