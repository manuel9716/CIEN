using System;
namespace Community.Dtos.AppUsers.Models
{
    public class SearchAppUser
    {
        public Guid Id { get; set; }
        public String Nombres { get; set; }
        public String Apellidos { get; set; }
        public System.Nullable<Guid> PaisResidenciaId { get; set; }
        public System.Nullable<Guid> DepartamentoResidenciaId { get; set; }
        public System.Nullable<Guid> MunicipioResidenciaId { get; set; }
        public System.Nullable<DateTime> FechaNacimientoMin { get; set; }
        public System.Nullable<DateTime> FechaNacimientoMax { get; set; }
        public System.Nullable<Guid> GeneroId { get; set; }
    }
}
