using System;
namespace Community.Dtos.AppUsers.Models
{
    public class UpdatePrivacyAppUser
    {
        public Guid Id { get; set; }
        public bool Notificar { get; set; }
        public bool MostrarCorreo { get; set; }
        public bool MostrarRedes { get; set; }
        public bool MostrarTelefono { get; set; }
    }
}
