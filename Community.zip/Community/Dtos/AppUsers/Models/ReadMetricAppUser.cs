using System;
namespace Community.Dtos.AppUsers.Models
{
    public class ReadMetricAppUser
    {
        public int UsuariosRegistrados { get; set; }
        public int Ingresos { get; set; }
        public int UsuariosInternacionales { get; set; }
        public int UusariosRegionales { get; set; }


    }
}
