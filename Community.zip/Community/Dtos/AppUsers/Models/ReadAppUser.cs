using System;
namespace Community.Dtos.AppUsers.Models
{
    public class ReadAppUser
    {
        public Guid Id { get; set; }
        public String Nombres { get; set; }
        public String Apellidos { get; set; }
        public Guid PaisResidenciaId { get; set; }
        public String PaisResidenciaNombre { get; set; }
        public Guid DepartamentoResidenciaId { get; set; }
        public String DepartamentoResidenciaNombre { get; set; }
        public Guid MunicipioResidenciaId { get; set; }
        public String MunicipioResidenciaNombre { get; set; }
        public DateTime FechaNacimiento { get; set; }
        public Guid GeneroId { get; set; }
        public String GeneroNombre { get; set; }
        
    }
}
