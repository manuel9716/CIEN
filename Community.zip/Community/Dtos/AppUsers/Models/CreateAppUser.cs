using System;
namespace Community.Dtos.AppUsers.Models
{
    public class CreateAppUser
    {
        public String Nombres { get; set; }
        public String Apellidos { get; set; }
        public Guid PaisResidenciaId { get; set; }
        public Guid DepartamentoResidenciaId { get; set; }
        public Guid MunicipioResidenciaId { get; set; }
        public DateTime FechaNacimiento { get; set; }
        public Guid GeneroId { get; set; }
        public string Email { get; set; }
        public string Password { get; set; }
    }
}
