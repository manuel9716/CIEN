using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Text.Json.Serialization;
using Community.Dtos.ListasItem.Models;
using Community.Dtos.Files.Models;

namespace Community.Dtos.AppUsers.Models
{
    public class ReadPreguntaConectaAppUser
    {
        
        public ReadListaItem PreguntaConecta { get; set; }

    
    }
}
