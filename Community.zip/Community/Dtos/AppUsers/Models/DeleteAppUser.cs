using System;
namespace Community.Dtos.AppUsers.Models
{
    public class DeleteAppUser
    {
        public Guid Id { get; set; }
        public Guid MotivoId { get; set; }

    }
}
