using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Text.Json.Serialization;

namespace Community.Dtos.AppUsers.Models
{
    public class ProjectAppUser
    {
        public Guid Id { get; set; }
        public String Nombre { get; set; }
        public String Descripcion { get; set; }
        public int Finalizacion { get; set; }

        public String Etiquetas { get; set; }
        
    }
}
