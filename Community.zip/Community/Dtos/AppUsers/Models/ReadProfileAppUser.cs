using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Text.Json.Serialization;
using Community.Dtos.ListasItem.Models;
using Community.Dtos.Files.Models;

namespace Community.Dtos.AppUsers.Models
{
    public class ReadProfileAppUser
    {
        public Guid Id { get; set; }

        public String Nombres { get; set; }
        public String Apellidos { get; set; }

        public Guid AppFileId { get; set; }
        public ReadFile AppFile { get; set; }

        public Guid PaisResidenciaId { get; set; }
        public ReadListaItem PaisResidencia { get; set; }
        
        public Guid DepartamentoResidenciaId { get; set; }
        public ReadListaItem DepartamentoResidencia { get; set; }
        public Guid MunicipioResidenciaId { get; set; }
        public ReadListaItem MunicipioResidencia { get; set; }
        public string CelularContacto { get; set; }
        public string EmailContacto { get; set; }
        public string Linkedin { get; set; }
        public string Twitter { get; set; }
        public List<ReadListaItem> Etiquetas { get; set; }
        public Guid OrganizacionId { get; set; }
        public ReadListaItem Organizacion { get; set; }
        public Guid AreaDireccionEquipoId { get; set; }
        public ReadListaItem AreaDireccionEquipo { get; set; }

        public Guid SectorId { get; set; }
        public ReadListaItem Sector { get; set; }
        public Guid OrdenId { get; set; }
        public ReadListaItem Orden { get; set; }
        public Guid ProfesionId { get; set; }
        public ReadListaItem Profesion { get; set; }
        public Guid? CargoActualId { get; set; }
        public ReadListaItem CargoActual { get; set; }
        public Guid NivelId { get; set; }
        public ReadListaItem Nivel { get; set; }
        public List<ReadListaItem> Temas { get; set; }
        public Guid ProyectoActualId { get; set; }
        public Guid ProyectoDestacadoId { get; set; }       
        public ProjectAppUser ProyectoActual { get; set; }         
        public ProjectAppUser ProyectoDestacado { get; set; } 

    }
}
