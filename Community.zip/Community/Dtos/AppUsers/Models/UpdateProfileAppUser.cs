using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Text.Json.Serialization;

namespace Community.Dtos.AppUsers.Models
{
    public class UpdateProfileAppUser
    {
        public Guid Id { get; set; }

        public Guid AppFileId { get; set; }

        public Guid PreguntaConectaId { get; set; }

        public Guid PaisResidenciaId { get; set; }
        public Guid DepartamentoResidenciaId { get; set; }
        public Guid MunicipioResidenciaId { get; set; }

        public string CelularContacto { get; set; }
        public string EmailContacto { get; set; }
        public string Linkedin { get; set; }
        public string Twitter { get; set; }

        public List<Guid> Etiquetas { get; set; }

        public Guid OrganizacionId { get; set; }
        public Guid AreaDireccionEquipoId { get; set; }
        public Guid SectorId { get; set; }
        public Guid OrdenId { get; set; }
        public bool UnidadInnovacion { get; set; }

        public Guid ProfesionId { get; set; }
        public Guid CargoActualId { get; set; }
        public Guid NivelId { get; set; }

        public List<Guid> Temas { get; set; }

        public ProjectAppUser ProyectoActual { get; set; }       
        public ProjectAppUser ProyectoDestacatdo { get; set; }       

    }
}
