﻿using AutoMapper;
using Community.Dtos.Interests.Models;
using Community.Models.interests;

namespace Community.Dtos.Interests.Mappings
{
    public class ReadInterestsUserIdMapping : Profile
    {
        public ReadInterestsUserIdMapping()
        {
            CreateMap<Interest, ReadInterestsUserId>();
        }
    }
}
