﻿using AutoMapper;
using Community.Dtos.Interests.Models;
using Community.Models.interests;

namespace Community.Dtos.Interests.Mappings
{
    public class ReadInterestsMapping: Profile
    {
        public ReadInterestsMapping()
        {
            CreateMap<Interest, ReadInterests>();
        }
    }
}
