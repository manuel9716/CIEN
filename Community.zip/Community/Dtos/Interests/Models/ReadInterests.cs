﻿using System;
using System.Collections.Generic;
using Community.Dtos.AppUsers.Models;
using Community.Dtos.ListasItem.Models;

namespace Community.Dtos.Interests.Models
{
    public class ReadInterests
    {
        public Guid Id { get; set; }
        public ReadAppUser Usuario { get; set; }
        public ReadListaItem ListaItem { get; set; }
        public String Codigo { get; set; }
    }
}
