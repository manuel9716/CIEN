﻿using Community.Dtos.AppUsers.Models;
using Community.Dtos.ListasItem.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Community.Dtos.Interests.Models
{
    public class ReadInterestsUserId
    {
        public Guid Id { get; set; }
        public ReadAppUser Usuario { get; set; }
    }
}
