using System;

namespace Community.Dtos.ListasItem.Models
{
    public class ReadListaItem
    {
        public Guid Id { get; set; }
        public String Codigo { get; set; }
        public String Nombre { get; set; }
        public int Orden { get; set; }
        public System.Nullable<Guid> PadreId { get; set; }
        public DateTime FechaCreacion { get; set; }
        public DateTime FechaActualizacion { get; set; }
    }
}
