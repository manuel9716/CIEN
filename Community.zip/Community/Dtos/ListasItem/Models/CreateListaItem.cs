using System;

namespace Community.Dtos.ListasItem.Models
{
    public class CreateListaItem
    {
        public String Codigo { get; set; }
        public String Nombre { get; set; }
        public int Orden { get; set; }
        public System.Nullable<Guid> PadreId { get; set; }

    }
}
