using System;
using Community.Dtos.ListasItem.Models;
using Community.Models;
using AutoMapper;

namespace Community.Dtos.ListasItem.Mappings
{
    public class UpdateListaItemMapping : Profile
    {
        public UpdateListaItemMapping()
        {
            CreateMap<UpdateListaItem, ListaItem>();
        }
    }
}
