using System;
using Community.Dtos.ListasItem.Models;
using Community.Models;
using AutoMapper;

namespace Community.Dtos.ListasItem.Mappings
{
    public class ReadListaItemMapping : Profile
    {
        public ReadListaItemMapping()
        {
            CreateMap<ListaItem, ReadListaItem>();
            CreateMap<ListaItem, ReadListaItemRespuestaEtiqueta>();
        }
    }
}
