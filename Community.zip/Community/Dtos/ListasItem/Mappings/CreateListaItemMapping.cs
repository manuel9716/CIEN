using System;
using Community.Dtos.ListasItem.Models;
using Community.Models;
using AutoMapper;

namespace Community.Dtos.ListasItem.Mappings
{
    public class CreateListaItemMapping : Profile
    {
        public CreateListaItemMapping()
        {
            CreateMap<CreateListaItem, ListaItem>();
        }
    }
}
