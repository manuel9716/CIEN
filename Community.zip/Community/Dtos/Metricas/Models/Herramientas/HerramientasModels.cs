﻿using System;

namespace Community.Dtos.Metricas.Models.Herramientas
{
    public class HerramientasModels
    {
        public int HerramientasCounts { get; set; }
        public Guid HerramientaId { get; set; }

    }
}
