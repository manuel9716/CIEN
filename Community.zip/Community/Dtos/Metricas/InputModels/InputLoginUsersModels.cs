﻿using System;

namespace Community.Dtos.Metricas.InputModels
{
    public class InputLoginUsersModels
    {
       public Guid idUsuario { get; set; }
        public string nombre { get; set; }
        public string nombreUsuario { get; set; }
        public string correo { get; set; }



    }
}
