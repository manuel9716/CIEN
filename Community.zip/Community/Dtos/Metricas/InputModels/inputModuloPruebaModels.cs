﻿namespace Community.Dtos.Metricas.InputModels
{
    public class inputModuloPruebaModels
    {
        public string tipo { get; set; }

    }
}
