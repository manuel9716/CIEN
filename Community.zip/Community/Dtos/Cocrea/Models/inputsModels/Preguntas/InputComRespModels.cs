﻿using System;

namespace Community.Dtos.Cocrea.Models.inputsModels.Preguntas
{
    public class InputComRespModels
    {
        public string ComentarioTexto { get; set; }
        public Guid RespuestaId { get; set; }

    }
}
