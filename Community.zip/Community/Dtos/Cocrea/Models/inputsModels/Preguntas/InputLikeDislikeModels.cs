﻿using System;

namespace Community.Dtos.Cocrea.Models.inputsModels.Preguntas
{
    public class InputLikeDislikeModels
    {
       public bool Dta { get; set; }
       public Guid RespuestaId { get; set; }
    }
}
