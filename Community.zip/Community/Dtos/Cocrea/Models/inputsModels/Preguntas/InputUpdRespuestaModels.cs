﻿using System;

namespace Community.Dtos.Cocrea.Models.inputsModels.Preguntas
{
    public class InputUpdRespuestaModels
    {
        public string RespuestaTexto { get; set; }
        public Guid RespuestaId { get; set; }
    }
}
