﻿using System;

namespace Community.Dtos.Cocrea.Models.inputsModels.Preguntas
{
    public class inputRespuestaModels
    {
        public string RespuestaTexto { get; set; }
        public Guid PreguntaId { get; set; }
    }
}
