﻿using System;

namespace Community.Dtos.Cocrea.Models.inputsModels.Preguntas
{
    public class InputPreguntaModels
    {
        public Guid EntidadId { get; set; }
        public string EntidadNombre { get; set; }
        public Guid GrupoId { get; set; }
        public string GrupoNombre { get; set; }
        public string PreguntaTexto { get; set; }
        public string Justificacion { get; set; }

    }
}
