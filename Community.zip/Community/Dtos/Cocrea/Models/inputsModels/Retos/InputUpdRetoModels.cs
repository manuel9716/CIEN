﻿using System.Collections.Generic;
using System;

namespace Community.Dtos.Cocrea.Models.inputsModels.Retos
{
    public class InputUpdRetoModels
    {
        public InputUpdRetoModels()
        {
            DocRetoList = new List<DocReto>();
            EntRetoList = new List<EntReto>();
            TemRetoList = new List<TemReto>();
            EtaRetoList = new List<EtaReto>();
            IncRetoList = new List<IncReto>();
            PartiRetoList = new List<PartiReto>();
        }

        public Guid IdReto { get; set; }
        public string Titulo { get; set; }
        public string Descripcion { get; set; }
        public DateTime FechaCreacion { get; set; }
        public DateTime FechaCierre { get; set; }
        public int Vistas { get; set; }
        public string Requisitos { get; set; }
        public string Estado { get; set; }
        public Guid Autor { get; set; }
        public bool FlagEstado { get; set; }
        public List<DocReto> DocRetoList { get; set; }
        public List<EntReto> EntRetoList { get; set; }
        public List<TemReto> TemRetoList { get; set; }
        public List<EtaReto> EtaRetoList { get; set; }
        public List<IncReto> IncRetoList { get; set; }
        public List<PartiReto> PartiRetoList { get; set; }


    }

    public class DocUpdReto
    {

        public string Tipo { get; set; }
        public string Webp { get; set; }
        public string Base64 { get; set; }
        public string NombreDocumento { get; set; }
        public bool FlagPortada { get; set; }
    }
    public class EntUpdReto
    {

        public Guid EntidadId { get; set; }
        public string NombreEntidad { get; set; }
        public bool Estado { get; set; }
    }
    public class TemUpdReto
    {
        public Guid TemaId { get; set; }

    }
    public class EtaUpdReto
    {

        public string Nombre { get; set; }
        public DateTime FechaInicial { get; set; }
        public DateTime FechaFinal { get; set; }
        public bool Estado { get; set; }
    }
    public class IncUpdReto
    {

        public string Nombre { get; set; }
        public string Descripcion { get; set; }
        public bool Estado { get; set; }
    }
    public class PartiUpdReto
    {
        public Guid ParticipanteId { get; set; }

    }
}
    

