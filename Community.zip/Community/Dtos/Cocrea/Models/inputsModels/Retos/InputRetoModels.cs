﻿using Community.Dtos.Cocrea.Models.Retos;
using System;
using System.Collections.Generic;

namespace Community.Dtos.Cocrea.Models.inputsModels.Retos
{
    public class InputRetoModels
    {
        public InputRetoModels()
        {
            DocRetoList = new List<DocReto>();
            EntRetoList = new List<EntReto>();
            TemRetoList = new List<TemReto>();
            EtaRetoList = new List<EtaReto>();
            IncRetoList = new List<IncReto>();
            PartiRetoList = new List<PartiReto>();
        }

        public string Titulo { get; set; }
        public string Descripcion { get; set; }
        public DateTime FechaCreacion { get; set; }
        public DateTime FechaCierre { get; set; }
        public int Vistas { get; set; }
        public string Requisitos { get; set; }
        public string Estado { get; set; }
        public Guid Autor { get; set; }
        public bool FlagEstado { get; set; }
        public List<DocReto> DocRetoList { get; set; }
        public List<EntReto> EntRetoList { get; set; }
        public List<TemReto> TemRetoList { get; set; }
        public List<EtaReto> EtaRetoList { get; set; }
        public List<IncReto> IncRetoList { get; set; }
        public List<PartiReto> PartiRetoList { get; set; }


    }

    public class DocReto
    {

        public string Tipo { get; set; }
        public string Webp { get; set; }
        public string Base64 { get; set; }
        public string NombreDocumento { get; set; }
        public bool FlagPortada { get; set; }
    }
    public class EntReto
    {

        public Guid EntidadId { get; set; }
        public string NombreEntidad { get; set; }
        public bool Estado { get; set; }
    }
    public class TemReto
    {
        public Guid TemaId { get; set; }

    }
    public class EtaReto
    {

        public string Nombre { get; set; }
        public DateTime FechaInicial { get; set; }
        public DateTime FechaFinal { get; set; }
        public bool Estado { get; set; }
    }
    public class IncReto
    {

        public string Nombre { get; set; }
        public string Descripcion { get; set; }
        public bool Estado { get; set; }
    }
    public class PartiReto
    {
        public Guid ParticipanteId { get; set; }

    }


}
