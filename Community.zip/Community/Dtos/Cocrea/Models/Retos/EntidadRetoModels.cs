﻿using System;

namespace Community.Dtos.Cocrea.Models.Retos
{
    public class EntidadRetoModels
    {
        public Guid EntidadRetoId { get; set; }
        public Guid RetoId { get; set; }
        public Guid EntidadId { get; set; }
        public string NombreEntidad { get; set; }
        public bool Estado { get; set; }
    }
}
