﻿using System.Collections.Generic;

namespace Community.Dtos.Cocrea.Models.Retos
{
    public class ParticipanteRetoAdminModels
    {
        public ParticipanteRetoAdminModels()
        {
            List = new List<ParticipanteRetoModels>();
        }

        public int Count { get; set; }

        public List<ParticipanteRetoModels> List { get; set; }
    }
}
