﻿using System;

namespace Community.Dtos.Cocrea.Models.Retos
{
    public class EtapaRetoModels
    {
        public Guid EtapaRetoId { get; set; }
        public Guid RetoId { get; set; }
        public string Nombre { get; set; }
        public DateTime FechaInicial { get; set; }
        public DateTime FechaFinal { get; set; }
        public bool Estado { get; set; }
    }
}
