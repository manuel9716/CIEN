﻿using System;

namespace Community.Dtos.Cocrea.Models.Retos
{
    public class ParticipanteRetoModels
    {
        public Guid ParticipanteRetoId { get; set; }
        public Guid RetoId { get; set; }
        public Guid ParticipanteId { get; set; }
        public bool Estado { get; set; }
        public string nombreParticipante { get; set; }
        public bool estadoparticipante { get; set; }
        
    }
}
