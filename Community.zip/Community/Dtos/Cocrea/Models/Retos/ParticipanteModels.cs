﻿using System;

namespace Community.Dtos.Cocrea.Models.Retos
{
    public class ParticipanteModels
    {
        public Guid ParticipanteId { get; set; }
        public string Nombre { get; set; }
        public bool Estado { get; set; }
    }
}
