﻿using System.Collections.Generic;

namespace Community.Dtos.Cocrea.Models.Retos
{
    public class IncentivoRetoAdminModels
    {
        public IncentivoRetoAdminModels()
        {
            List = new List<IncentivoRetoModels>();
        }
        public int Count { get; set; }
        public List<IncentivoRetoModels> List { get; set; }
    }
}
