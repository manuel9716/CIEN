﻿
using System;

namespace Community.Dtos.Cocrea.Models.Retos
{
    public class RetoModels
    {

        public Guid RetoId { get; set; }
        public string Titulo { get; set; }
        public string Descripcion { get; set; }
        public DateTime FechaCreacion { get; set; }
        public DateTime FechaCierre { get; set; }
        public int Vistas { get; set; }
        public string Requisitos { get; set; }
        public string Estado { get; set; }
        public Guid Autor { get; set; }
        public string NombreAutor { get; set; }
        public bool FlagEstado { get; set; }
        public string Base64 { get; set; }
        public bool FlagPortada { get; set; }
        public string NombreTema { get; set; }
        public string NombreParticipante { get; set; }
    }

}
