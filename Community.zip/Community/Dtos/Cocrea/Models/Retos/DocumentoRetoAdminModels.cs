﻿using System.Collections.Generic;

namespace Community.Dtos.Cocrea.Models.Retos
{
    public class DocumentoRetoAdminModels
    {
        public DocumentoRetoAdminModels()
        {
            List = new List<DocumentoRetoModels>();
        }
        public int Count { get; set; }
        public List<DocumentoRetoModels> List { get; set; }
    }
}
