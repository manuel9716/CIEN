﻿using System.Collections.Generic;

namespace Community.Dtos.Cocrea.Models.Retos
{
    public class RetoAdminModels
    {
        public RetoAdminModels()
        {
            List = new List<RetoExtendedModels>();
        }

        public int Count { get; set; }

        public List<RetoExtendedModels> List { get; set; }
       
    }
}
