﻿using System.Collections.Generic;

namespace Community.Dtos.Cocrea.Models.Retos
{
    public class ParticipanteAdminModels
    {
        public ParticipanteAdminModels()
        {
            List = new List<ParticipanteModels>();
        }

        public int Count { get; set; }

        public List<ParticipanteModels> List { get; set; }

    }
}
