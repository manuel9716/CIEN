﻿using System.Collections.Generic;

namespace Community.Dtos.Cocrea.Models.Retos
{
    public class TemaAdminModels
    {
        public TemaAdminModels()
        {
            List = new List<TemaModels>();
        }

        public int Count { get; set; }

        public List<TemaModels> List { get; set; }
    }
}
