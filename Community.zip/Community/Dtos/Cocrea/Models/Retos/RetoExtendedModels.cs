﻿using System;
using System.Collections.Generic;

namespace Community.Dtos.Cocrea.Models.Retos
{
    public class RetoExtendedModels
    {
          public RetoExtendedModels()
        {
            DocumentoList = new List<DocumentoRetoModels>();
            EntidadList = new List<EntidadRetoModels>();
            TemaList = new List<TemaRetoModels>();
            EtapaList = new List<EtapaRetoModels>();
            IncentivoList = new List<IncentivoRetoModels>();
            ParticipanteList = new List<ParticipanteRetoModels>();
        }

        public Guid RetoId { get; set; }
        public string Titulo { get; set; }
        public string Descripcion { get; set; }
        public DateTime FechaCreacion { get; set; }
        public DateTime FechaCierre { get; set; }
        public int Vistas { get; set; }
        public string Requisitos { get; set; }
        public string Estado { get; set; }
        public Guid Autor { get; set; }
        public bool FlagEstado { get; set; }
        public List<DocumentoRetoModels> DocumentoList { get; set; }
        public List<EntidadRetoModels> EntidadList { get; set; }
        public List<TemaRetoModels> TemaList { get; set; }
        public List<EtapaRetoModels> EtapaList { get; set; }
        public List<IncentivoRetoModels> IncentivoList { get; set; }
        public List<ParticipanteRetoModels> ParticipanteList { get; set; }
    }
}
