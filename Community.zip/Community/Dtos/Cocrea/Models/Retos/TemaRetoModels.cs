﻿using System;
using System.Collections.Generic;

namespace Community.Dtos.Cocrea.Models.Retos
{
    public class TemaRetoModels
    {
        public Guid Id { get; set; }
        public Guid RetoId { get; set; }
        public bool Estado { get; set; }
        public Guid TemaId { get; set; }
        public string nombreTema { get; set; }
        public bool estadoTema { get; set; }
    }
}
