﻿using System;

namespace Community.Dtos.Cocrea.Models.Retos
{
    public class DocumentoRetoModels
    {
        public Guid DocumentoRetoId { get; set; }
        public Guid RetoId { get; set; }
        public string Tipo { get; set; }
        public string Webp { get; set; }
        public string Base64 { get; set; }
        public string NombreDocumento { get; set; }
        public bool FlagPortada { get; set; }
    }
}
