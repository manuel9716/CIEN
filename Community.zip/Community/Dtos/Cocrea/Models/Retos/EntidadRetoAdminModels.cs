﻿using System.Collections.Generic;

namespace Community.Dtos.Cocrea.Models.Retos
{
    public class EntidadRetoAdminModels
    {
        public EntidadRetoAdminModels()
        {
            List = new List<EntidadRetoModels>();
        }
        public int Count { get; set; }
        public List<EntidadRetoModels> List { get; set; }
    }
}
