﻿using System.Collections.Generic;

namespace Community.Dtos.Cocrea.Models.Retos
{
    public class EtapaRetoAdminModels
    {
        public EtapaRetoAdminModels()
        {
            List = new List<EtapaRetoModels>();
        }
        public int Count { get; set; }
        public List<EtapaRetoModels> List { get; set; }
    }
}
