﻿using System;

namespace Community.Dtos.Cocrea.Models.Retos
{
    public class TemaModels
    {
        public Guid TemaId { get; set; }
        public string Nombre { get; set; }
        public bool Estado { get; set; }
        public string Descripcion { get; set; }
    }
}
