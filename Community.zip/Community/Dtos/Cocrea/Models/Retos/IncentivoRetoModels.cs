﻿using Community.Models.Cocrea;
using System;

namespace Community.Dtos.Cocrea.Models.Retos
{
    public class IncentivoRetoModels
    {
        public Guid IncentivoRetoId { get; set; }
        public Guid RetoId { get; set; }
        public string Nombre { get; set; }
        public string Descripcion { get; set; }
        public bool Estado { get; set; }

    }
}

