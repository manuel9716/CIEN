﻿using System.Collections.Generic;

namespace Community.Dtos.Cocrea.Models.Retos
{
    public class TemaRetoAdminModels
    {
        public TemaRetoAdminModels()
        {
            List = new List<TemaRetoModels>();
        }

        public int Count { get; set; }

        public List<TemaRetoModels> List { get; set; }
    }
}
