﻿using Microsoft.EntityFrameworkCore.Query.SqlExpressions;
using System;

namespace Community.Dtos.Cocrea.Models
{
    public class ResponseModels
    {
        public bool IsSuccess { get; set; }
        public string Message { get; set; }

    }
}
