﻿using System.Collections.Generic;

namespace Community.Dtos.Cocrea.Models.Preguntas
{
    public class CocreaComentModels
    {
        public CocreaComentModels()
        {
            List = new List<ComentRespuestaModels>();
        }
        public int Count { get; set; }
        public List<ComentRespuestaModels> List { get; set; }
    }
}
