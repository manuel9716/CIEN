﻿using System;

namespace Community.Dtos.Cocrea.Models.Preguntas
{
    public class ComentRespuestaModels
    {
        public Guid ComentarioId { get; set; }
        public string ComentarioTexto { get; set; }
        public bool Estado { get; set; }
        public DateTime FechaCreacion { get; set; }
        public DateTime FechaModificacion { get; set; }
        public Guid Autor { get; set; }
        public string NombreAutor { get; set; }
        public Guid ModificadoPor { get; set; }
        public Guid RespuestaId { get; set; }
    }
}
