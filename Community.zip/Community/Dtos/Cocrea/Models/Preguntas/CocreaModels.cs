﻿using System.Collections.Generic;

namespace Community.Dtos.Cocrea.Models.Preguntas
{
    public class CocreaModels
    {
        public CocreaModels()
        {
            List = new List<PreguntaModels>();
        }
        public int Count { get; set; }
        public List<PreguntaModels> List { get; set; }
    }
}
