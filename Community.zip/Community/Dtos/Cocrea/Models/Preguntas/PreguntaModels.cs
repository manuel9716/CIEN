﻿using System;
using System.Collections.Generic;

namespace Community.Dtos.Cocrea.Models.Preguntas
{
    public class PreguntaModels
    {
        public PreguntaModels()
        {
            RespuestaList = new List<RespuestaModels>();
        }
        public Guid PreguntaId { get; set; }
        public Guid EntidadId { get; set; }
        public string EntidadNombre { get; set; }
        public Guid GrupoId { get; set; }
        public string GrupoNombre { get; set; }
        public string PreguntaTexto { get; set; }
        public string Justificacion { get; set; }
        public bool Estado { get; set; }
        public DateTime FechaCreacion { get; set; }
        public DateTime FechaModificacion { get; set; }
        public Guid Autor { get; set; }
        public Guid ModificadoPor { get; set; }
        public int Contador { get; set; }
        public List<RespuestaModels> RespuestaList { get; set; }
    }
}
