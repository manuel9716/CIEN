﻿using System;

namespace Community.Dtos.Cocrea.Models.Preguntas
{
    public class RespuestaModels
    {
        public Guid RespuestaId { get; set; }
        public string RespuestaTexto { get; set; }
        public bool Estado { get; set; }
        public DateTime FechaCreacion { get; set; }
        public DateTime FechaModificacion { get; set; }
        public Guid Autor { get; set; }
        public  string NombreAutor { get; set; }
        public  string Nombreentidad { get; set; }
        public bool isLike { get; set; }
        public Guid ModificadoPor { get; set; }
        public Guid PreguntaId { get; set; }
        public int LikesCount { get; set; }
    }
}
