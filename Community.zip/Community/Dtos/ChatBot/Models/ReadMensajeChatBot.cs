﻿using System;

namespace Community.Dtos.ChatBot.Models
{
    public class ReadMensajeChatBot
    {

        public int IDChatBot { get; set; }

        public string HTMLTexto { get; set; }
        public string Tipo { get; set; }
        public string Llave { get; set; }
        public int Ubicacion { get; set; }
        public string Anterior { get; set; }
        public string Ejecucion { get; set; }
        public string Siguiente { get; set; }
        public DateTime FechaCreacion { get; set; }
        public string UsuarioCreacion { get; set; }
        public int Estado { get; set; }
    }
}
