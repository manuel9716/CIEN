﻿using AutoMapper;
using Community.Dtos.ChatBot.Models;
using Community.Models.ChatBot;

namespace Community.Dtos.ChatBot.Mappings
{
    public class ReadMensajeChatBotMapping : Profile
    {

        public ReadMensajeChatBotMapping()
        {
            CreateMap<MensajeChatbot, ReadMensajeChatBot>();
        }

    }
}
