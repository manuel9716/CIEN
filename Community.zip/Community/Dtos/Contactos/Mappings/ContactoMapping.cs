using AutoMapper;
using Community.Dtos.AppUsers.Models;
using Community.Dtos.Contactos.Models;
using Community.Models;
using Community.Models.contactos;

namespace Community.Dtos.Contactos.Mappings
{
    public class ContactoMapping : Profile
    {
        public ContactoMapping()
        {
            CreateMap<CreateContacto, Contacto>().ReverseMap();
            CreateMap<ReadContacto, Contacto>().ReverseMap();
        }
    }
}
