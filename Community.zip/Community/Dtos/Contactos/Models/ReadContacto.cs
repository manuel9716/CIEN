using Community.Models.publication;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Community.Models.interests;
using Community.Models.Messages;
using Community.Models.notification;
using Community.Models.tool;
using Community.Models.experience;
using Community.Models.Learn;
using Community.Models.project;

namespace Community.Dtos.Contactos.Models
{
    public class ReadContacto
    {
        public Guid UserId { get; set; }
        public Guid ContactId { get; set; }
        public string Respuesta { get; set; }

    }
}

