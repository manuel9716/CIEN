using System;
using System.Collections.Generic;
using System.Text.Json.Serialization;

namespace Community.Dtos.Messages.Models
{
    public class CreateMessage
    {
        public Guid ConversacionId { get; set; }
        public string Mensaje { get; set; }
        public string UrlGif { get; set; }
        [JsonIgnore]
        public Guid AppUserId { get; set; }
        public List<Guid> Files { get; set; }
    }
}