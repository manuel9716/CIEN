using System.Collections.Generic;

namespace Community.Dtos.Messages.Models
{
    public class ReadMessageFinal
    {
        public int NroMensajesSinLeer { get; set; }
        public List<ReadMessage> Mensajes { get; set; }
    }
}