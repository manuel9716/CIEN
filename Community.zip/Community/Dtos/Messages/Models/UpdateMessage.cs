using System;

namespace Community.Dtos.Messages.Models
{
    public class UpdateMessage
    {
        public Guid Id { get; set; }
        public bool Leido { get; set; }
    }
}