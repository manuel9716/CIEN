using System;

namespace Community.Dtos.Messages.Models
{
    public class ReadConversationSocket
    {
        public Guid Id { get; set; }
        public int NroMensajesSinLeer { get; set; } = 0;
      
    }
}