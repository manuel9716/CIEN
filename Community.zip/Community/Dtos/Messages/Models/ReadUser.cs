using System;
namespace Community.Dtos.Messages.Models
{
    public class ReadUser
    {
        public Guid Id { get; set; }
        public String Nombres { get; set; }
        public String Apellidos { get; set; }
        
    }
}