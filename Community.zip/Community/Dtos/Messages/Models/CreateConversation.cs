using System;
using System.Collections.Generic;
using System.Linq;
using System.Text.Json.Serialization;
using System.Threading.Tasks;

namespace Community.Dtos.Messages.Models
{
    public class CreateConversation
    {
        [JsonIgnore]
        public Guid UserSenderId { get; set; }
        public Guid UserReceptorId { get; set; }
    }
}