using System;

namespace Community.Dtos.Messages.Models
{
    public class ReadConversacionesConectados
    {
        public Guid Id { get; set; }
        public Guid ConversacionId { get; set; }
        public Guid AppUserId { get; set; }
        public string SocketId { get; set; }

    }
}