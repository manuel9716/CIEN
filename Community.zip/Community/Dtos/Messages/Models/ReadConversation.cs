using Community.Dtos.AppUsers.Models;
using System;
using System.Text.Json.Serialization;

namespace Community.Dtos.Messages.Models
{
    public class ReadConversation
    {
        public Guid Id { get; set; }
        public int NroMensajesSinLeer { get; set; } = 0;
        [JsonPropertyName("Usuario")]
        public ReadAppUser ReceptorUsuario { get; set; }
        public DateTime FechaCreacion { get; set; }
         public string ultimoMensaje { get; set; } = "";
    }
}
