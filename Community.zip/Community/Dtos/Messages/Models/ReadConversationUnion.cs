using System;

namespace Community.Dtos.Messages.Models
{
    public class ReadConversationUnion
    {
        public Guid Id { get; set; }
        public ReadConversation SenderConversacion { get; set; }
        public ReadConversation ReceptorConversacion { get; set; }
    }
}