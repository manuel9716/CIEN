using Community.Dtos.AppUsers.Models;
using System;
using System.Collections.Generic;

namespace Community.Dtos.Messages.Models
{
    public class ReadMensajesSinLeerUsuario
    {
       public int NroMensajesSinLeer { get; set; } = 0;
    }
}