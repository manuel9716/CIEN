using Community.Dtos.AppUsers.Models;
using System;
using System.Collections.Generic;

namespace Community.Dtos.Messages.Models
{
    public class ReadMessage
    {
        public Guid Id { get; set; }
        public string Mensaje { get; set; }
        public string UrlGif { get; set; }
        public DateTime FechaCreacion { get; set; }
        public ReadAppUser Usuario { get; set; }
        public List<ReadMessageFile> Files { get; set; }

        //public bool Leido { get; set; } = false;
    }
}