using System;

namespace Community.Dtos.Messages.Models
{
    public class CreateConversationUnion
    {
        public Guid IdSender { get; set; }
        public Guid IdReceptor { get; set; }
    }
}