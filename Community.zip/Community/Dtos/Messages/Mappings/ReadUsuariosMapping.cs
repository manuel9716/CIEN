using AutoMapper;
using Community.Dtos.Messages.Models;
using Community.Models;
using Community.Models.Messages;

namespace Community.Dtos.Messages.Mappings
{
    public class ReadUsuariosMapping: Profile
    {
        public ReadUsuariosMapping()
        {
            CreateMap<AppUser, ReadUser>();
        }
    }
}