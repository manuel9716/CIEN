using AutoMapper;
using Community.Dtos.Messages.Models;
using Community.Models.Messages;

namespace Community.Dtos.Messages.Mappings
{
    public class CreateMessageMapping:Profile
    {
        public CreateMessageMapping()
        {
            CreateMap<CreateMessage, Message>();
        }
    }
}