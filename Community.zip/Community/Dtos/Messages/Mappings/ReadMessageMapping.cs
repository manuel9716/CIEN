using AutoMapper;
using Community.Dtos.Messages.Models;
using Community.Models.Messages;

namespace Community.Dtos.Messages.Mappings
{
    public class ReadMessageMapping: Profile
    {
        public ReadMessageMapping()
        {
            CreateMap<Message, ReadMessage>();
        }
    }
}
