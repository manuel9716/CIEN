using System;

namespace Community.Dtos.Learn.Models
{
    public class ReadOfertaDirigidoA
    {
        public Guid Id { get; set; }
        public Guid DirigidoAId { get; set; }
        public string Nombre { get; set; }
    }
}