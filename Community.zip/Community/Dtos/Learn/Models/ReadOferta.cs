using Community.Dtos.AppUsers.Models;
using System;
using System.Collections.Generic;

namespace Community.Dtos.Learn.Models
{
    public class ReadOferta
    {
        public Guid Id { get; set; }
        public string Titulo { get; set; }
        public Guid TipoId { get; set; }
        public string Contenido { get; set; }
        public List<string> Modulos { get; set; }
        public Guid TiempoId { get; set; }
        public List<Guid> DirigidosA { get; set; }
        public bool ExisteRequisitoPrevio { get; set; }
        public string RequisitoPrevioCuales { get; set; }
        public List<Guid> Temas { get; set; }
        public Guid ModalidadId { get; set; }
        public string Url { get; set; }
        public List<string> Files { get; set; }
        public Guid AppFilePortadaId { get; set; }
        public string UrlVideo { get; set; }
        public string Etiquetas { get; set; }
        public string NombreContacto { get; set; }
        public string DependenciaContacto { get; set; }
        public string CorreoContacto { get; set; }
        public string IndicativoCelularContacto { get; set; }
        public string NumeroCelularContacto { get; set; }
        public bool EstaInteresadoConocerOfertas { get; set; }
        public DateTime FechaCreacion { get; set; }
        public DateTime FechaActualizacion { get; set; }
        public ReadAppUser Usuario { get; set; }

    }
}
