using System;

namespace Community.Dtos.Learn.Models
{
    public class ReadOfertaModulo
    {
        public Guid Id { get; set; }
        public string Descripcion { get; set; }
    }
}