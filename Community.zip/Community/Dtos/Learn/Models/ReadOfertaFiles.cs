using System;

namespace Community.Dtos.Learn.Models
{
    public class ReadOfertaFiles
    {
        public Guid Id { get; set; }
        public Guid AppFileId { get; set; }
    }
}