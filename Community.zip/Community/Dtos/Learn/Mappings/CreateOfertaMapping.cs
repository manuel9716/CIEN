using AutoMapper;
using Community.Dtos.Learn.Models;
using Community.Models.Learn;

namespace Community.Dtos.Learn.Mappings
{
    public class CreateOfertaMapping: Profile
    {
        public CreateOfertaMapping()
        {
            CreateMap<CreateOferta, Oferta>();
        }
    }
}
