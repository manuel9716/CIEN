using AutoMapper;
using Community.Dtos.Learn.Models;
using Community.Models.Learn;

namespace Community.Dtos.Learn.Mappings
{
    public class ReadOfertaDirigidoaMapping : Profile
    {
        public ReadOfertaDirigidoaMapping()
        {
            CreateMap<Oferta_DIrigido_A, ReadOfertaDirigidoA>();
        }
    }
}
