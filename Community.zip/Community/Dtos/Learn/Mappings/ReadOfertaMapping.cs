using AutoMapper;
using Community.Dtos.Learn.Models;
using Community.Models.Learn;

namespace Community.Dtos.Learn.Mappings
{
    public class ReadOfertaMapping: Profile
    {
        public ReadOfertaMapping()
        {
            CreateMap<Oferta, ReadOferta>();
            CreateMap<Oferta, ReadOfertas>();
        }
    }
}
