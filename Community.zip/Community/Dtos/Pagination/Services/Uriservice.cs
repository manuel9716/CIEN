using System;
using Community.Dtos.Pagination.Models;
using Microsoft.AspNetCore.WebUtilities;

namespace Community.Dtos.Pagination.Services
{
    public class UriService : IUriService
    {
        private readonly String _baseUri;
        public UriService(String baseUri)
        {
            _baseUri = baseUri;
        }
        public Uri GetPageUri(Paginator paginator, String route)
        {
            var _enpointUri = new Uri(string.Concat(_baseUri, route));
            var modifiedUri = QueryHelpers.AddQueryString(_enpointUri.ToString(), "pageNumber", paginator.PageNumber.ToString());
            modifiedUri = QueryHelpers.AddQueryString(modifiedUri, "pageSize", paginator.PageSize.ToString());
            return new Uri(modifiedUri);
        }
    }
}
