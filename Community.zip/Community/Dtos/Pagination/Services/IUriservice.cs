using System;
using Community.Dtos.Pagination.Models;

namespace Community.Dtos.Pagination.Services
{
    public interface IUriService
    {
        public Uri GetPageUri(Paginator paginator, string route);

    }
}
