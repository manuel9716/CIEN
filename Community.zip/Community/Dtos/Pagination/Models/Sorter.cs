using System;

namespace Community.Dtos.Pagination.Models
{
    public class Sorter
    {
        public String SortBy { get; set; }
        public String SortOrder { get; set; }
        public Sorter()
        {
            SortBy = "id";
            SortOrder = "asc";
        }
        public Sorter(String _sortBy, String _sortOrder)
        {
            SortBy = _sortBy;
            SortOrder = _sortOrder;
        }
    }
}
