using System;
using System.Collections.Generic;
using System.Text.Json.Serialization;

namespace Community.Dtos.Publications.Models
{
    public class UpdatePublication
    {
        public Guid Id { get; set; }
        public String Descripcion { get; set; }
        public string UrlGif { get; set; }
        [JsonIgnore]
        public Guid AppUserId { get; set; }
        public List<Guid> Files { get; set; }
    }
}