using System;

namespace Community.Dtos.Publications.Models
{
    public class ReadHidePublication
    {
        public Guid Id { get; set; }
        public Guid PublicacionId { get; set; }
        public Guid ListaItemId { get; set; }
        public DateTime FechaCreacion { get; set; }
    }
}