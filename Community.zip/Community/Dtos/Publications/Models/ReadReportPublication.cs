using System;

namespace Community.Dtos.Publications.Models
{
    public class ReadReportPublication
    {
        public Guid Id { get; set; }
        public Guid PublicacionId { get; set; }
        public Guid ListaItemId { get; set; }
        public String Otro { get; set; }
        public DateTime FechaCreacion { get; set; }
    }
}