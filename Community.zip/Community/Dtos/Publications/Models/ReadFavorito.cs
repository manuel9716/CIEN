using System;
using System.Collections.Generic;
using Community.Dtos.AppUsers.Models;
using Community.Models.publication;

namespace Community.Dtos.Publications.Models
{
    public class ReadFavorito
    {
        public Guid Id { get; set; }
        public DateTime FechaCreacion { get; set; }
        public ReadPublicationFavorito Publicacion { get; set; }

    }
}