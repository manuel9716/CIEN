using System;
using System.Collections.Generic;
using Community.Dtos.AppUsers.Models;
using Community.Models.publication;

namespace Community.Dtos.Publications.Models
{
    public class ReadFavoritoEliminar
    {
        public int NroFavoritos { get; set; }
        public ReadFavorito Favoritos { get; set; }

    }
}