using Community.Dtos.AppUsers.Models;
using Community.Dtos.Publications.Models;
using System;
using System.Collections.Generic;
using System.Text.Json.Serialization;

namespace Community.Dtos.Publications
{
    public class ReadPublication
    {
        public Guid Id { get; set; }
        public String Descripcion { get; set; }
        public DateTime FechaCreacion { get; set; }
        public DateTime FechaActualizacion { get; set; }
        public string UrlGif { get; set; }
        public ReadAppUser Usuario { get; set; }
        // public ReadUsuario Usuario { get; set; }
        public List<ReadComment> Publicacioncomentario { get; set; }
        public int NroMeGusta { get; set; }
        public int NroFavoritos { get; set; }
        public int NroComentarios { get; set; }
        public List<ReadPublicationFile> Files { get; set; }
        public ReadPublication PublicacionCompartida { get; set; }
        [JsonIgnore]
        public string CompartirId { get; set; } = null;

    }
}