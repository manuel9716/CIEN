using System;
using System.Text.Json.Serialization;

namespace Community.Dtos.Publications.Models
{
    public class CreateCommentPublication
    {
        public String Descripcion { get; set; }
        public Guid PublicacionId { get; set; }
        [JsonIgnore]
        public Guid AppUserId { get; set; }
        public string PadreId { get; set; }

    }
}