using System;
using System.Collections.Generic;
using Community.Dtos.AppUsers.Models;
using Community.Models.publication;

namespace Community.Dtos.Publications.Models
{
    public class ReadFavoritoFinal
    {
        public int NroFavoritos { get; set; }
        public List<ReadFavorito> Favoritos { get; set; }

    }
}