using Community.Dtos.AppUsers.Models;
using System;
using System.Collections.Generic;

namespace Community.Dtos.Publications.Models
{
    public class ReadComentComent: ReadComment
    {
        
        public List<ReadComentComent> Comments {get; set;}
      
    }
}