using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.Text.Json.Serialization;

namespace Community.Dtos.Publications.Models
{
    public class CreatePublication
    {
        public String Descripcion { get; set; }
        public string UrlGif { get; set; }
        [JsonIgnore]
        public Guid AppUserId { get; set; }
        public List<Guid> Files { get; set; }
        public string CompartirId { get; set; }
    }
}