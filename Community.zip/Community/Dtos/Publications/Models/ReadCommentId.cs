using Community.Dtos.AppUsers.Models;
using System;
using System.Collections.Generic;

namespace Community.Dtos.Publications.Models
{
    public class ReadCommentId
    {
        public Guid Id { get; set; }
        public Guid PublicacionId { get; set; }
        public String Descripcion { get; set; }
        public DateTime FechaCreacion { get; set; }
        public DateTime FechaActualizacion { get; set; }
        public int NroComentarios { get; set; }
        public ReadAppUser Usuario { get; set; }
        public int NroMeGusta { get; set; }
        public List<ReadComentComent> Comentariocomentario { get; set; }

    }
}
