using System;
using Community.Dtos.AppUsers.Models;
using Community.Models.publication;

namespace Community.Dtos.Publications.Models
{
    public class ReadPublicationFavorito
    {
        public Guid Id { get; set; }
        public String Descripcion { get; set; }
        public DateTime FechaCreacion { get; set; }
        public DateTime FechaActualizacion { get; set; }
        public string UrlGif { get; set; }
        public ReadAppUser Usuario { get; set; }


    }
}