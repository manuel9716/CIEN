using System;
using System.Text.Json.Serialization;

namespace Community.Dtos.Publications.Models
{
    public class DeletePublication
    {
        public Guid Id { get; set; }
        [JsonIgnore]
        public Guid AppUserId { get; set; }

    }
}