using System;
using System.Text.Json.Serialization;

namespace Community.Dtos.Publications.Models
{
    public class CreateReportPublications
    {
        public Guid PublicacionId { get; set; }
        [JsonIgnore]
        public Guid AppUserId { get; set; }
        public Guid ListaItemId { get; set; }
        public String Otro { get; set; }

    }
}