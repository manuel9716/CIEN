using Community.Dtos.AppUsers.Models;
using System;
using System.Collections.Generic;

namespace Community.Dtos.Publications.Models
{
    public class ReadPublicationId
    {
        public Guid Id { get; set; }
        public String Descripcion { get; set; }
        public DateTime FechaCreacion { get; set; }
        public DateTime FechaActualizacion { get; set; }
        public string UrlGif { get; set; }
        public ReadAppUser Usuario { get; set; }
        public List<ReadCommentId> Publicacioncomentario { get; set; }
        public int NroMeGusta { get; set; }
        public int NroFavoritos { get; set; }
        public int NroComentarios { get; set; }
        public List<ReadPublicationFile> Files { get; set; }
    }
}
