using System;
using System.Text.Json.Serialization;

namespace Community.Dtos.Publications.Models
{
    public class CreateIteracionComment
    {
        public Guid ComentarioId { get; set; }
        [JsonIgnore]
        public Guid AppUserId { get; set; }
        public string TipoItem { get; set; }
        [JsonIgnore]
        public Guid ListaItemId { get; set; }

    }
}