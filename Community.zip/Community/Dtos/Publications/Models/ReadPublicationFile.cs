using System;

namespace Community.Dtos.Publications.Models
{
    public class ReadPublicationFile
    {
        public Guid Id { get; set; }
        public string Path { get; set; }
        public string FileName { get; set; }
        public string ContentType { get; set; }
    }
}
