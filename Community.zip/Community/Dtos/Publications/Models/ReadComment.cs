using Community.Dtos.AppUsers.Models;
using System;

namespace Community.Dtos.Publications.Models
{
    public class ReadComment
    {
        public Guid Id { get; set; }
        public Guid PublicacionId { get; set; } 
        public String Descripcion { get; set; }
        public DateTime FechaCreacion { get; set; }
        public DateTime FechaActualizacion { get; set; }
        public int NroComentarios { get; set; }
        public ReadAppUser Usuario { get; set; }
        // public ReadUsuario Usuario { get; set; }
        public int NroMeGusta { get; set; }
        public bool TieneComentarios { get; set; } = false;

        // public int NroFavoritos { get; set; }

      
    }
}