using AutoMapper;
using Community.Dtos.AppUsers.Models;
using Community.Dtos.Publications.Models;
using Community.Models;
using Community.Models.publication;
using System.Collections.Generic;
using System.Linq;

namespace Community.Dtos.Publications.Mappings
{
    public class ReadPublicationItemMapping: Profile
    {
        public ReadPublicationItemMapping()
        {
            CreateMap<Publication, ReadPublication>();
            CreateMap<Publication, ReadPublicationId>();
            //  CreateMap<Publication, ReadPublication>()
            //     .ForMember(comentDTO => comentDTO.Publicacioncomentario, opciones => opciones.MapFrom(MapPublicationComment));
                CreateMap<AppUser, ReadUsuario>();
        }
        private List<ReadComment> MapPublicationComment(Publication publication, ReadPublication readPublication)
        {
            var resultado = new List<ReadComment>();

            if(publication.Descripcion == null) { return resultado; }

            if(publication.Publicacioncomentario == null) { return resultado; }

            foreach (var publicacionComentario in publication.Publicacioncomentario)
            {
                resultado.Add(new ReadComment()
                {
                    Id = publicacionComentario.Id,
                    Descripcion = publicacionComentario.Descripcion,
                    FechaCreacion = publicacionComentario.FechaCreacion,
                    FechaActualizacion = publicacionComentario.FechaActualizacion,
                    Usuario = new ReadAppUser()
                    {
                        Id = publicacionComentario.Usuario.Id,
                        Nombres = publicacionComentario.Usuario.Nombres,
                        Apellidos = publicacionComentario.Usuario.Apellidos,
                        PaisResidenciaId = publicacionComentario.Usuario.PaisResidenciaId,
                        DepartamentoResidenciaId = publicacionComentario.Usuario.DepartamentoResidenciaId,
                        MunicipioResidenciaId = publicacionComentario.Usuario.MunicipioResidenciaId,
                        FechaNacimiento = publicacionComentario.Usuario.FechaNacimiento,
                        GeneroId = publicacionComentario.Usuario.GeneroId                      
                    },
                    NroMeGusta = publicacionComentario.Comentarioiteracion.Count(z => z.ListaItem.Codigo == "ITEMG"),
                    // NroFavoritos = publicacionComentario.Comentarioiteracion.Count(z => z.ListaItem.Codigo == "FV")
                    
                });
                ;
            }

            return resultado;

        }

    }

    

}