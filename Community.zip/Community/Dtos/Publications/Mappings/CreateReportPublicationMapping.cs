using AutoMapper;
using Community.Dtos.Publications.Models;
using Community.Models.publication;

namespace Community.Dtos.Publications.Mappings
{
    public class CreateReportPublicationMapping: Profile
    {
        public CreateReportPublicationMapping()
        {
            CreateMap<CreateReportPublications,Publication_report>();
        }
    }
}