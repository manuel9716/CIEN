using AutoMapper;
using Community.Dtos.Publications.Models;
using Community.Models.publication;

namespace Community.Dtos.Publications.Mappings
{
    public class CreateCommentPublicationMapping: Profile
    {
        public CreateCommentPublicationMapping()
        {
            CreateMap<CreateCommentPublication, Comment>();
        }
    }
}