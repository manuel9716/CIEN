using AutoMapper;
using Community.Dtos.Publications.Models;
using Community.Models.publication;

namespace Community.Dtos.Publications.Mappings
{
    public class ReadCommentMapping: Profile
    {
        public ReadCommentMapping()
        {
            CreateMap<Comment, ReadComment>();
            CreateMap<Comment, ReadCommentId>();

        }
    }
}