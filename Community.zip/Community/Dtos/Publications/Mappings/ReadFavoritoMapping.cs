using AutoMapper;
using Community.Dtos.Publications.Models;
using Community.Models.publication;

namespace Community.Dtos.Publications.Mappings
{
    public class ReadFavoritoMapping: Profile
    {
        public ReadFavoritoMapping()
        {
            CreateMap<Iteracion, ReadFavorito>();
            CreateMap<Publication, ReadPublicationFavorito>();
          
        }


    }
}