﻿using Community.Models.tool;
using System;
using System.Collections.Generic;
using System.Text.Json.Serialization;

namespace Community.Dtos.Tools.Models
{
    public class CreateTools
    {
        //[JsonIgnore]
        public Guid AppUserId { get; set; }
        public Guid TipoRecursoID { get; set; }
        public String DescripcionInnovador { get; set; }
        public String NombreHerramienta { get; set; }
        public Boolean Recurso { get; set; }
        public String DescripcionRecurso { get; set; }
        public String Que_Es { get; set; }
        public String Para_Que_Sirve { get; set; }
        public Boolean valor_como_se_usa { get; set; }
        public String Como_Se_usa { get; set; }
        public Guid TipoHerramientaID { get; set; }
        public String Etiqueta { get; set; }
        public ICollection<CreateToolsFases> ToolFases { get; set; }
        public ICollection<CreateToolsTasks> ToolTareas { get; set; }
        //public ICollection<CreateToolsTeams> ToolEquipos { get; set; }
    }
}
