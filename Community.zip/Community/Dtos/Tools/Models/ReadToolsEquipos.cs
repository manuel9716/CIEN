﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Community.Dtos.ListasItem.Models;

namespace Community.Dtos.Tools.Models
{
    public class ReadToolsEquipos
    {
        public Guid Id { get; set; }
        public Guid toolId { get; set; }
        public Guid EquiposID { get; set; }
        public ReadListaItem Equipos { get; set; }
    }
}
