﻿using Community.Models;
using Community.Models.tool;
using System.Collections.Generic;
using System;
using Community.Dtos.AppUsers.Models;
using Community.Dtos.ListasItem.Models;


namespace Community.Dtos.Tools.Models
{
    public class ReadTools
    {
        public Guid Id { get; set; }
        public Guid AppUserId { get; set; }
        public Guid TipoRecursoID { get; set; }
        public ListaItem TipoRecurso { get; set; }
        public String DescripcionInnovador { get; set; }
        public String NombreHerramienta { get; set; }
        public Boolean Recurso { get; set; }
        public String DescripcionRecurso { get; set; }
        public String Que_Es { get; set; }
        public String Para_Que_Sirve { get; set; }
        public Boolean valor_como_se_usa { get; set; }
        public String Como_Se_usa { get; set; }
        public Guid TipoHerramientaID { get; set; }
        public String Etiqueta { get; set; }
        public ICollection<ToolFase> ToolFases { get; set; }
        public ICollection<ToolTask> ToolTareas { get; set; }
        public ICollection<ToolTeam> ToolEquipos { get; set; }
    }
}
