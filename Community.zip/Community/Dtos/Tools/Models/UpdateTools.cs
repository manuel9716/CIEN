﻿using System;
using System.Text.Json.Serialization;

namespace Community.Dtos.Tools.Models
{
    public class UpdateTools
    {
        public Guid Id { get; set; }
        [JsonIgnore]
        public Guid AppUserId { get; set; }
        public Guid TipoRecursoID { get; set; }
        public String DescripcionInnovador { get; set; }
        public String NombreHerramienta { get; set; }
        public Boolean Recurso { get; set; }
        public String DescripcionRecurso { get; set; }
        public String Que_Es { get; set; }
        public String Para_Que_Sirve { get; set; }
        public Guid PasoID { get; set; }
        public String Como_Se_usa { get; set; }
        //public Guid DiagnosticoID { get; set; }
        //public Guid FormularioID { get; set; }
        //public Guid ImplementacionID { get; set; }
        //public Guid EvaluacionID { get; set; }
        //public Guid DifusionID { get; set; }
        //public Guid EntenderID { get; set; }
        //public Guid DefinirID { get; set; }
        //public Guid IdeasID { get; set; }
        //public Guid ColaborarID { get; set; }
        //public Guid AnalizarID { get; set; }
        //public Guid ProbarID { get; set; }
        //public Guid ComunicarID { get; set; }
        //public Guid GestionarCID { get; set; }
        //public Guid GestionEquipoID { get; set; }
        //public Guid GestionCambioID { get; set; }
        //public Guid TipoHerramientaID { get; set; }
    }
}
