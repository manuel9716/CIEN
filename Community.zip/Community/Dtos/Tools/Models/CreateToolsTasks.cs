﻿using System;
using System.Text.Json.Serialization;

namespace Community.Dtos.Tools.Models
{
    public class CreateToolsTasks
    {
        [JsonIgnore]
        public Guid toolId { get; set; }
        public Guid TareasID { get; set; }
    }
}
