﻿using System;
using System.Text.Json.Serialization;

namespace Community.Dtos.Tools.Models
{
    public class CreateToolsFases
    {
        [JsonIgnore]
        public Guid toolId { get; set; }
        public Guid FasesID { get; set; }
    }
}
