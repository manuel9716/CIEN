﻿using System;
using System.Text.Json.Serialization;

namespace Community.Dtos.Tools.Models
{
    public class CreateToolsTeams
    {
        [JsonIgnore]
        public Guid toolId { get; set; }
        public Guid EquiposID { get; set; }
    }
}
