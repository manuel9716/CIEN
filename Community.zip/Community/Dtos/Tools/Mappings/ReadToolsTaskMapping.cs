﻿using AutoMapper;
using Community.Dtos.Tools.Models;
using Community.Models.tool;

namespace Community.Dtos.Tools.Mappings
{
    public class ReadToolsTaskMapping : Profile
    {
        public ReadToolsTaskMapping()
        {
            CreateMap<ToolTask, ReadToolsFases>();
        }
    }
}
