﻿using AutoMapper;
using Community.Dtos.Tools.Models;
using Community.Models.tool;

namespace Community.Dtos.Tools.Mappings
{
    public class CreateToolsEquiposMapping : Profile
    {
        public CreateToolsEquiposMapping()
        {
            CreateMap<CreateToolsTeams, ToolTeam>();
        }
    }
}
