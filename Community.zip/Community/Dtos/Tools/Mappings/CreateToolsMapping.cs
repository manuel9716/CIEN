﻿using AutoMapper;
using Community.Dtos.Tools.Models;
using Community.Models.tool;

namespace Community.Dtos.Tools.Mappings
{
    public class CreateToolsMapping : Profile
    {
        public CreateToolsMapping()
        {
            CreateMap<CreateTools, Tool>();
        }
    }
}
