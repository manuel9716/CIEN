﻿using AutoMapper;
using Community.Dtos.Tools.Models;
using Community.Models.tool;

namespace Community.Dtos.Tools.Mappings
{
    public class UpdateToolsMapping: Profile
    {
        public UpdateToolsMapping()
        {
            CreateMap<UpdateTools, Tool>();
        }
    }
}
