﻿using AutoMapper;
using Community.Dtos.Tools.Models;
using Community.Models.tool;

namespace Community.Dtos.Tools.Mappings
{
    public class ReadToolsMapping : Profile
    {
        public ReadToolsMapping()
        {
            CreateMap<Tool, ReadTools>();
        }
    }
}
