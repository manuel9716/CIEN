﻿using AutoMapper;
using Community.Dtos.Tools.Models;
using Community.Models.tool;

namespace Community.Dtos.Tools.Mappings
{
    public class CreateToolsFasesMapping : Profile
    {
        public CreateToolsFasesMapping()
        {
            CreateMap<CreateToolsFases, ToolFase>();
        }
    }
}
