using AutoMapper;
using Community.Dtos.Files.Models;
using Community.Models;

namespace Community.Dtos.Files.Mappings
{
    public class UpdateFileMapping : Profile
    {
        public UpdateFileMapping()
        {
            CreateMap<UpdateFile, AppFile>();
        }
    }
}