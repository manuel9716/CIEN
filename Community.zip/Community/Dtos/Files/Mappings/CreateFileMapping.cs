using AutoMapper;
using Community.Dtos.Files.Models;
using Community.Models;
using Microsoft.AspNetCore.Http;

namespace Community.Dtos.Files.Mappings
{
    public class CreateFileMapping : Profile
    {
        public CreateFileMapping()
        {
            CreateMap<IFormFile, CreateFile> ()
            .ForMember (c => c.ContentType, opt => opt.MapFrom (f => f.ContentType))
            .ForMember (c => c.Name, opt => opt.MapFrom (f => f.FileName))
            .ForMember (c => c.Length, opt => opt.MapFrom (f => f.Length));
            CreateMap<CreateFile, AppFile>()
            
            ;
        }
    }
}