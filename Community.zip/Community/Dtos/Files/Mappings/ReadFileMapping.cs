using AutoMapper;
using Community.Dtos.Files.Models;
using Community.Models;
using Microsoft.AspNetCore.Http;

namespace Community.Dtos.Files.Mappings
{
    public class ReadFileMapping : Profile
    {
        public ReadFileMapping()
        {
            CreateMap<AppFile, ReadFile>();
        }
    }
}