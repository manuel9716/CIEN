namespace Community.Dtos.Files.Models
{
    public class SearchFile
    {
        public string ContentType { get; set; }
        public System.Nullable<long> LengthMin { get; set; }
        public System.Nullable<long> LengthMax { get; set; }
        public string Name { get; set; }
    }
}