using System;

namespace Community.Dtos.Files.Models
{
    public class CreateFile
    {
        public string ContentType { get; set; }
        public long Length { get; set; }
        public string Name { get; set; }
        public Guid OwnerId { get; set; }
        public string FileName { get; internal set; }
    }
}