using System;

namespace Community.Dtos.Files.Models
{
    public class UpdateFile
    {
        public Guid Id { get; set; }
        string ContentType { get; set; }
        long Length { get; set; }
        string Name { get; set; }

    }
}