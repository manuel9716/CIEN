﻿using System;
using System.Collections.Generic;
using Community.Dtos.AppUsers.Models;
using Community.Dtos.ListasItem.Models;

namespace Community.Dtos.Experiences.Models
{
    public class ReadExperiences
    {
        public Guid Id { get; set; }
        public ReadAppUser Usuario { get; set; }
        public ReadListaItem ListaItem { get; set; }
        public String DescripcionInnovador { get; set; }
    }
}
