﻿using System;
using System.Text.Json.Serialization;

namespace Community.Dtos.Experiences.Models
{
    public class CreateExperiences
    {
        public Guid Id { get; set; }
        public Guid AppUserId { get; set; }
        public Guid LIstadItemId { get; set; }
        public String DescripcionInnovador { get; set; }
    }
}
