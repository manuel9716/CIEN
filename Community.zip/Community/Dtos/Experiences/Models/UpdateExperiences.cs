﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Community.Dtos.Experiences.Models
{
    public class UpdateExperiences
    {
        public Guid Id { get; set; }
        public Guid AppUserId { get; set; }
        public Guid LIstadItemId { get; set; }
        public String DescripcionInnovador { get; set; }
    }
}
