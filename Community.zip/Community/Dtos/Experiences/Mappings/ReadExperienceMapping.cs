﻿using AutoMapper;
using Community.Dtos.Experiences.Models;
using Community.Models.experience;

namespace Community.Dtos.Experiences.Mappings
{
    public class ReadExperienceMapping : Profile
    {
        public ReadExperienceMapping()
        {
            CreateMap<Experience, ReadExperiences>();
        }
    }
}
