﻿using AutoMapper;
using Community.Dtos.Experiences.Models;
using Community.Models.experience;

namespace Community.Dtos.Experiences.Mappings
{
    public class CreateExperienceMapping :Profile
    {
        public CreateExperienceMapping()
        {
            CreateMap<CreateExperiences, Experience>();
        }
    }
}
