using System;

namespace Community.Dtos.Publications.Models
{
    public class ReadUsuario
    {
        public Guid Id { get; set; }
        public String Nombres { get; set; }
        public String Apellidos { get; set; }
    }
}